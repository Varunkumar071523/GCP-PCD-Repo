'use strict';

// ============================================================
// CONTENT.JS — PopShield
// Injected into every page at document_start (before page scripts run).
// Five blocking layers:
//   1. window.open() override
//   2. Notification.requestPermission override
//   3. Cosmetic CSS (hides known popup selectors instantly)
//   4. MutationObserver (catches dynamically injected popups)
//   5. Zap mode (user-initiated element removal)
// ============================================================

// ── Known popup CSS selectors (cosmetic filter list) ─────────
// These are hidden via injected CSS immediately at document_start.
const COSMETIC_SELECTORS = [
  // Cookie consent — major platforms
  '#onetrust-banner-sdk', '#onetrust-consent-sdk', '#onetrust-pc-sdk',
  '#cookie-law-info-bar', '#cookie-notice', '#cookieNotice',
  '#cookieBanner', '#cookie-banner', '#cookieBar', '#CookieBanner',
  '.cc-banner', '.cc-window', '.cc-revoke',
  '#gdpr-banner', '.gdpr-banner', '#gdpr-overlay', '.gdpr-overlay',
  '#gdpr-cookie-notice', '.gdpr-cookie-notice',
  '#consent-banner', '.consent-banner', '#consent-popup', '.consent-popup',
  '[id*="cookie-banner"]', '[class*="cookie-banner"]',
  '[id*="cookieBanner"]',  '[class*="cookieBanner"]',
  '[id*="cookie-consent"]','[class*="cookie-consent"]',
  '[id*="cookie-notice"]', '[class*="cookie-notice"]',
  '[id*="gdpr"]',          '[class*="gdpr"]',
  // Newsletter / subscribe popups
  '[id*="newsletter-popup"]',   '[class*="newsletter-popup"]',
  '[id*="subscribe-popup"]',    '[class*="subscribe-popup"]',
  '[id*="email-popup"]',        '[class*="email-popup"]',
  '[id*="email-overlay"]',      '[class*="email-overlay"]',
  '[id*="signup-popup"]',       '[class*="signup-popup"]',
  '[id*="modal-newsletter"]',   '[class*="modal-newsletter"]',
  // Exit-intent / interstitial
  '[id*="exit-intent"]',   '[class*="exit-intent"]',
  '[id*="exit-popup"]',    '[class*="exit-popup"]',
  '[id*="interstitial"]',  '[class*="interstitial"]',
  // Push notification prompts (custom UI, not browser native)
  '[id*="push-notification"]',  '[class*="push-notification"]',
  '[id*="notification-popup"]', '[class*="notification-popup"]',
  '[id*="notification-prompt"]','[class*="notification-prompt"]',
  // Generic overlays
  '[id*="popup-overlay"]', '[class*="popup-overlay"]',
  '[id*="modal-overlay"]', '[class*="modal-overlay"]',
  '#modalOverlay', '.modalOverlay', '#modal-overlay', '.modal-overlay',
  '.overlay-backdrop', '.popup-backdrop', '.modal-backdrop',
  // Specific common ones used by major sites
  '#ModalOverlay', '.ReactModal__Overlay',
  '#mc_embed_signup', '#mailmunch-pop-div',
  '.optinmonster-optin-wrap',
];

// ── Keywords that signal a popup element ─────────────────────
const POPUP_KEYWORDS = [
  'popup', 'modal', 'overlay', 'dialog', 'lightbox',
  'cookie', 'consent', 'gdpr', 'ccpa', 'privacy-banner',
  'newsletter', 'subscribe', 'email-capture', 'lead-capture',
  'notification', 'push-prompt', 'permission-prompt',
  'interstitial', 'splash', 'exit-intent', 'takeover',
];

// ── Runtime state ─────────────────────────────────────────────
let settings = null;         // loaded from storage
let domain   = '';
let observer = null;
let zapMode  = false;
let zapHighlighted = null;

// ============================================================
// BOOT — load settings and start blocking
// ============================================================
(async function boot() {
  domain = location.hostname.replace(/^www\./, '');

  const data = await chrome.storage.local.get('settings');
  settings   = data.settings || getDefaultSettings();

  if (isActive()) {
    phase1_overrideAPIs();
    phase2_injectCSS();
    phase3_domBlocking();
    phase4_applyZapRules();
  }
})();

// Listen for live settings updates (e.g. user toggles in popup while page is open)
chrome.runtime.onMessage.addListener((message) => {
  if (message.type === 'SETTINGS_UPDATED') {
    settings = message.settings;
    if (isActive()) {
      phase2_injectCSS();     // re-inject in case new rules apply
      phase3_domBlocking();   // restart observer if needed
    } else if (observer) {
      observer.disconnect();  // stop if disabled
      observer = null;
    }
  }
  if (message.type === 'START_ZAP_MODE') {
    enterZapMode();
  }
});

// ============================================================
// HELPERS
// ============================================================
function getDefaultSettings() {
  return {
    enabled: true, blockWindowOpen: true, blockOverlays: true,
    blockCookieBanners: true, blockNotifications: true,
    removeScrollLocks: true, zapRules: {}, whitelist: [],
  };
}

function isActive() {
  if (!settings?.enabled) return false;
  if ((settings?.whitelist || []).includes(domain)) return false;
  return true;
}

function reportBlock(kind) {
  chrome.runtime.sendMessage({ type: 'POPUP_BLOCKED', domain, kind }).catch(() => {});
}

// ============================================================
// PHASE 1 — Override browser APIs (runs before ANY page script)
// ============================================================
function phase1_overrideAPIs() {

  // ── Block window.open() ──────────────────────────────────
  if (settings.blockWindowOpen) {
    const _open = window.open;
    window.open = function(...args) {
      // Allow blank targets opened by user gestures (keyboard/click)
      // Block anything opened programmatically or with an ad URL
      const url = args[0] || '';
      if (isAdLikeUrl(url)) {
        reportBlock('windowOpen');
        return null;
      }
      // Allow if called with no URL (blank window) — often legitimate
      if (!url || url === 'about:blank' || url === '') {
        return _open.apply(this, args);
      }
      reportBlock('windowOpen');
      return null;
    };
  }

  // ── Block Notification.requestPermission() ───────────────
  if (settings.blockNotifications && typeof Notification !== 'undefined') {
    const _req = Notification.requestPermission.bind(Notification);
    Notification.requestPermission = function() {
      reportBlock('notification');
      return Promise.resolve('denied');
    };
  }
}

// A URL is "ad-like" if it's an external URL opened from a different origin
function isAdLikeUrl(url) {
  if (!url || url === 'about:blank') return false;
  try {
    const u = new URL(url, location.href);
    // Same origin is probably legitimate (e.g. help docs, preview windows)
    return u.hostname !== location.hostname;
  } catch {
    return false;
  }
}

// ============================================================
// PHASE 2 — Inject cosmetic CSS (hides known popup selectors)
// ============================================================
function phase2_injectCSS() {
  const styleId = '__popshield_css__';
  // Remove old style if it exists
  document.getElementById(styleId)?.remove();

  const selectors = [...COSMETIC_SELECTORS];

  // Add user's saved Zap rules for this domain
  const zapRules = settings.zapRules?.[domain] || [];
  selectors.push(...zapRules);

  if (!settings.blockCookieBanners) {
    // If cookie blocking is off, remove cookie-related selectors
    selectors.filter(s => !s.toLowerCase().includes('cookie') && !s.toLowerCase().includes('gdpr'));
  }

  const css = selectors.join(',\n') + ' { display: none !important; visibility: hidden !important; }';

  // Inject before any other styles so we can be overridden deliberately but catch everything early
  const style = document.createElement('style');
  style.id    = styleId;
  style.textContent = css;

  // Insert as early as possible
  const target = document.head || document.documentElement;
  if (target) {
    target.insertBefore(style, target.firstChild);
  }
}

// ============================================================
// PHASE 3 — MutationObserver: catch dynamically added popups
// ============================================================
function phase3_domBlocking() {
  if (observer) {
    observer.disconnect();
    observer = null;
  }

  if (!settings.blockOverlays && !settings.blockCookieBanners) return;

  // Scan once immediately when body is available
  const scanWhenReady = () => {
    if (document.body) {
      scanSubtree(document.body);
      fixScrollLock();
    }
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', scanWhenReady, { once: true });
  } else {
    scanWhenReady();
  }

  // Watch for elements added after page load
  const waitForBody = setInterval(() => {
    if (!document.body) return;
    clearInterval(waitForBody);

    observer = new MutationObserver((mutations) => {
      let needScrollFix = false;
      for (const mutation of mutations) {
        for (const node of mutation.addedNodes) {
          if (node.nodeType === Node.ELEMENT_NODE) {
            if (checkAndBlock(node)) needScrollFix = true;
          }
        }
        // Watch for inline style changes that add scroll locks
        if (mutation.type === 'attributes' && mutation.attributeName === 'style') {
          needScrollFix = true;
        }
      }
      if (needScrollFix && settings.removeScrollLocks) fixScrollLock();
    });

    observer.observe(document.body, {
      childList:  true,
      subtree:    true,
      attributes: true,
      attributeFilter: ['style', 'class'],
    });
  }, 50);
}

// Scan all children of a container
function scanSubtree(root) {
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT);
  let node;
  while ((node = walker.nextNode())) {
    checkAndBlock(node);
  }
}

// Check one element and hide it if it looks like a popup
// Returns true if blocked
function checkAndBlock(el) {
  if (!el || !el.isConnected) return false;
  if (isOurOwnElement(el)) return false;

  let score = 0;
  const tag  = el.tagName?.toLowerCase() || '';

  // Skip tiny/invisible elements
  if (['script', 'style', 'link', 'meta', 'title', 'head'].includes(tag)) return false;

  // ── Signal 1: Keyword in id/class/aria ─────────────────
  const id   = (el.id   || '').toLowerCase();
  const cls  = (el.className && typeof el.className === 'string' ? el.className : '').toLowerCase();
  const role = (el.getAttribute('role') || '').toLowerCase();

  const hasKeyword = POPUP_KEYWORDS.some(k => id.includes(k) || cls.includes(k));
  if (hasKeyword) score += 2;
  if (role === 'dialog' || role === 'alertdialog') score += 2;

  // ── Signal 2: CSS characteristics ──────────────────────
  let style;
  try { style = window.getComputedStyle(el); } catch { return false; }

  const isFixed    = style.position === 'fixed' || style.position === 'sticky';
  const zIndex     = parseInt(style.zIndex) || 0;
  const isHighZ    = zIndex > 100;
  const hasBg      = style.backgroundColor !== 'rgba(0, 0, 0, 0)' &&
                     style.backgroundColor !== 'transparent';
  const hasOpacity = parseFloat(style.opacity) > 0.3;

  if (isFixed && isHighZ) score += 2;
  if (isFixed && hasBg)   score += 1;

  // ── Signal 3: Size (covers a large portion of the viewport) ──
  try {
    const rect  = el.getBoundingClientRect();
    const vw    = window.innerWidth  || 1;
    const vh    = window.innerHeight || 1;
    const wPct  = rect.width  / vw;
    const hPct  = rect.height / vh;

    // Large overlay: covers >40% of viewport in both dimensions
    if (wPct > 0.4 && hPct > 0.4) score += 2;
    // Or a banner: full-width but short (cookie bar)
    if (wPct > 0.8 && hPct > 0.05 && hPct < 0.35) score += 1;
  } catch { /* off-screen */ }

  // ── Signal 4: Has a close button / dismiss button ──────
  if (hasCloseButton(el)) score += 1;

  // Only block if we're fairly confident (score >= 4)
  // This avoids false positives on navigation menus, tooltips, etc.
  if (score >= 4 && hasOpacity) {
    hideElement(el, 'overlay');
    return true;
  }

  return false;
}

function hasCloseButton(el) {
  const closeSelectors = [
    '[class*="close"]', '[id*="close"]', '[aria-label*="close" i]',
    '[class*="dismiss"]', '[class*="cancel"]', '[data-dismiss]',
    'button[type="button"]',
  ];
  return closeSelectors.some(s => el.querySelector(s) !== null);
}

function hideElement(el, kind) {
  try {
    el.style.setProperty('display',    'none', 'important');
    el.style.setProperty('visibility', 'hidden', 'important');
    el.style.setProperty('opacity',    '0', 'important');
    reportBlock(kind);
    if (settings.removeScrollLocks) fixScrollLock();
  } catch (e) { /* read-only element */ }
}

// ============================================================
// PHASE 4 — Apply saved Zap rules for this domain
// ============================================================
function phase4_applyZapRules() {
  const rules = settings.zapRules?.[domain] || [];
  if (rules.length === 0) return;

  const applyRules = () => {
    for (const selector of rules) {
      try {
        document.querySelectorAll(selector).forEach(el => {
          el.style.setProperty('display', 'none', 'important');
        });
      } catch { /* invalid selector */ }
    }
  };

  document.addEventListener('DOMContentLoaded', applyRules);
  applyRules(); // also run immediately for pre-rendered elements
}

// ============================================================
// SCROLL LOCK FIXER
// Sites add overflow:hidden to <body> or <html> when showing modals.
// We restore it when we remove the modal.
// ============================================================
function fixScrollLock() {
  if (!settings.removeScrollLocks) return;

  const targets = [document.body, document.documentElement].filter(Boolean);
  for (const el of targets) {
    try {
      const s = window.getComputedStyle(el);
      if (s.overflow === 'hidden' || s.overflowY === 'hidden') {
        el.style.setProperty('overflow',   'visible', 'important');
        el.style.setProperty('overflow-y', 'auto',    'important');
      }
      // Remove padding-right that sites add to compensate for scrollbar
      if (el.style.paddingRight && parseInt(el.style.paddingRight) > 0) {
        el.style.removeProperty('padding-right');
      }
    } catch { /* no-op */ }
  }
}

// ============================================================
// ZAP MODE — click any element to permanently hide it
// ============================================================
function enterZapMode() {
  if (zapMode) return;
  zapMode = true;

  // Show hint banner
  const banner = document.createElement('div');
  banner.id = '__popshield_zap_banner__';
  banner.style.cssText = `
    position: fixed; top: 0; left: 0; right: 0; z-index: 2147483647;
    background: #0e7490; color: #fff; font-family: system-ui, sans-serif;
    font-size: 13px; font-weight: 600; padding: 10px 16px;
    display: flex; align-items: center; justify-content: space-between;
    box-shadow: 0 2px 12px rgba(0,0,0,.4);
  `;
  banner.innerHTML = `
    <span>🎯 ZAP MODE — Click any element to permanently hide it</span>
    <button id="__popshield_zap_cancel__"
      style="background:rgba(255,255,255,.15);border:none;color:#fff;
             padding:4px 10px;border-radius:4px;cursor:pointer;font-size:12px;">
      Cancel (Esc)
    </button>
  `;
  document.body.appendChild(banner);

  const originalCursor = document.body.style.cursor;
  document.body.style.cursor = 'crosshair';

  // Highlight element on hover
  const onMouseOver = (e) => {
    e.stopPropagation();
    if (zapHighlighted && zapHighlighted !== e.target) {
      zapHighlighted.style.outline = '';
    }
    if (isOurOwnElement(e.target)) return;
    zapHighlighted = e.target;
    zapHighlighted.style.outline = '2px solid #f85149';
  };

  // Click to remove
  const onClick = (e) => {
    if (isOurOwnElement(e.target)) { cancelZap(); return; }
    e.preventDefault();
    e.stopPropagation();

    const el       = e.target;
    const selector = buildSelector(el);

    // Hide immediately
    el.style.setProperty('display', 'none', 'important');
    reportBlock('zap');

    // Save the rule
    chrome.runtime.sendMessage({ type: 'SAVE_ZAP_RULE', domain, selector }).catch(() => {});

    // Brief flash to confirm
    const flash = document.createElement('div');
    flash.style.cssText = `
      position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);
      background:#0e7490;color:#fff;padding:10px 18px;border-radius:8px;
      font-family:system-ui;font-size:13px;font-weight:600;z-index:2147483647;
      pointer-events:none;
    `;
    flash.textContent = `✓ Hidden on ${domain}`;
    document.body.appendChild(flash);
    setTimeout(() => flash.remove(), 1500);

    cancelZap();
  };

  const onKeyDown = (e) => {
    if (e.key === 'Escape') cancelZap();
  };

  const cancelZap = () => {
    zapMode = false;
    if (zapHighlighted) { zapHighlighted.style.outline = ''; zapHighlighted = null; }
    document.body.style.cursor = originalCursor;
    document.removeEventListener('mouseover', onMouseOver, true);
    document.removeEventListener('click',     onClick,     true);
    document.removeEventListener('keydown',   onKeyDown,   true);
    banner.remove();
  };

  document.getElementById('__popshield_zap_cancel__').addEventListener('click', cancelZap);
  document.addEventListener('mouseover', onMouseOver, true);
  document.addEventListener('click',     onClick,     true);
  document.addEventListener('keydown',   onKeyDown,   true);
}

// Build a reasonably specific CSS selector for an element
function buildSelector(el) {
  if (el.id) return `#${CSS.escape(el.id)}`;

  // Build a class-based selector using up to 3 distinctive class names
  if (el.classList?.length > 0) {
    const classes = Array.from(el.classList)
      .filter(c => c.length > 2 && !c.match(/^(active|open|show|visible|hidden)$/i))
      .slice(0, 3);
    if (classes.length > 0) {
      return `${el.tagName.toLowerCase()}.${classes.map(c => CSS.escape(c)).join('.')}`;
    }
  }

  // Fallback: nth-child path (fragile but works for unique elements)
  return buildNthPath(el);
}

function buildNthPath(el) {
  const parts = [];
  let current = el;
  while (current && current !== document.body && parts.length < 4) {
    const tag    = current.tagName.toLowerCase();
    const parent = current.parentElement;
    if (!parent) break;
    const siblings = Array.from(parent.children).filter(c => c.tagName === current.tagName);
    const idx    = siblings.indexOf(current) + 1;
    parts.unshift(siblings.length > 1 ? `${tag}:nth-of-type(${idx})` : tag);
    current = parent;
  }
  return parts.join(' > ');
}

// Don't zap/block our own injected elements
function isOurOwnElement(el) {
  return !!(el?.id?.startsWith('__popshield'));
}

'use strict';

// ============================================================
// BACKGROUND.JS — PopShield
// Manages settings, stats, badge count, and message routing.
// The real work happens in content.js.
// ============================================================

// Default settings applied on first install
const DEFAULT_SETTINGS = {
  enabled:              true,
  blockWindowOpen:      true,   // window.open() popup windows
  blockOverlays:        true,   // modal/overlay divs on the page
  blockCookieBanners:   true,   // cookie consent banners
  blockNotifications:   true,   // browser notification permission prompts
  removeScrollLocks:    true,   // restore scrolling when a popup is blocked
  zapRules:             {},     // { 'domain.com': ['#selector1', '.selector2'] }
  whitelist:            [],     // domains where PopShield is disabled
};

// ── Install: set defaults ────────────────────────────────────
chrome.runtime.onInstalled.addListener(async () => {
  const existing = await chrome.storage.local.get('settings');
  if (!existing.settings) {
    await chrome.storage.local.set({ settings: DEFAULT_SETTINGS, stats: emptyStats() });
  }
  updateBadge();
});

// ── Startup: restore badge ───────────────────────────────────
chrome.runtime.onStartup.addListener(updateBadge);

// ============================================================
// MESSAGE HANDLER — receives messages from content.js & popup.js
// ============================================================
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  const handle = async () => {
    switch (message.type) {

      // content.js reports a blocked popup
      case 'POPUP_BLOCKED': {
        const domain = message.domain || 'unknown';
        const kind   = message.kind   || 'overlay';
        await incrementStats(domain, kind);
        await updateBadge();
        return { ok: true };
      }

      // popup.js asks for current stats + settings
      case 'GET_STATE': {
        const [settingsData, statsData] = await Promise.all([
          chrome.storage.local.get('settings'),
          chrome.storage.local.get('stats'),
        ]);
        return {
          ok:       true,
          settings: settingsData.settings || DEFAULT_SETTINGS,
          stats:    statsData.stats       || emptyStats(),
        };
      }

      // popup.js saves updated settings
      case 'SAVE_SETTINGS': {
        await chrome.storage.local.set({ settings: message.settings });
        // Notify all content scripts that settings changed
        notifyAllTabs({ type: 'SETTINGS_UPDATED', settings: message.settings });
        return { ok: true };
      }

      // popup.js toggles a specific site on/off
      case 'TOGGLE_SITE': {
        const data     = await chrome.storage.local.get('settings');
        const settings = data.settings || DEFAULT_SETTINGS;
        const wl       = settings.whitelist || [];
        const domain   = message.domain;
        if (message.block) {
          settings.whitelist = wl.filter(d => d !== domain);
        } else {
          if (!wl.includes(domain)) settings.whitelist = [...wl, domain];
        }
        await chrome.storage.local.set({ settings });
        notifyAllTabs({ type: 'SETTINGS_UPDATED', settings });
        return { ok: true };
      }

      // popup.js triggers zap mode on the active tab
      case 'START_ZAP_MODE': {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (tab?.id) {
          chrome.tabs.sendMessage(tab.id, { type: 'START_ZAP_MODE' });
        }
        return { ok: true };
      }

      // content.js saves a user-picked zap selector
      case 'SAVE_ZAP_RULE': {
        const data      = await chrome.storage.local.get('settings');
        const settings  = data.settings || DEFAULT_SETTINGS;
        const domain    = message.domain;
        const selector  = message.selector;
        if (!settings.zapRules[domain]) settings.zapRules[domain] = [];
        if (!settings.zapRules[domain].includes(selector)) {
          settings.zapRules[domain].push(selector);
        }
        await chrome.storage.local.set({ settings });
        return { ok: true };
      }

      // popup.js asks to clear all stats
      case 'CLEAR_STATS': {
        await chrome.storage.local.set({ stats: emptyStats() });
        await updateBadge();
        return { ok: true };
      }

      default:
        return { ok: false, error: 'unknown_message' };
    }
  };

  handle().then(sendResponse).catch(err => {
    console.error('[PopShield] Handler error:', err);
    sendResponse({ ok: false, error: err.message });
  });
  return true; // async
});

// ============================================================
// STATS HELPERS
// ============================================================
function emptyStats() {
  return {
    total:    0,
    today:    { date: todayString(), count: 0 },
    byKind:   { windowOpen: 0, overlay: 0, cookie: 0, notification: 0, zap: 0 },
    byDomain: {},   // { 'reddit.com': 12 }
    recent:   [],   // last 20 blocked items [{ domain, kind, time }]
  };
}

async function incrementStats(domain, kind) {
  const data  = await chrome.storage.local.get('stats');
  const stats = data.stats || emptyStats();

  // Reset daily counter if date changed
  const today = todayString();
  if (stats.today.date !== today) {
    stats.today = { date: today, count: 0 };
  }

  stats.total++;
  stats.today.count++;
  stats.byKind[kind]             = (stats.byKind[kind]             || 0) + 1;
  stats.byDomain[domain]         = (stats.byDomain[domain]         || 0) + 1;

  // Keep last 20 recent entries
  stats.recent.unshift({ domain, kind, time: Date.now() });
  if (stats.recent.length > 20) stats.recent.pop();

  await chrome.storage.local.set({ stats });
}

// ============================================================
// BADGE — shows today's block count on the toolbar icon
// ============================================================
async function updateBadge() {
  const { settings, stats } = await chrome.storage.local.get(['settings', 'stats']);
  const enabled = settings?.enabled !== false;
  const count   = stats?.today?.count || 0;

  chrome.action.setBadgeBackgroundColor({ color: enabled ? '#06b6d4' : '#4d5566' });
  chrome.action.setBadgeText({ text: enabled ? (count > 0 ? String(count) : '') : 'OFF' });
}

// ============================================================
// HELPERS
// ============================================================
function todayString() {
  return new Date().toISOString().split('T')[0];
}

async function notifyAllTabs(message) {
  const tabs = await chrome.tabs.query({ url: ['http://*/*', 'https://*/*'] });
  for (const tab of tabs) {
    chrome.tabs.sendMessage(tab.id, message).catch(() => {}); // ignore inactive tabs
  }
}

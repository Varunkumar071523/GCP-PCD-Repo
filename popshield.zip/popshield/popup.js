'use strict';

// ============================================================
// POPUP.JS — PopShield
// ============================================================

// ── DOM refs ─────────────────────────────────────────────────
const mainView      = document.getElementById('main-view');
const settingsView  = document.getElementById('settings-view');

// Main view
const masterToggle      = document.getElementById('master-toggle');
const masterLabel       = document.getElementById('master-label');
const masterSub         = document.getElementById('master-sub');
const statToday         = document.getElementById('stat-today');
const statTotal         = document.getElementById('stat-total');
const statDomain        = document.getElementById('stat-domain');
const currentDomainEl   = document.getElementById('current-domain');
const currentDomainSub  = document.getElementById('current-domain-sub');
const toggleSiteBtn     = document.getElementById('toggle-site-btn');
const recentList        = document.getElementById('recent-list');
const zapBtn            = document.getElementById('zap-btn');
const settingsBtn       = document.getElementById('settings-btn');

// Filter toggles
const toggleWindowOpen    = document.getElementById('toggle-windowOpen');
const toggleOverlays      = document.getElementById('toggle-overlays');
const toggleCookies       = document.getElementById('toggle-cookies');
const toggleNotifications = document.getElementById('toggle-notifications');
const toggleScroll        = document.getElementById('toggle-scroll');

// Settings view
const settingsBackBtn = document.getElementById('settings-back-btn');
const clearStatsBtn   = document.getElementById('clear-stats-btn');
const wlInput         = document.getElementById('wl-input');
const wlAddBtn        = document.getElementById('wl-add-btn');
const whitelistItems  = document.getElementById('whitelist-items');
const zapRulesList    = document.getElementById('zap-rules-list');
const clearZapBtn     = document.getElementById('clear-zap-btn');
const settingsFeedback= document.getElementById('settings-feedback');

// ── Runtime state ─────────────────────────────────────────────
let currentSettings = null;
let currentStats    = null;
let currentDomain   = '';

// ============================================================
// INIT
// ============================================================
async function init() {
  // Get the domain of the active tab
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  try {
    currentDomain = new URL(tab?.url || '').hostname.replace(/^www\./, '');
  } catch {
    currentDomain = '';
  }

  // Load state from background
  const state = await chrome.runtime.sendMessage({ type: 'GET_STATE' });
  currentSettings = state.settings;
  currentStats    = state.stats;

  renderMain();
  setupTabs();
}

// ============================================================
// RENDER MAIN VIEW
// ============================================================
function renderMain() {
  const s       = currentSettings;
  const stats   = currentStats;
  const enabled = s.enabled;
  const onWL    = (s.whitelist || []).includes(currentDomain);

  // Master toggle
  masterToggle.checked  = enabled;
  masterLabel.textContent = enabled ? 'Protection ON' : 'Protection OFF';
  masterSub.textContent   = enabled
    ? (onWL ? `Disabled on ${currentDomain}` : 'Blocking popups on all sites')
    : 'Click to re-enable PopShield';

  // Stats
  const today = stats?.today?.date === todayString() ? (stats.today.count || 0) : 0;
  statToday.textContent  = today;
  statTotal.textContent  = stats?.total || 0;
  statDomain.textContent = (currentDomain && stats?.byDomain?.[currentDomain]) || 0;

  // Current site
  currentDomainEl.textContent  = currentDomain || 'No active tab';
  currentDomainSub.textContent = onWL
    ? 'PopShield disabled on this site'
    : `${stats?.byDomain?.[currentDomain] || 0} popups blocked here`;

  toggleSiteBtn.textContent = onWL ? 'Re-enable' : 'Disable here';
  toggleSiteBtn.className   = onWL
    ? 'btn btn-sm btn-primary'
    : 'btn btn-sm btn-outline';
  toggleSiteBtn.disabled = !currentDomain;

  // Filter toggles
  toggleWindowOpen.checked    = s.blockWindowOpen    !== false;
  toggleOverlays.checked      = s.blockOverlays      !== false;
  toggleCookies.checked       = s.blockCookieBanners !== false;
  toggleNotifications.checked = s.blockNotifications !== false;
  toggleScroll.checked        = s.removeScrollLocks  !== false;

  // Recent list
  renderRecent(stats?.recent || []);
}

function renderRecent(recent) {
  if (!recent.length) {
    recentList.innerHTML = '<div class="empty-state">No popups blocked yet.</div>';
    return;
  }

  const kindMeta = {
    windowOpen:   { icon: '🪟', label: 'Popup window' },
    overlay:      { icon: '🔲', label: 'Overlay'      },
    cookie:       { icon: '🍪', label: 'Cookie banner' },
    notification: { icon: '🔔', label: 'Notification'  },
    zap:          { icon: '⚡', label: 'Zapped'        },
  };

  recentList.innerHTML = recent.slice(0, 8).map(item => {
    const meta    = kindMeta[item.kind] || { icon: '🚫', label: item.kind };
    const timeAgo = formatTimeAgo(item.time);
    return `
      <div class="recent-item">
        <span class="ri-kind">${meta.icon}</span>
        <span class="ri-domain">${item.domain}</span>
        <span class="kind-chip kind-${item.kind}">${meta.label}</span>
        <span class="ri-time">${timeAgo}</span>
      </div>`;
  }).join('');
}

// ============================================================
// MASTER TOGGLE
// ============================================================
masterToggle.addEventListener('change', async () => {
  currentSettings.enabled = masterToggle.checked;
  await saveSettings();
  renderMain();
});

// ============================================================
// TOGGLE CURRENT SITE
// ============================================================
toggleSiteBtn.addEventListener('click', async () => {
  if (!currentDomain) return;
  const onWL = (currentSettings.whitelist || []).includes(currentDomain);
  await chrome.runtime.sendMessage({
    type:   'TOGGLE_SITE',
    domain: currentDomain,
    block:  onWL,  // if currently whitelisted, re-block; else whitelist
  });
  // Reload settings
  const state = await chrome.runtime.sendMessage({ type: 'GET_STATE' });
  currentSettings = state.settings;
  renderMain();
});

// ============================================================
// FILTER TOGGLES
// ============================================================
const filterMap = {
  'toggle-windowOpen':    'blockWindowOpen',
  'toggle-overlays':      'blockOverlays',
  'toggle-cookies':       'blockCookieBanners',
  'toggle-notifications': 'blockNotifications',
  'toggle-scroll':        'removeScrollLocks',
};

Object.entries(filterMap).forEach(([id, key]) => {
  document.getElementById(id).addEventListener('change', async (e) => {
    currentSettings[key] = e.target.checked;
    await saveSettings();
  });
});

// ============================================================
// ZAP BUTTON — activates element picker on the current tab
// ============================================================
zapBtn.addEventListener('click', async () => {
  await chrome.runtime.sendMessage({ type: 'START_ZAP_MODE' });
  window.close(); // Close popup so the user can interact with the page
});

// ============================================================
// TABS
// ============================================================
function setupTabs() {
  document.querySelectorAll('.tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
      document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
      tab.classList.add('active');
      document.getElementById(`tab-${tab.dataset.tab}`).classList.add('active');
    });
  });
}

// ============================================================
// SETTINGS VIEW
// ============================================================
settingsBtn.addEventListener('click', () => {
  mainView.classList.add('hidden');
  settingsView.classList.remove('hidden');
  renderSettingsView();
});

settingsBackBtn.addEventListener('click', () => {
  settingsView.classList.add('hidden');
  mainView.classList.remove('hidden');
});

function renderSettingsView() {
  renderWhitelist();
  renderZapRules();
  clearFeedback();
}

// ── Whitelist ────────────────────────────────────────────────
function renderWhitelist() {
  const wl = currentSettings.whitelist || [];
  if (wl.length === 0) {
    whitelistItems.innerHTML = '<div class="empty-state" style="padding:8px 0;">No sites whitelisted.</div>';
    return;
  }
  whitelistItems.innerHTML = wl.map(domain => `
    <div class="wl-item">
      <span class="wl-domain">${domain}</span>
      <span class="wl-remove" data-domain="${domain}" title="Remove">×</span>
    </div>`).join('');

  whitelistItems.querySelectorAll('.wl-remove').forEach(btn => {
    btn.addEventListener('click', async () => {
      currentSettings.whitelist = currentSettings.whitelist.filter(d => d !== btn.dataset.domain);
      await saveSettings();
      renderWhitelist();
      showFeedback(`Removed ${btn.dataset.domain}`, 'ok');
    });
  });
}

wlAddBtn.addEventListener('click', addToWhitelist);
wlInput.addEventListener('keydown', e => { if (e.key === 'Enter') addToWhitelist(); });

async function addToWhitelist() {
  let domain = wlInput.value.trim().toLowerCase()
    .replace(/^https?:\/\//i, '').replace(/^www\./i, '').split('/')[0];

  if (!domain || !domain.includes('.')) {
    showFeedback('Enter a valid domain (e.g. mysite.com)', 'error');
    return;
  }
  if ((currentSettings.whitelist || []).includes(domain)) {
    showFeedback(`${domain} is already whitelisted.`, 'error');
    return;
  }

  currentSettings.whitelist = [...(currentSettings.whitelist || []), domain];
  await saveSettings();
  wlInput.value = '';
  renderWhitelist();
  showFeedback(`✓ ${domain} whitelisted`, 'ok');
}

// ── Zap rules ────────────────────────────────────────────────
function renderZapRules() {
  const rules = currentSettings.zapRules || {};
  const domains = Object.keys(rules).filter(d => rules[d]?.length > 0);

  if (domains.length === 0) {
    zapRulesList.innerHTML = '<div class="empty-state" style="padding:8px 0;">No saved zap rules yet.<br>Use the Zap button to click elements to hide.</div>';
    return;
  }

  zapRulesList.innerHTML = domains.map(domain => `
    <div class="wl-item" style="flex-direction:column;align-items:flex-start;gap:4px;">
      <div style="display:flex;justify-content:space-between;width:100%;">
        <span class="wl-domain">${domain}</span>
        <span class="wl-remove" data-domain="${domain}" title="Clear all rules for this site">×</span>
      </div>
      <span style="font-size:10px;color:var(--text-muted);">${rules[domain].length} rule${rules[domain].length !== 1 ? 's' : ''}</span>
    </div>`).join('');

  zapRulesList.querySelectorAll('.wl-remove').forEach(btn => {
    btn.addEventListener('click', async () => {
      delete currentSettings.zapRules[btn.dataset.domain];
      await saveSettings();
      renderZapRules();
    });
  });
}

clearZapBtn.addEventListener('click', async () => {
  currentSettings.zapRules = {};
  await saveSettings();
  renderZapRules();
  showFeedback('All zap rules cleared.', 'ok');
});

// ── Clear stats ──────────────────────────────────────────────
clearStatsBtn.addEventListener('click', async () => {
  await chrome.runtime.sendMessage({ type: 'CLEAR_STATS' });
  const state = await chrome.runtime.sendMessage({ type: 'GET_STATE' });
  currentStats = state.stats;
  showFeedback('Stats cleared.', 'ok');
});

// ============================================================
// SAVE SETTINGS
// ============================================================
async function saveSettings() {
  await chrome.runtime.sendMessage({ type: 'SAVE_SETTINGS', settings: currentSettings });
}

// ============================================================
// HELPERS
// ============================================================
function showFeedback(msg, type) {
  settingsFeedback.textContent = msg;
  settingsFeedback.className   = `feedback feedback-${type}`;
  settingsFeedback.classList.remove('hidden');
  if (type === 'ok') setTimeout(clearFeedback, 2500);
}

function clearFeedback() {
  settingsFeedback.textContent = '';
  settingsFeedback.classList.add('hidden');
}

function todayString() {
  return new Date().toISOString().split('T')[0];
}

function formatTimeAgo(ts) {
  if (!ts) return '';
  const diff = Date.now() - ts;
  if (diff < 60000)  return 'just now';
  if (diff < 3600000) return `${Math.floor(diff / 60000)}m ago`;
  if (diff < 86400000) return `${Math.floor(diff / 3600000)}h ago`;
  return `${Math.floor(diff / 86400000)}d ago`;
}

// ============================================================
// START
// ============================================================
init();

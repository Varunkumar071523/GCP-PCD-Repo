'use strict';

// ============================================================
// CONTENT.JS — injected into every web page.
//
// In Lockin's current design, blocking is handled entirely by
// background.js redirecting the tab to blocked.html — so this
// script is intentionally lightweight.
//
// It listens for a SHOW_CHECKING message from background.js,
// which can optionally show a brief "Checking…" overlay while
// the async AI decision is in flight (useful on slow connections).
// ============================================================

let overlay = null;

chrome.runtime.onMessage.addListener((message) => {
  if (message.type === 'SHOW_CHECKING') {
    showCheckingOverlay();
  }
  if (message.type === 'HIDE_CHECKING') {
    removeOverlay();
  }
});

function showCheckingOverlay() {
  if (overlay) return; // Already showing

  overlay = document.createElement('div');
  overlay.id = 'lockin-checking-overlay';
  overlay.style.cssText = `
    position: fixed;
    inset: 0;
    background: rgba(13, 17, 23, 0.88);
    backdrop-filter: blur(4px);
    z-index: 2147483647;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 14px;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', system-ui, sans-serif;
    color: #e6edf3;
  `;

  overlay.innerHTML = `
    <div style="
      width: 44px; height: 44px;
      border: 3px solid #30363d;
      border-top-color: #f59e0b;
      border-radius: 50%;
      animation: lockin-spin 0.7s linear infinite;
    "></div>
    <p style="font-size:15px; font-weight:600; color:#e6edf3; margin:0;">
      Checking relevance…
    </p>
    <p style="font-size:13px; color:#7d8590; margin:0;">
      Lockin is deciding if this helps your goal
    </p>
    <style>
      @keyframes lockin-spin {
        to { transform: rotate(360deg); }
      }
    </style>
  `;

  document.documentElement.appendChild(overlay);
}

function removeOverlay() {
  if (overlay) {
    overlay.remove();
    overlay = null;
  }
}

'use strict';

// ============================================================
// POPUP.JS — controls which screen is visible and handles
// all user interactions in the extension popup.
// ============================================================

const FREE_SESSION_LIMIT_MIN = 30;

// ── DOM refs ─────────────────────────────────────────────────
const screens = {
  setup:    document.getElementById('screen-setup'),
  idle:     document.getElementById('screen-idle'),
  active:   document.getElementById('screen-active'),
  summary:  document.getElementById('screen-summary'),
  settings: document.getElementById('screen-settings'),
};

// Setup screen
const setupApiKeyInput = document.getElementById('setup-api-key');
const setupSaveBtn     = document.getElementById('setup-save-btn');

// Idle screen
const taskInput              = document.getElementById('task-input');
const charCount              = document.getElementById('char-count');
const startBtn               = document.getElementById('start-btn');
const idleTierBadge          = document.getElementById('idle-tier-badge');
const idleSettingsBtn        = document.getElementById('idle-settings-btn');
const sessionsRemainingLabel = document.getElementById('sessions-remaining-label');
const idleFeedback           = document.getElementById('idle-feedback');
const idleLastSummary        = document.getElementById('idle-last-summary');
const idleLastSummaryText    = document.getElementById('idle-last-summary-text');

// Active screen
const timerDisplay      = document.getElementById('timer-display');
const activeTaskText    = document.getElementById('active-task-text');
const statAllowed       = document.getElementById('stat-allowed');
const statBlocked       = document.getElementById('stat-blocked');
const statBreaks        = document.getElementById('stat-breaks');
const endBtn            = document.getElementById('end-btn');
const freeTierBarWrap   = document.getElementById('free-tier-bar-wrap');
const freeTierBar       = document.getElementById('free-tier-bar');
const freeTierBarLabel  = document.getElementById('free-tier-bar-label');

// Summary screen
const summaryDuration  = document.getElementById('summary-duration');
const summaryAllowed   = document.getElementById('summary-allowed');
const summaryBlocked   = document.getElementById('summary-blocked');
const summaryMessage   = document.getElementById('summary-message');
const summaryTaskChip  = document.getElementById('summary-task-chip');
const newSessionBtn    = document.getElementById('new-session-btn');

// Settings screen
const settingsBackBtn    = document.getElementById('settings-back-btn');
const settingsApiKeyInput= document.getElementById('settings-api-key');
const settingsSaveKeyBtn = document.getElementById('settings-save-key-btn');
const licenseKeyInput    = document.getElementById('license-key-input');
const activateProBtn     = document.getElementById('activate-pro-btn');
const proStatusBadge     = document.getElementById('pro-status-badge');
const proUnlockSection   = document.getElementById('pro-unlock-section');
const proActiveSection   = document.getElementById('pro-active-section');
const settingsTierBadge  = document.getElementById('settings-tier-badge');
const usageCount         = document.getElementById('usage-count');
const settingsFeedback   = document.getElementById('settings-feedback');

// ── State ─────────────────────────────────────────────────────
let timerInterval    = null;
let statsInterval    = null;
let previousScreen   = 'idle'; // so Settings knows where to go back

// ============================================================
// INIT — runs when popup opens
// ============================================================
async function init() {
  const data = await chrome.storage.local.get([
    'apiKey', 'activeSession', 'task', 'startTime',
    'lastSessionSummary', 'sessionsToday', 'lastResetDate', 'isPro'
  ]);

  // Reset daily counter when date has changed
  const today = todayString();
  if (data.lastResetDate !== today) {
    await chrome.storage.local.set({ sessionsToday: 0, lastResetDate: today });
    data.sessionsToday = 0;
  }

  // Route to the right screen
  if (!data.apiKey) {
    showScreen('setup');
    return;
  }

  if (data.activeSession) {
    showScreen('active');
    populateActiveScreen(data);
    return;
  }

  if (data.lastSessionSummary && isRecent(data.lastSessionSummary.endTime)) {
    showScreen('summary');
    populateSummaryScreen(data.lastSessionSummary);
    return;
  }

  showScreen('idle');
  populateIdleScreen(data);
}

// ============================================================
// SCREEN SWITCHING
// ============================================================
function showScreen(name) {
  Object.values(screens).forEach(s => s.classList.add('hidden'));
  screens[name].classList.remove('hidden');
}

// ============================================================
// SCREEN: SETUP
// ============================================================
setupSaveBtn.addEventListener('click', async () => {
  const key = setupApiKeyInput.value.trim();
  if (!key.startsWith('sk-')) {
    setupApiKeyInput.style.borderColor = 'var(--danger)';
    return;
  }
  setupApiKeyInput.style.borderColor = '';
  await chrome.runtime.sendMessage({ type: 'SAVE_API_KEY', apiKey: key });
  const data = await chrome.storage.local.get(['sessionsToday', 'lastResetDate', 'isPro']);
  showScreen('idle');
  populateIdleScreen(data);
});

// ============================================================
// SCREEN: IDLE
// ============================================================
function populateIdleScreen(data) {
  // Tier badge
  if (data.isPro) {
    idleTierBadge.textContent = '⭐ PRO';
    idleTierBadge.className   = 'badge badge-pro';
  } else {
    idleTierBadge.textContent = 'FREE';
    idleTierBadge.className   = 'badge badge-free';
  }

  // Sessions remaining for free tier
  if (!data.isPro) {
    const used = data.sessionsToday || 0;
    const left = Math.max(0, 2 - used);
    sessionsRemainingLabel.innerHTML =
      `<span>${left}</span> free session${left !== 1 ? 's' : ''} remaining today`;
    sessionsRemainingLabel.style.color = left === 0 ? 'var(--danger)' : '';
  } else {
    sessionsRemainingLabel.textContent = 'Unlimited sessions — Pro';
    sessionsRemainingLabel.style.color = 'var(--accent)';
  }

  // Last session mini-chip
  if (data.lastSessionSummary) {
    const s = data.lastSessionSummary;
    idleLastSummaryText.textContent =
      `Last: ${s.durationMin}min — blocked ${s.blocked} distractions`;
    idleLastSummary.classList.remove('hidden');
  }
}

// Character counter for task input
taskInput.addEventListener('input', () => {
  const len = taskInput.value.length;
  charCount.textContent = `${len} / 120`;
  charCount.style.color = len > 100 ? 'var(--accent)' : '';
});

// Start session
startBtn.addEventListener('click', async () => {
  const task = taskInput.value.trim();
  if (task.length < 3) {
    showFeedback(idleFeedback, 'Please describe your task (at least 3 characters)', 'error');
    taskInput.focus();
    return;
  }

  startBtn.disabled = true;
  startBtn.textContent = 'Starting…';

  const result = await chrome.runtime.sendMessage({ type: 'START_SESSION', task });

  if (!result.ok) {
    startBtn.disabled = false;
    startBtn.textContent = '🚀 Start Focus Session';
    const msgs = {
      no_api_key:   'No API key set — go to Settings.',
      daily_limit:  'You\'ve used your 2 free sessions today. Upgrade to Pro for unlimited sessions.',
      no_task:      'Please describe what you\'re working on.',
    };
    showFeedback(idleFeedback, msgs[result.error] || result.error, 'error');
    return;
  }

  // Transition to active screen
  const data = await chrome.storage.local.get(['task', 'startTime', 'sessionStats', 'isPro']);
  showScreen('active');
  populateActiveScreen({ ...data, activeSession: true });
});

// Settings button from idle screen
idleSettingsBtn.addEventListener('click', () => {
  previousScreen = 'idle';
  openSettings();
});

// ============================================================
// SCREEN: ACTIVE SESSION
// ============================================================
function populateActiveScreen(data) {
  clearTimers();

  activeTaskText.textContent = data.task || '—';

  // Show free-tier progress bar if not Pro
  if (!data.isPro) {
    freeTierBarWrap.classList.remove('hidden');
  }

  // Start live timer
  timerInterval = setInterval(() => {
    updateTimerAndBar(data.startTime, data.isPro);
  }, 1000);
  updateTimerAndBar(data.startTime, data.isPro);

  // Poll stats every 2 seconds so the popup stays live
  statsInterval = setInterval(refreshStats, 2000);
  refreshStats();
}

function updateTimerAndBar(startTime, isPro) {
  const elapsedMs  = Date.now() - (startTime || Date.now());
  const elapsedSec = Math.floor(elapsedMs / 1000);
  const minutes    = Math.floor(elapsedSec / 60);
  const seconds    = elapsedSec % 60;

  timerDisplay.textContent =
    `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;

  if (!isPro) {
    const pct = Math.min(100, (elapsedMs / (FREE_SESSION_LIMIT_MIN * 60 * 1000)) * 100);
    freeTierBar.style.width   = pct + '%';
    freeTierBarLabel.textContent =
      `${minutes} / ${FREE_SESSION_LIMIT_MIN} min`;
    // Turn bar red in last 5 minutes
    freeTierBar.style.background = pct >= 83 ? 'var(--danger)' : 'var(--accent)';
  }
}

async function refreshStats() {
  const data = await chrome.storage.local.get(['sessionStats', 'activeSession']);

  // If the session was auto-ended (e.g. 30-min limit hit), switch to summary
  if (!data.activeSession) {
    clearTimers();
    const summaryData = await chrome.storage.local.get(['lastSessionSummary']);
    if (summaryData.lastSessionSummary) {
      showScreen('summary');
      populateSummaryScreen(summaryData.lastSessionSummary);
    }
    return;
  }

  const s = data.sessionStats || { allowed: 0, blocked: 0, breakRequests: 0 };
  statAllowed.textContent = s.allowed       || 0;
  statBlocked.textContent = s.blocked       || 0;
  statBreaks.textContent  = s.breakRequests || 0;
}

// End session button
endBtn.addEventListener('click', async () => {
  endBtn.disabled = true;
  endBtn.textContent = 'Ending…';

  const result = await chrome.runtime.sendMessage({ type: 'END_SESSION' });

  clearTimers();

  if (result.ok) {
    showScreen('summary');
    populateSummaryScreen(result.summary);
  }
});

// ============================================================
// SCREEN: SUMMARY
// ============================================================
function populateSummaryScreen(summary) {
  summaryDuration.textContent = summary.durationMin || 0;
  summaryAllowed.textContent  = summary.allowed      || 0;
  summaryBlocked.textContent  = summary.blocked      || 0;

  // Task chip
  summaryTaskChip.textContent = summary.task
    ? `🎯 ${summary.task}`
    : 'Session complete';

  // Motivational message
  const mins       = summary.durationMin || 0;
  const distractions = summary.blocked || 0;
  const breaks     = summary.breakRequests || 0;

  let msg = `You focused for ${mins} minute${mins !== 1 ? 's' : ''}`;
  if (distractions > 0) {
    msg += ` and resisted ${distractions} distraction${distractions !== 1 ? 's' : ''}`;
  }
  if (breaks > 0) {
    msg += ` (took ${breaks} quick break${breaks !== 1 ? 's' : ''})`;
  }
  msg += '. ' + pickMotivation(distractions, mins);

  summaryMessage.textContent = msg;
}

function pickMotivation(distractions, minutes) {
  if (minutes >= 25) return 'Outstanding deep work session! 🔥';
  if (distractions >= 5) return 'You resisted the urge every time — that\'s real discipline. 💪';
  if (distractions >= 2) return 'Every blocked distraction is a win. Keep building the habit! ✨';
  if (minutes >= 10)     return 'Solid session — consistency beats perfection. 🌱';
  return 'Every minute of focus counts. Great start! 🚀';
}

newSessionBtn.addEventListener('click', async () => {
  await chrome.runtime.sendMessage({ type: 'CLEAR_SUMMARY' });
  const data = await chrome.storage.local.get(['sessionsToday', 'lastResetDate', 'isPro', 'lastSessionSummary']);
  showScreen('idle');
  populateIdleScreen(data);
  taskInput.focus();
});

// ============================================================
// SCREEN: SETTINGS
// ============================================================
async function openSettings() {
  const data = await chrome.storage.local.get(['apiKey', 'isPro', 'sessionsToday', 'lastResetDate']);

  // Mask the existing API key
  if (data.apiKey) {
    settingsApiKeyInput.value       = '';
    settingsApiKeyInput.placeholder = data.apiKey.slice(0, 8) + '••••••••••••••••';
  }

  // Tier badges
  if (data.isPro) {
    settingsTierBadge.textContent = '⭐ PRO';
    settingsTierBadge.className   = 'badge badge-pro';
    proStatusBadge.textContent    = '⭐ PRO';
    proStatusBadge.className      = 'badge badge-pro';
    proUnlockSection.classList.add('hidden');
    proActiveSection.classList.remove('hidden');
  } else {
    settingsTierBadge.textContent = 'FREE';
    settingsTierBadge.className   = 'badge badge-free';
    proStatusBadge.textContent    = 'FREE';
    proStatusBadge.className      = 'badge badge-free';
    proUnlockSection.classList.remove('hidden');
    proActiveSection.classList.add('hidden');
  }

  // Usage counter
  const today = todayString();
  const used  = (data.lastResetDate === today ? data.sessionsToday : 0) || 0;
  usageCount.textContent = data.isPro ? '∞' : `${used} / 2`;

  clearFeedback(settingsFeedback);
  showScreen('settings');
}

settingsBackBtn.addEventListener('click', () => {
  showScreen(previousScreen);
});

settingsSaveKeyBtn.addEventListener('click', async () => {
  const key = settingsApiKeyInput.value.trim();
  if (!key) {
    showFeedback(settingsFeedback, 'Enter a new key to update it.', 'error');
    return;
  }
  if (!key.startsWith('sk-')) {
    showFeedback(settingsFeedback, 'That doesn\'t look like a valid Claude API key.', 'error');
    return;
  }
  await chrome.runtime.sendMessage({ type: 'SAVE_API_KEY', apiKey: key });
  settingsApiKeyInput.value       = '';
  settingsApiKeyInput.placeholder = key.slice(0, 8) + '••••••••••••••••';
  showFeedback(settingsFeedback, '✓ API key saved!', 'ok');
});

activateProBtn.addEventListener('click', async () => {
  const key = licenseKeyInput.value.trim();
  if (!key) {
    showFeedback(settingsFeedback, 'Enter your license key.', 'error');
    return;
  }
  activateProBtn.disabled = true;
  activateProBtn.textContent = '…';

  const result = await chrome.runtime.sendMessage({ type: 'ACTIVATE_PRO', licenseKey: key });

  activateProBtn.disabled = false;
  activateProBtn.textContent = 'Activate';

  if (result.ok) {
    // Update UI to show Pro
    settingsTierBadge.textContent = '⭐ PRO';
    settingsTierBadge.className   = 'badge badge-pro';
    proStatusBadge.textContent    = '⭐ PRO';
    proStatusBadge.className      = 'badge badge-pro';
    proUnlockSection.classList.add('hidden');
    proActiveSection.classList.remove('hidden');
    usageCount.textContent = '∞';
    showFeedback(settingsFeedback, '⭐ Pro activated! All limits removed.', 'ok');
  } else {
    showFeedback(settingsFeedback, '✗ Invalid license key. Try LOCKIN-PRO-2024 to test.', 'error');
  }
});

// ============================================================
// HELPERS
// ============================================================
function showFeedback(el, msg, type) {
  el.textContent  = msg;
  el.className    = `feedback feedback-${type === 'ok' ? 'ok' : 'error'}`;
  el.classList.remove('hidden');
  // Auto-clear success messages after 3 seconds
  if (type === 'ok') {
    setTimeout(() => clearFeedback(el), 3000);
  }
}

function clearFeedback(el) {
  el.textContent = '';
  el.classList.add('hidden');
}

function clearTimers() {
  clearInterval(timerInterval);
  clearInterval(statsInterval);
  timerInterval = null;
  statsInterval = null;
}

function todayString() {
  return new Date().toISOString().split('T')[0];
}

// A summary is "recent" if it was created within the last 5 minutes
function isRecent(endTime) {
  return endTime && (Date.now() - endTime < 5 * 60 * 1000);
}

// ============================================================
// KICK OFF
// ============================================================
init();

'use strict';

// ============================================================
// CONFIGURATION
// ============================================================

// Use Haiku for ALLOW/BLOCK decisions — it's fast and cheap.
// Change to 'claude-sonnet-4-6' if you want more nuanced judgments.
const AI_MODEL = 'claude-haiku-4-5-20251001';
const API_ENDPOINT = 'https://api.anthropic.com/v1/messages';

const FREE_SESSION_LIMIT_MIN = 30;    // Max session length on free tier
const FREE_SESSIONS_PER_DAY   = 2;    // Max sessions/day on free tier

// Valid Pro license keys (expand this list when you sell keys)
const VALID_PRO_KEYS = ['LOCKIN-PRO-2024'];

// ============================================================
// IN-MEMORY STATE
// Service workers can be killed and restarted by Chrome at any time.
// We rebuild these from chrome.storage on init().
// ============================================================
let domainCache = {};   // { 'reddit.com': { decision: 'ALLOW'|'BLOCK', reason: '...' } }
let tempPasses  = {};   // { 'reddit.com': 1716000000000 }  ← expiry timestamp

// ============================================================
// INIT — called every time the service worker wakes up
// ============================================================
async function init() {
  try {
    const data = await chrome.storage.local.get(['activeSession', 'domainCache', 'tempPasses']);
    if (data.activeSession) {
      domainCache = data.domainCache || {};
      tempPasses  = data.tempPasses  || {};
    }
  } catch (e) {
    console.error('[Lockin] init error:', e);
  }
}
init();

// ============================================================
// NAVIGATION INTERCEPTOR — fires before any HTTP request is made
// ============================================================
chrome.webNavigation.onBeforeNavigate.addListener(async (details) => {

  // Only intercept top-level tab navigations (not iframes, images, etc.)
  if (details.frameId !== 0) return;

  // Skip chrome://, about:, data:, and our own extension pages
  const url = details.url;
  if (!url.startsWith('http://') && !url.startsWith('https://')) return;
  if (url.includes(chrome.runtime.id)) return;   // Our own blocked.html page

  // Pull session state from storage
  const storage = await chrome.storage.local.get([
    'activeSession', 'task', 'startTime', 'isPro', 'apiKey'
  ]);

  // Nothing to do if no session is running
  if (!storage.activeSession) return;

  // ── Free tier: auto-end session if 30 minutes have elapsed ──────────────
  if (!storage.isPro) {
    const elapsed = Date.now() - (storage.startTime || Date.now());
    if (elapsed >= FREE_SESSION_LIMIT_MIN * 60 * 1000) {
      await endSession(true);
      return;
    }
  }

  // Extract bare domain (strip www.)
  let domain;
  try {
    domain = new URL(url).hostname.replace(/^www\./, '');
  } catch {
    return; // Malformed URL — skip
  }

  // ── Check for an active temp pass ───────────────────────────────────────
  if (tempPasses[domain]) {
    if (tempPasses[domain] > Date.now()) {
      return; // Valid 5-min pass → let them through
    }
    delete tempPasses[domain]; // Expired — remove it
  }

  // ── Check the per-session domain cache ──────────────────────────────────
  if (domainCache[domain]) {
    if (domainCache[domain].decision === 'BLOCK') {
      redirectToBlocked(details.tabId, url, domain, domainCache[domain].reason, storage.task);
    }
    return; // Cached decision (ALLOW or BLOCK already handled)
  }

  // ── New domain — ask Claude ──────────────────────────────────────────────
  if (!storage.apiKey) {
    // No API key set: fail safe (allow page), nudge user in console
    console.warn('[Lockin] No API key set — allowing page. Open the extension to add your key.');
    return;
  }

  try {
    const result = await callClaudeAPI(storage.task, domain, storage.apiKey);

    // Cache the decision for this domain for the rest of the session
    domainCache[domain] = result;
    await chrome.storage.local.set({ domainCache });

    // Update session stats
    await incrementStat(result.decision === 'ALLOW' ? 'allowed' : 'blocked');

    if (result.decision === 'BLOCK') {
      redirectToBlocked(details.tabId, url, domain, result.reason, storage.task);
    }
  } catch (err) {
    // ⚠️ FAIL SAFE: if AI check errors for any reason, allow the page.
    // We never want to trap the user due to a network or API issue.
    console.error('[Lockin] AI check failed — allowing page. Error:', err.message);
  }
});

// ============================================================
// CLAUDE API CALL
// Sends: task + domain  →  Receives: ALLOW or BLOCK + short reason
// We send ONLY the domain, never page content. Privacy-first.
// ============================================================
async function callClaudeAPI(task, domain, apiKey) {
  const prompt =
`You are a focus assistant helping someone stay productive.

Their current task: "${task}"
They are about to visit: ${domain}

Decide: is this website relevant to their task (ALLOW) or a distraction (BLOCK)?

Reply with EXACTLY one line — no preamble, no explanation, just:
ALLOW - [6-word reason]
  OR
BLOCK - [6-word reason]`;

  const response = await fetch(API_ENDPOINT, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': apiKey,
      'anthropic-version': '2023-06-01',
    },
    body: JSON.stringify({
      model: AI_MODEL,
      max_tokens: 60,
      messages: [{ role: 'user', content: prompt }]
    })
  });

  if (!response.ok) {
    const body = await response.text();
    throw new Error(`HTTP ${response.status}: ${body.slice(0, 200)}`);
  }

  const data  = await response.json();
  const text  = (data.content?.[0]?.text || '').trim();
  const upper = text.toUpperCase();

  if (upper.startsWith('ALLOW')) {
    const reason = text.replace(/^ALLOW\s*[-–]\s*/i, '').trim() || 'Relevant to your task';
    return { decision: 'ALLOW', reason };
  }
  if (upper.startsWith('BLOCK')) {
    const reason = text.replace(/^BLOCK\s*[-–]\s*/i, '').trim() || 'Not relevant to your task';
    return { decision: 'BLOCK', reason };
  }

  // Unexpected format — fail safe
  console.warn('[Lockin] Unexpected AI response format, allowing. Got:', text);
  return { decision: 'ALLOW', reason: 'Could not parse AI response' };
}

// ============================================================
// REDIRECT TO BLOCKED PAGE
// Passes context as URL params so blocked.html can render it
// ============================================================
function redirectToBlocked(tabId, originalUrl, domain, reason, task) {
  const blockedUrl =
    chrome.runtime.getURL('blocked.html') +
    '?url='    + encodeURIComponent(originalUrl) +
    '&domain=' + encodeURIComponent(domain) +
    '&reason=' + encodeURIComponent(reason) +
    '&task='   + encodeURIComponent(task);

  chrome.tabs.update(tabId, { url: blockedUrl }).catch(err =>
    console.error('[Lockin] Tab redirect failed:', err)
  );
}

// ============================================================
// MESSAGE HANDLER — receives requests from popup.js and blocked.html
// ============================================================
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {

  const handle = async () => {
    switch (message.type) {

      case 'START_SESSION':
        return startSession(message.task);

      case 'END_SESSION':
        return endSession(false);

      case 'REQUEST_TEMP_PASS':
        return grantTempPass(message.domain, message.reason);

      case 'GET_STATS':
        return getStats();

      case 'SAVE_API_KEY':
        await chrome.storage.local.set({ apiKey: message.apiKey.trim() });
        return { ok: true };

      case 'ACTIVATE_PRO':
        return activatePro(message.licenseKey);

      case 'CLEAR_SUMMARY':
        await chrome.storage.local.set({ lastSessionSummary: null });
        return { ok: true };

      default:
        return { ok: false, error: 'unknown_message_type' };
    }
  };

  handle()
    .then(sendResponse)
    .catch(err => {
      console.error('[Lockin] Message handler error:', err);
      sendResponse({ ok: false, error: err.message });
    });

  return true; // Keep the message channel open for async response
});

// ============================================================
// SESSION: START
// ============================================================
async function startSession(task) {
  const storage = await chrome.storage.local.get([
    'isPro', 'sessionsToday', 'lastResetDate', 'apiKey'
  ]);

  if (!storage.apiKey) {
    return { ok: false, error: 'no_api_key' };
  }

  if (!task || task.trim().length < 3) {
    return { ok: false, error: 'no_task' };
  }

  // Reset daily counter when the calendar date changes
  const today = todayString();
  let sessionsToday = storage.sessionsToday || 0;
  if (storage.lastResetDate !== today) {
    sessionsToday = 0;
  }

  // Free tier: enforce 2-sessions/day cap
  if (!storage.isPro && sessionsToday >= FREE_SESSIONS_PER_DAY) {
    return { ok: false, error: 'daily_limit' };
  }

  // Reset in-memory cache for this new session
  domainCache = {};
  tempPasses  = {};

  const startTime = Date.now();

  await chrome.storage.local.set({
    activeSession:      true,
    task:               task.trim(),
    startTime,
    domainCache:        {},
    tempPasses:         {},
    sessionStats:       { allowed: 0, blocked: 0, breakRequests: 0 },
    sessionsToday:      sessionsToday + 1,
    lastResetDate:      today,
    lastSessionSummary: null,
  });

  // Set an alarm that auto-ends the session for free tier users
  if (!storage.isPro) {
    chrome.alarms.create('sessionTimeLimit', {
      delayInMinutes: FREE_SESSION_LIMIT_MIN
    });
  }

  return { ok: true, startTime };
}

// ============================================================
// SESSION: END
// ============================================================
async function endSession(autoEnded = false) {
  const storage = await chrome.storage.local.get(['sessionStats', 'startTime', 'task']);

  const now        = Date.now();
  const durationMs = now - (storage.startTime || now);
  const stats      = storage.sessionStats || { allowed: 0, blocked: 0, breakRequests: 0 };

  const summary = {
    task:          storage.task || '',
    durationMin:   Math.max(0, Math.round(durationMs / 60000)),
    durationSec:   Math.max(0, Math.round(durationMs / 1000)),
    allowed:       stats.allowed       || 0,
    blocked:       stats.blocked       || 0,
    breakRequests: stats.breakRequests || 0,
    endTime:       now,
    autoEnded,
  };

  // Reset in-memory state
  domainCache = {};
  tempPasses  = {};

  await chrome.storage.local.set({
    activeSession:      false,
    task:               '',
    startTime:          null,
    domainCache:        {},
    tempPasses:         {},
    lastSessionSummary: summary,
  });

  chrome.alarms.clear('sessionTimeLimit');

  return { ok: true, summary };
}

// ============================================================
// TEMP PASS: grant 5 minutes on a domain
// ============================================================
async function grantTempPass(domain, reason) {
  const FIVE_MIN = 5 * 60 * 1000;
  tempPasses[domain] = Date.now() + FIVE_MIN;

  await chrome.storage.local.set({ tempPasses });

  // Log this as a break request in session stats
  const { sessionStats } = await chrome.storage.local.get('sessionStats');
  const stats = sessionStats || { allowed: 0, blocked: 0, breakRequests: 0 };
  stats.breakRequests = (stats.breakRequests || 0) + 1;
  await chrome.storage.local.set({ sessionStats: stats });

  return { ok: true, expiresAt: tempPasses[domain] };
}

// ============================================================
// GET STATS — snapshot of current state for popup
// ============================================================
async function getStats() {
  const data = await chrome.storage.local.get([
    'activeSession', 'task', 'startTime', 'sessionStats',
    'isPro', 'lastSessionSummary', 'sessionsToday', 'lastResetDate', 'apiKey'
  ]);
  return { ok: true, ...data };
}

// ============================================================
// PRO ACTIVATION
// ============================================================
async function activatePro(licenseKey) {
  const key = (licenseKey || '').trim().toUpperCase();
  if (VALID_PRO_KEYS.includes(key)) {
    await chrome.storage.local.set({ isPro: true, licenseKey: key });
    return { ok: true };
  }
  return { ok: false, error: 'invalid_key' };
}

// ============================================================
// HELPER: increment a field in sessionStats
// ============================================================
async function incrementStat(field) {
  const { sessionStats } = await chrome.storage.local.get('sessionStats');
  const stats = sessionStats || { allowed: 0, blocked: 0, breakRequests: 0 };
  stats[field] = (stats[field] || 0) + 1;
  await chrome.storage.local.set({ sessionStats: stats });
}

// ============================================================
// HELPER: returns today as "YYYY-MM-DD"
// ============================================================
function todayString() {
  return new Date().toISOString().split('T')[0];
}

// ============================================================
// ALARM: auto-end free-tier session at 30 minutes
// ============================================================
chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name !== 'sessionTimeLimit') return;

  await endSession(true);

  // Best-effort notification (requires 'notifications' permission)
  try {
    chrome.notifications.create('sessionEnded', {
      type:    'basic',
      iconUrl: chrome.runtime.getURL('icons/icon48.png'),
      title:   'Lockin — Session Complete!',
      message: `Your ${FREE_SESSION_LIMIT_MIN}-min focus session just ended. Check your stats!`
    });
  } catch (e) { /* silently ignore if notifications unavailable */ }
});

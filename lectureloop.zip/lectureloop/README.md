# 📚 LectureLoop

**Turn YouTube lectures into exam-ready study notes & flashcards.**

LectureLoop is a Chrome extension built specifically for students — school,
college, and competitive-exam aspirants (JEE / NEET / UPSC) — who learn from
long YouTube lectures. It is **not** a generic video summarizer. It produces
structured, revision-friendly study material and auto-generates flashcards, in
English *and* major Indian languages.

> 🔒 **100% private. No account. No login.** You bring your own Claude API key,
> and nothing ever leaves your browser except the call to the AI API.

---

## ✨ Features

### Study-note format (not just a paragraph)
- **📝 Quick Revision Notes** — clean bullet hierarchy, like class notes
- **📖 Key Concepts & Definitions** — term : definition pairs
- **⭐ Important Points to Remember** — exam-focused highlights
- **🧮 Formulas / Facts** — auto-detected formulas and hard facts

### 🎴 Auto-flashcards (the killer feature)
- 5–10 Q&A flashcards generated automatically from the lecture
- Flip-card UI — click to reveal the answer
- Export to **Anki-compatible CSV**

### 🌐 Indian-language support
Summarize an English lecture **into** your chosen language:
English, Hindi, Hinglish, Tamil, Telugu, Bengali, Marathi, Kannada.

### 🔒 Privacy-first
No account, no signup, no third-party server. Your API key and data live only
in your browser's local storage.

---

## 💎 Free vs Pro

| | Free | Pro |
|---|---|---|
| Lectures per day | 3 | Unlimited |
| Notes + Key Concepts | ✅ | ✅ |
| Auto-flashcards | 🔒 Locked | ✅ |
| Languages | English + Hindi | All 8 |
| Export (TXT / MD / Anki CSV) | ❌ | ✅ |
| Pro badge | — | ⭐ |

**Test license key:** `LECTURELOOP-PRO-2024`

---

## 📂 Project structure

```
lectureloop/
├── manifest.json     # MV3 config (YouTube-only content script)
├── background.js     # Claude API call, freemium limits, JSON parsing
├── content.js        # On-page button + study panel + transcript fetch
├── popup.html        # Settings: API key, language, Pro activation
├── popup.js          # Popup logic
├── styles.css        # Popup styling (panel styles are in content.js)
├── README.md         # This file
└── icons/
    ├── icon16.png
    ├── icon48.png
    └── icon128.png
```

### What each file does
- **manifest.json** — Manifest V3. Restricts the content script to
  `youtube.com`; grants `storage` plus the Anthropic + YouTube hosts.
- **background.js** — The "brain." Runs outside the page so it can call the
  Claude API (YouTube's origin would be CORS-blocked), enforces the daily
  limit in one trusted place, validates license keys, and parses Claude's
  JSON into the four study sections.
- **content.js** — Everything you see on YouTube: injects the
  **📚 Study Mode** button, builds the slide-in study panel inside a
  **Shadow DOM** (so YouTube's CSS can't break it), fetches the transcript,
  and renders Notes / Concepts / Flashcards + export.
- **popup.html / popup.js / styles.css** — The settings surface: paste your
  API key, pick a default language, see usage, and activate Pro.

---

## 🚀 Installation (Developer Mode)

1. Open Chrome and go to `chrome://extensions/`
2. Turn on **Developer mode** (top-right toggle)
3. Click **Load unpacked** and select the `lectureloop` folder
4. Pin LectureLoop from the puzzle-piece menu

### First-time setup
1. Click the LectureLoop icon in your toolbar
2. Paste your Claude API key from
   [console.anthropic.com](https://console.anthropic.com) (starts with `sk-ant-`)
3. Click **Save key** — it's stored only on your device
4. (Optional) Pick a default output language

---

## 📖 How to use

1. Open any **YouTube lecture that has captions** (look for the CC button)
2. Click **📚 Study Mode** below the video
3. The study panel slides in with three tabs:
   - **Notes** — revision notes, important points, formulas/facts
   - **Concepts** — key terms and definitions
   - **Flashcards** — flip-cards (Pro)
4. Change the **output language** at the top of the panel
5. **Export** your notes / flashcards from the panel footer (Pro)

---

## 🔄 How it works

```
YouTube page
   │  (1) you click "Study Mode"
   ▼
content.js ──(2) fetch transcript──► YouTube captions
   │            • Method 1: ytInitialPlayerResponse → timed-text JSON
   │            • Method 2 (fallback): scrape the "Show transcript" panel
   │  (3) send transcript + language
   ▼
background.js ──(4) call Claude API──► api.anthropic.com
   │  (5) parse JSON: notes / concepts / keyPoints / flashcards
   ▼
content.js  (6) render the study panel
```

The AI prompt asks Claude to return strict JSON:

```json
{
  "notes": ["bullet 1", "bullet 2"],
  "concepts": [{ "term": "...", "definition": "..." }],
  "keyPoints": ["..."],
  "flashcards": [{ "question": "...", "answer": "..." }]
}
```

---

## 🛠️ Development notes

- **After editing `content.js` or `background.js`:** reload the extension at
  `chrome://extensions/` **and** reload the YouTube tab. (Old content scripts
  become "orphaned" after a reload — the code handles this with a friendly
  "Please reload this page" message instead of an error.)
- **Model:** `claude-sonnet-4-20250514` (change `MODEL` in `background.js`)
- **Limits/keys:** `FREE_LIMIT`, `VALID_KEY`, `MAX_TRANSCRIPT` are all at the
  top of `background.js`
- Storage shape:
  `{ usageCount, lastResetDate, isPro, apiKey, language }`

---

## ⚠️ Known limitations

- **Needs captions.** No captions (manual or auto-generated) → you'll see
  *"No transcript available — try a lecture with captions."*
- **YouTube anti-scraping tokens.** YouTube is rolling out tokens on some
  timed-text URLs. When Method 1 fails, LectureLoop automatically falls back
  to **scraping the on-page transcript panel** (Method 2), which is far more
  resilient — but very rare layouts could still miss.
- **Very long lectures** are truncated to the first ~16,000 characters of
  transcript (configurable via `MAX_TRANSCRIPT`).

---

## 🔐 Privacy

LectureLoop has **no backend**. The only network request it makes is the
direct call to the Anthropic API using **your** key. Your key, usage counter,
and preferences are stored in `chrome.storage.local` on your machine and are
never transmitted anywhere else.

---

## 📝 License

Personal/educational use. Bring your own Anthropic API key.

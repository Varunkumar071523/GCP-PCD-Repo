// ============================================================
//  content.js — Runs on YouTube. The whole on-page experience.
//   1. Injects the "📚 Study Mode" button below the video
//   2. Builds a slide-in study panel (Shadow DOM = style-proof)
//   3. Fetches the lecture transcript
//   4. Sends it to background.js → renders Notes/Concepts/Flashcards
//  YouTube is a single-page app, so we re-inject on navigation.
// ============================================================

(function () {
  if (window.__lectureLoopInjected) return;
  window.__lectureLoopInjected = true;

  let panelBuilt = false;
  let shadow = null;
  let lastStudy = null;       // last generated study data (for export)
  let lastStatus = null;      // last known {isPro, features, ...}
  let lastMeta = { title: "", channel: "" };

  // ============================================================
  //  1) Inject / maintain the Study Mode button
  //     YouTube swaps content without reloading, so we keep
  //     checking that our button is present on /watch pages.
  // ============================================================
  function ensureButton() {
    const onWatch = location.pathname === "/watch";
    const existing = document.getElementById("ll-study-btn");

    if (!onWatch) {
      if (existing) existing.remove();
      return;
    }
    if (existing) return; // already there

    // Find a good anchor near the title; fall back to fixed button
    const anchor =
      document.querySelector("ytd-watch-metadata #title") ||
      document.querySelector("#above-the-fold #title") ||
      document.querySelector("#title.ytd-watch-metadata");

    const btn = document.createElement("button");
    btn.id = "ll-study-btn";
    btn.textContent = "📚 Study Mode";
    // Inline styles so YouTube's CSS can't override the button
    Object.assign(btn.style, {
      display: "inline-flex",
      alignItems: "center",
      gap: "6px",
      margin: "12px 0",
      padding: "10px 18px",
      background: "linear-gradient(135deg,#4f46e5,#0d9488)",
      color: "#fff",
      border: "none",
      borderRadius: "22px",
      fontSize: "14px",
      fontWeight: "600",
      fontFamily: "Roboto, Arial, sans-serif",
      cursor: "pointer",
      boxShadow: "0 4px 14px rgba(79,70,229,.35)",
      zIndex: "9999"
    });
    btn.addEventListener("click", openPanelAndGenerate);

    if (anchor && anchor.parentElement) {
      anchor.parentElement.insertBefore(btn, anchor.nextSibling);
    } else {
      // Fallback: float it bottom-right
      Object.assign(btn.style, {
        position: "fixed", bottom: "20px", right: "20px", margin: "0"
      });
      document.body.appendChild(btn);
    }
  }

  // Re-check the button on YouTube's SPA navigation + a light interval
  document.addEventListener("yt-navigate-finish", () => setTimeout(ensureButton, 400));
  window.addEventListener("load", ensureButton);
  setInterval(ensureButton, 2000);
  ensureButton();

  // ============================================================
  //  2) Build the slide-in study panel (once) in a Shadow DOM
  // ============================================================
  function buildPanel() {
    if (panelBuilt) return;
    panelBuilt = true;

    const host = document.createElement("div");
    host.id = "ll-panel-host";
    host.style.all = "initial";
    document.documentElement.appendChild(host);
    shadow = host.attachShadow({ mode: "open" });

    shadow.innerHTML = `
      <style>${PANEL_CSS()}</style>
      <div class="ll-overlay" id="ll-overlay"></div>
      <aside class="ll-panel" id="ll-panel">
        <header class="ll-head">
          <div class="ll-logo"><span>📚</span> Lecture<b>Loop</b></div>
          <span class="ll-pro" id="ll-pro">PRO</span>
          <button class="ll-close" id="ll-close" type="button">×</button>
        </header>

        <div class="ll-langrow">
          <label>Output language</label>
          <select id="ll-lang"></select>
        </div>

        <nav class="ll-tabs">
          <button class="ll-tab active" data-tab="notes" type="button">Notes</button>
          <button class="ll-tab" data-tab="concepts" type="button">Concepts</button>
          <button class="ll-tab" data-tab="cards" type="button">Flashcards</button>
        </nav>

        <div class="ll-body" id="ll-body">
          <!-- rendered content goes here -->
        </div>

        <footer class="ll-foot">
          <div class="ll-export" id="ll-export"></div>
          <div class="ll-foot-row">
            <span class="ll-privacy">🔒 100% private. No account. Your data never leaves your browser.</span>
          </div>
          <div class="ll-foot-row">
            <span class="ll-usage" id="ll-usage"></span>
          </div>
          <div class="ll-upgrade" id="ll-upgrade"></div>
        </footer>
      </aside>
    `;

    // Wire up controls
    shadow.getElementById("ll-close").addEventListener("click", closePanel);
    shadow.getElementById("ll-overlay").addEventListener("click", closePanel);

    shadow.querySelectorAll(".ll-tab").forEach((t) => {
      t.addEventListener("click", () => switchTab(t.dataset.tab));
    });

    shadow.getElementById("ll-lang").addEventListener("change", (e) => {
      chrome.storage.local.set({ language: e.target.value });
    });
  }

  function openPanel() {
    buildPanel();
    shadow.getElementById("ll-panel").classList.add("open");
    shadow.getElementById("ll-overlay").classList.add("open");
  }
  function closePanel() {
    if (!shadow) return;
    shadow.getElementById("ll-panel").classList.remove("open");
    shadow.getElementById("ll-overlay").classList.remove("open");
  }

  // ============================================================
  //  3) Main flow: open panel → fetch transcript → generate
  // ============================================================
  async function openPanelAndGenerate() {
    openPanel();
    const body = shadow.getElementById("ll-body");

    // Load status first (Pro?, languages, key present?)
    lastStatus = await send({ type: "GET_STATUS" });
    renderStatus(lastStatus);

    // No API key yet → guide the user to the popup
    if (lastStatus && !lastStatus.hasKey) {
      body.innerHTML = card(
        "🔑 Add your Claude API key",
        "<p class='ll-muted'>LectureLoop uses <b>your own</b> Claude API key — nothing is sent to us. " +
        "Click the LectureLoop icon in your toolbar, paste your key from " +
        "<a href='https://console.anthropic.com' target='_blank'>console.anthropic.com</a>, and try again.</p>"
      );
      return;
    }

    // Loading state
    body.innerHTML =
      "<div class='ll-loading'><div class='ll-spinner'></div>" +
      "<p>Reading the lecture & building your notes…</p></div>";

    // Grab transcript + metadata from the page
    const { transcript, title, channel } = await getTranscript();
    lastMeta = { title, channel };

    if (!transcript) {
      body.innerHTML = card(
        "😕 No transcript found",
        "<p class='ll-muted'>No transcript available — try a lecture with captions " +
        "(look for the CC button on the video).</p>"
      );
      return;
    }

    // Ask background to call Claude
    const lang = shadow.getElementById("ll-lang").value || "English";
    const result = await send({ type: "GENERATE", transcript, title, language: lang });

    if (!result.ok) {
      if (result.reason === "limit") return renderUpgrade(result.message);
      body.innerHTML = card("⚠️ " + titleForReason(result.reason),
        "<p class='ll-muted'>" + escapeHtml(result.message) + "</p>");
      return;
    }

    // Success → store + render
    lastStudy = result.study;
    lastStatus = Object.assign({}, lastStatus, {
      isPro: result.isPro, features: result.features,
      usageCount: result.usageCount, remaining: result.remaining
    });
    renderStatus(lastStatus);
    renderAll(result.study, lastStatus);
    switchTab("notes");

    if (result.truncated) {
      const note = document.createElement("p");
      note.className = "ll-muted ll-trunc";
      note.textContent = "Note: this lecture was long, so notes are based on the first part of the transcript.";
      shadow.getElementById("ll-body").prepend(note);
    }
  }

  // ============================================================
  //  4) Transcript fetching
  //     Read YouTube's ytInitialPlayerResponse to find the
  //     caption tracks, then fetch the timed-text JSON.
  // ============================================================
  async function getTranscript() {
    let title = cleanTitle(document.title);
    let channel = "";
    let transcript = "";

    // ---- Method 1: caption tracks via ytInitialPlayerResponse ----
    // Fast and clean. May fail if YouTube token-gates the timed-text URL.
    try {
      const html = await fetch(location.href, { credentials: "include" }).then(r => r.text());
      const pr = extractPlayerResponse(html);
      if (pr) {
        title = pr?.videoDetails?.title || title;
        channel = pr?.videoDetails?.author || "";

        const tracks = pr?.captions?.playerCaptionsTracklistRenderer?.captionTracks;
        if (tracks && tracks.length) {
          // Prefer a manual English track, else any manual, else first
          const pick =
            tracks.find(t => t.languageCode === "en" && t.kind !== "asr") ||
            tracks.find(t => t.kind !== "asr") ||
            tracks.find(t => t.languageCode === "en") ||
            tracks[0];

          const tt = await fetch(pick.baseUrl + "&fmt=json3").then(r => r.json());
          transcript = (tt.events || [])
            .map(ev => (ev.segs || []).map(s => s.utf8).join(""))
            .join(" ")
            .replace(/\s+/g, " ")
            .trim();
        }
      }
    } catch (e) {
      // fall through to the scraping fallback
    }

    // ---- Method 2 (fallback): scrape YouTube's transcript panel ----
    // Works even when the timed-text endpoint is token-gated, because
    // it reads the captions YouTube itself renders in the UI.
    if (!transcript || transcript.length < 30) {
      const scraped = await scrapeTranscriptPanel();
      if (scraped) transcript = scraped;
    }

    return { transcript, title, channel };
  }

  // ------------------------------------------------------------
  //  Fallback: open YouTube's "Show transcript" panel and read it
  // ------------------------------------------------------------
  async function scrapeTranscriptPanel() {
    // Maybe the panel is already open (user opened it themselves) —
    // read it but DON'T close it, since we didn't open it.
    let segs = collectSegments();
    if (segs) return segs;

    // Remember whether the description was collapsed, so we can
    // restore the page to how we found it afterwards.
    const expand = document.querySelector("#expand, tp-yt-paper-button#expand");
    const weExpanded = !!expand;
    if (expand) { expand.click(); await wait(300); }

    // Find a "transcript" button by aria-label or visible text
    let btn = findTranscriptButton();
    if (!btn) { await wait(500); btn = findTranscriptButton(); }
    if (!btn) { if (weExpanded) collapseDescription(); return ""; }

    // We are opening the panel ourselves → we should close it again.
    btn.click();

    // Segments load asynchronously — poll for up to ~5s
    let result = "";
    for (let i = 0; i < 20; i++) {
      await wait(250);
      segs = collectSegments();
      if (segs) { result = segs; break; }
    }

    // Clean up: close the transcript panel and re-collapse the
    // description so the user never sees our scraping.
    closeTranscriptPanel();
    if (weExpanded) collapseDescription();
    return result;
  }

  // Close the engagement panel we opened (click the same/close button)
  function closeTranscriptPanel() {
    // Modern YouTube: the searchable-transcript engagement panel has a
    // close (×) button in its header.
    const panel = document.querySelector(
      'ytd-engagement-panel-section-list-renderer[target-id="engagement-panel-searchable-transcript"], ' +
      'ytd-engagement-panel-section-list-renderer[visibility="ENGAGEMENT_PANEL_VISIBILITY_EXPANDED"]'
    );
    if (panel) {
      const closeBtn = panel.querySelector(
        '#visibility-button button, button[aria-label="Close transcript"], yt-icon-button#close-button button'
      );
      if (closeBtn) { closeBtn.click(); return; }
    }
    // Fallback: toggle the original "Show transcript" button again
    const btn = findTranscriptButton();
    if (btn) btn.click();
  }

  // Re-collapse the description if we were the ones who expanded it
  function collapseDescription() {
    const collapse = document.querySelector("#collapse, tp-yt-paper-button#collapse");
    if (collapse) collapse.click();
  }

  // Read all transcript segment text nodes from the panel
  function collectSegments() {
    const nodes = document.querySelectorAll(
      "ytd-transcript-segment-renderer .segment-text, " +
      "ytd-transcript-segment-renderer yt-formatted-string.segment-text"
    );
    if (!nodes.length) return "";
    return [...nodes]
      .map(n => n.textContent.trim())
      .filter(Boolean)
      .join(" ")
      .replace(/\s+/g, " ")
      .trim();
  }

  // Locate the "Show transcript" button across YouTube's many button types
  function findTranscriptButton() {
    const buttons = document.querySelectorAll(
      "button, tp-yt-paper-button, yt-button-shape button, ytd-button-renderer button, ytd-menu-service-item-renderer"
    );
    for (const b of buttons) {
      const label = (b.getAttribute("aria-label") || "") + " " + (b.textContent || "");
      if (/transcript/i.test(label)) return b;
    }
    return null;
  }

  function wait(ms) { return new Promise(r => setTimeout(r, ms)); }

  // Pull the ytInitialPlayerResponse JSON object out of page HTML
  function extractPlayerResponse(html) {
    const marker = "ytInitialPlayerResponse";
    const idx = html.indexOf(marker);
    if (idx === -1) return null;
    const braceStart = html.indexOf("{", idx);
    if (braceStart === -1) return null;
    const jsonStr = sliceBalanced(html, braceStart);
    if (!jsonStr) return null;
    try { return JSON.parse(jsonStr); } catch (e) { return null; }
  }

  // Walk from an opening "{" to its matching "}", respecting strings
  function sliceBalanced(str, start) {
    let depth = 0, inStr = false, esc = false;
    for (let i = start; i < str.length; i++) {
      const c = str[i];
      if (inStr) {
        if (esc) esc = false;
        else if (c === "\\") esc = true;
        else if (c === '"') inStr = false;
      } else {
        if (c === '"') inStr = true;
        else if (c === "{") depth++;
        else if (c === "}") { depth--; if (depth === 0) return str.slice(start, i + 1); }
      }
    }
    return null;
  }

  function cleanTitle(t) { return (t || "").replace(/ - YouTube$/, "").trim(); }

  // ============================================================
  //  5) Rendering the study sections
  // ============================================================
  function renderAll(study, status) {
    renderNotes(study, status);
    renderConcepts(study, status);
    renderCards(study, status);
    renderExport(status);
  }

  // ---- Notes tab: Quick Revision + Important Points + Formulas ----
  function renderNotes(study, status) {
    let html = "";

    if (study.notes.length) {
      html += "<h3 class='ll-h'>📝 Quick Revision Notes</h3><ul class='ll-bullets'>" +
        study.notes.map(n => "<li>" + escapeHtml(n) + "</li>").join("") + "</ul>";
    }

    if (study.keyPoints.length) {
      html += "<h3 class='ll-h'>⭐ Important Points to Remember</h3><ul class='ll-bullets ll-key'>" +
        study.keyPoints.map(k => "<li>" + escapeHtml(k) + "</li>").join("") + "</ul>";
    }

    // Auto-detect formula/fact-like lines from notes + keyPoints
    const facts = [...study.notes, ...study.keyPoints].filter(looksLikeFact);
    if (facts.length) {
      html += "<h3 class='ll-h'>🧮 Formulas / Facts</h3><ul class='ll-bullets ll-facts'>" +
        facts.map(f => "<li>" + escapeHtml(f) + "</li>").join("") + "</ul>";
    }

    if (!html) html = "<p class='ll-muted'>No notes were generated for this lecture.</p>";
    getTab("notes").innerHTML = html;
  }

  // ---- Concepts tab: term : definition cards ----
  function renderConcepts(study, status) {
    let html = "<h3 class='ll-h'>📖 Key Concepts & Definitions</h3>";
    if (study.concepts.length) {
      html += study.concepts.map(c =>
        "<div class='ll-concept'><div class='ll-term'>" + escapeHtml(c.term || "") +
        "</div><div class='ll-def'>" + escapeHtml(c.definition || "") + "</div></div>"
      ).join("");
    } else {
      html += "<p class='ll-muted'>No key concepts were generated.</p>";
    }
    getTab("concepts").innerHTML = html;
  }

  // ---- Flashcards tab: flip-cards (LOCKED for free users) ----
  function renderCards(study, status) {
    const tab = getTab("cards");

    if (!status.features.flashcards) {
      tab.innerHTML =
        "<div class='ll-lock'><div class='ll-lock-icon'>🔒</div>" +
        "<h3>Unlock Auto-Flashcards with Pro</h3>" +
        "<p class='ll-muted'>LectureLoop turns this lecture into ready-to-revise " +
        "Q&A flashcards — flip to test yourself, export to Anki. The killer revision tool.</p>" +
        "<button class='ll-btn' id='ll-unlock'>Upgrade to Pro</button></div>";
      const u = shadow.getElementById("ll-unlock");
      if (u) u.addEventListener("click", () => renderUpgrade("Unlock flashcards, all 8 languages, and export with Pro."));
      return;
    }

    if (!study.flashcards.length) {
      tab.innerHTML = "<p class='ll-muted'>No flashcards were generated.</p>";
      return;
    }

    tab.innerHTML = "<h3 class='ll-h'>🎴 Flashcards <span class='ll-muted'>(tap to flip)</span></h3>" +
      "<div class='ll-cards'>" +
      study.flashcards.map((f, i) =>
        "<div class='ll-flip' data-i='" + i + "'>" +
          "<div class='ll-flip-inner'>" +
            "<div class='ll-flip-front'><span class='ll-q'>Q" + (i + 1) + "</span>" + escapeHtml(f.question || "") + "</div>" +
            "<div class='ll-flip-back'><span class='ll-a'>A</span>" + escapeHtml(f.answer || "") + "</div>" +
          "</div></div>"
      ).join("") + "</div>";

    tab.querySelectorAll(".ll-flip").forEach(c =>
      c.addEventListener("click", () => c.classList.toggle("flipped")));
  }

  // ---- Export buttons (Pro only) ----
  function renderExport(status) {
    const box = shadow.getElementById("ll-export");
    if (!status.features.export || !lastStudy) { box.innerHTML = ""; return; }
    box.innerHTML =
      "<button class='ll-btn-ghost' id='ll-exp-md'>⬇ Notes (.md)</button>" +
      "<button class='ll-btn-ghost' id='ll-exp-txt'>⬇ Notes (.txt)</button>" +
      "<button class='ll-btn-ghost' id='ll-exp-csv'>⬇ Flashcards (.csv)</button>";
    shadow.getElementById("ll-exp-md").addEventListener("click", () => exportNotes("md"));
    shadow.getElementById("ll-exp-txt").addEventListener("click", () => exportNotes("txt"));
    shadow.getElementById("ll-exp-csv").addEventListener("click", exportFlashcards);
  }

  // ============================================================
  //  6) Status rendering (Pro badge, languages, usage, upgrade)
  // ============================================================
  function renderStatus(status) {
    if (!status) return;

    // Pro badge
    shadow.getElementById("ll-pro").classList.toggle("visible", !!status.isPro);

    // Language selector — allowed tones enabled, others shown locked
    const sel = shadow.getElementById("ll-lang");
    const ALL = ["English","Hindi","Hinglish","Tamil","Telugu","Bengali","Marathi","Kannada"];
    sel.innerHTML = "";
    ALL.forEach(l => {
      const allowed = status.languages.includes(l);
      const o = document.createElement("option");
      o.value = l;
      o.textContent = allowed ? l : (l + " 🔒");
      o.disabled = !allowed;
      sel.appendChild(o);
    });
    sel.value = status.languages.includes(status.language) ? status.language : "English";

    // Usage counter
    const usage = shadow.getElementById("ll-usage");
    usage.textContent = status.isPro
      ? "⭐ Pro — unlimited lectures"
      : (status.usageCount + " / " + status.limit + " lectures used today");

    // Upgrade banner (free users only)
    const up = shadow.getElementById("ll-upgrade");
    up.innerHTML = status.isPro ? "" :
      "<button class='ll-banner' id='ll-banner'>✨ Upgrade to Pro — flashcards, 8 languages, export</button>";
    const b = shadow.getElementById("ll-banner");
    if (b) b.addEventListener("click", () => renderUpgrade("Unlock flashcards, all 8 languages, and export with Pro."));
  }

  // Inline Pro activation (sends key to background)
  function renderUpgrade(message) {
    switchTab("cards"); // show in the body area
    getTab("cards").innerHTML =
      "<div class='ll-lock'><div class='ll-lock-icon'>✨</div>" +
      "<h3>Upgrade to Pro</h3><p class='ll-muted'>" + escapeHtml(message) + "</p>" +
      "<ul class='ll-prolist'>" +
        "<li>Unlimited lectures per day</li>" +
        "<li>Auto-flashcards (flip + Anki export)</li>" +
        "<li>All 8 languages incl. Tamil, Telugu, Bengali…</li>" +
        "<li>Export notes (.md / .txt)</li>" +
      "</ul>" +
      "<input class='ll-key' id='ll-key' type='text' placeholder='LECTURELOOP-PRO-XXXX' autocomplete='off' spellcheck='false' />" +
      "<button class='ll-btn' id='ll-activate'>Activate</button>" +
      "<div class='ll-act-result' id='ll-act-result'></div></div>";

    const keyEl = shadow.getElementById("ll-key");
    const resEl = shadow.getElementById("ll-act-result");
    const submit = async () => {
      const r = await send({ type: "ACTIVATE_PRO", key: keyEl.value });
      if (r.ok) {
        resEl.className = "ll-act-result ok";
        resEl.textContent = "🎉 " + r.message;
        lastStatus = await send({ type: "GET_STATUS" });
        renderStatus(lastStatus);
        if (lastStudy) renderAll(lastStudy, lastStatus); // unlock flashcards/export now
      } else {
        resEl.className = "ll-act-result err";
        resEl.textContent = r.message;
      }
    };
    shadow.getElementById("ll-activate").addEventListener("click", submit);
    keyEl.addEventListener("keydown", e => { if (e.key === "Enter") submit(); });
  }

  // ============================================================
  //  7) Tabs + small helpers
  // ============================================================
  function switchTab(name) {
    if (!shadow) return;
    shadow.querySelectorAll(".ll-tab").forEach(t =>
      t.classList.toggle("active", t.dataset.tab === name));
    shadow.querySelectorAll(".ll-tabpane").forEach(p =>
      p.classList.toggle("active", p.dataset.pane === name));
  }

  // Each tab's content lives in a pane; create lazily inside body
  function getTab(name) {
    const body = shadow.getElementById("ll-body");
    let pane = body.querySelector('.ll-tabpane[data-pane="' + name + '"]');
    if (!pane) {
      pane = document.createElement("div");
      pane.className = "ll-tabpane";
      pane.dataset.pane = name;
      body.appendChild(pane);
    }
    return pane;
  }

  function card(title, inner) {
    return "<div class='ll-card'><h3 class='ll-h'>" + title + "</h3>" + inner + "</div>";
  }
  function titleForReason(r) {
    return r === "no_key" ? "API key needed"
         : r === "no_transcript" ? "No transcript"
         : "Something went wrong";
  }

  // True-ish if a line looks like a formula or hard fact
  function looksLikeFact(s) {
    return /[=×÷±√∑∫]|(\d+\s*(%|kg|m\/s|km|cm|mm|°|mol|N|J|W|Hz|eV))|\b\d{3,}\b/.test(s);
  }

  function escapeHtml(s) {
    return String(s || "")
      .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  // ============================================================
  //  8) Export (Pro): Markdown / TXT notes, Anki-style CSV
  // ============================================================
  function exportNotes(format) {
    if (!lastStudy) return;
    const t = lastMeta.title || "LectureLoop Notes";
    let out = "";

    if (format === "md") {
      out += "# " + t + "\n\n## Quick Revision Notes\n";
      lastStudy.notes.forEach(n => out += "- " + n + "\n");
      out += "\n## Key Concepts & Definitions\n";
      lastStudy.concepts.forEach(c => out += "- **" + c.term + "**: " + c.definition + "\n");
      out += "\n## Important Points\n";
      lastStudy.keyPoints.forEach(k => out += "- " + k + "\n");
    } else {
      out += t + "\n\nQUICK REVISION NOTES\n";
      lastStudy.notes.forEach(n => out += "• " + n + "\n");
      out += "\nKEY CONCEPTS & DEFINITIONS\n";
      lastStudy.concepts.forEach(c => out += "- " + c.term + ": " + c.definition + "\n");
      out += "\nIMPORTANT POINTS\n";
      lastStudy.keyPoints.forEach(k => out += "• " + k + "\n");
    }
    download(out, slug(t) + (format === "md" ? ".md" : ".txt"),
             format === "md" ? "text/markdown" : "text/plain");
  }

  function exportFlashcards() {
    if (!lastStudy || !lastStudy.flashcards.length) return;
    // Anki imports CSV: front,back  (quotes escaped by doubling)
    const rows = lastStudy.flashcards.map(f =>
      '"' + String(f.question || "").replace(/"/g, '""') + '","' +
            String(f.answer || "").replace(/"/g, '""') + '"');
    download(rows.join("\n"), slug(lastMeta.title || "flashcards") + ".csv", "text/csv");
  }

  function download(content, filename, mime) {
    const blob = new Blob([content], { type: mime + ";charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = filename;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
  function slug(s) { return (s || "notes").replace(/[^\w\d]+/g, "_").slice(0, 60); }

  // ============================================================
  //  Messaging helper (handles "extension reloaded" gracefully)
  // ============================================================
  function send(msg) {
    return new Promise((resolve) => {
      if (!chrome.runtime?.id) {
        resolve({ ok: false, reason: "context", message: "Please reload this page (extension was updated)." });
        return;
      }
      try {
        chrome.runtime.sendMessage(msg, (resp) => {
          if (chrome.runtime.lastError)
            resolve({ ok: false, reason: "api", message: chrome.runtime.lastError.message });
          else resolve(resp);
        });
      } catch (e) {
        resolve({ ok: false, reason: "context", message: "Please reload this page (extension was updated)." });
      }
    });
  }

  // ============================================================
  //  9) Panel stylesheet (inside Shadow DOM → page can't touch it)
  // ============================================================
  function PANEL_CSS() {
    return `
      :host, * { box-sizing: border-box; }
      .ll-overlay {
        position: fixed; inset: 0; background: rgba(20,20,40,.25);
        opacity: 0; pointer-events: none; transition: opacity .25s; z-index: 2147483646;
      }
      .ll-overlay.open { opacity: 1; pointer-events: auto; }

      .ll-panel {
        position: fixed; top: 0; right: 0; height: 100vh; width: 400px; max-width: 92vw;
        background: #f8fafc; box-shadow: -8px 0 40px rgba(30,27,75,.25);
        transform: translateX(105%); transition: transform .28s ease;
        display: flex; flex-direction: column; z-index: 2147483647;
        font-family: 'Inter','Segoe UI',system-ui,-apple-system,sans-serif; color: #1e1b4b;
      }
      .ll-panel.open { transform: translateX(0); }

      .ll-head {
        display: flex; align-items: center; gap: 8px; padding: 16px 18px;
        background: linear-gradient(135deg,#4f46e5,#0d9488); color: #fff;
      }
      .ll-logo { font-size: 17px; font-weight: 700; }
      .ll-logo span { font-size: 18px; }
      .ll-logo b { color: #c7f9ec; }
      .ll-pro {
        display: none; background: linear-gradient(135deg,#fbbf24,#f59e0b);
        color: #3a2a00; font-size: 10px; font-weight: 800; padding: 2px 8px;
        border-radius: 10px; letter-spacing: .5px;
      }
      .ll-pro.visible { display: inline-block; }
      .ll-close {
        margin-left: auto; background: none; border: none; color: #fff;
        font-size: 24px; line-height: 1; cursor: pointer; opacity: .85;
      }
      .ll-close:hover { opacity: 1; }

      .ll-langrow {
        display: flex; align-items: center; gap: 10px; padding: 12px 18px;
        background: #fff; border-bottom: 1px solid #eef2f7;
      }
      .ll-langrow label { font-size: 12px; font-weight: 600; color: #475569; }
      #ll-lang {
        flex: 1; padding: 7px 10px; border: 1.5px solid #e2e8f0; border-radius: 9px;
        font-size: 13px; font-family: inherit; color: #1e1b4b; background: #fff; cursor: pointer;
      }
      #ll-lang:focus { outline: none; border-color: #4f46e5; }

      .ll-tabs { display: flex; background: #fff; padding: 0 10px; border-bottom: 1px solid #eef2f7; }
      .ll-tab {
        flex: 1; padding: 12px 6px; background: none; border: none; cursor: pointer;
        font-size: 13px; font-weight: 600; color: #94a3b8; font-family: inherit;
        border-bottom: 2.5px solid transparent;
      }
      .ll-tab.active { color: #4f46e5; border-bottom-color: #4f46e5; }

      .ll-body { flex: 1; overflow-y: auto; padding: 16px 18px; }
      .ll-tabpane { display: none; }
      .ll-tabpane.active { display: block; }

      .ll-h { font-size: 14px; margin: 4px 0 10px; color: #312e81; }
      .ll-h .ll-muted { font-weight: 400; font-size: 12px; }
      .ll-muted { color: #64748b; font-size: 13px; line-height: 1.55; }
      .ll-trunc { background: #fef9c3; border: 1px solid #fde68a; padding: 8px 10px; border-radius: 8px; }

      .ll-bullets { margin: 0 0 18px; padding-left: 20px; }
      .ll-bullets li { font-size: 13px; line-height: 1.6; margin-bottom: 6px; color: #334155; }
      .ll-key li { color: #b45309; }
      .ll-facts li { font-family: 'Cascadia Code',Consolas,monospace; color: #0f766e; }

      .ll-concept {
        background: #fff; border: 1px solid #eef2f7; border-radius: 12px;
        padding: 12px 14px; margin-bottom: 10px;
      }
      .ll-term { font-weight: 700; font-size: 13.5px; color: #4338ca; margin-bottom: 3px; }
      .ll-def { font-size: 13px; color: #475569; line-height: 1.55; }

      /* Flashcards */
      .ll-cards { display: flex; flex-direction: column; gap: 12px; }
      .ll-flip { perspective: 1000px; cursor: pointer; min-height: 96px; }
      .ll-flip-inner {
        position: relative; width: 100%; min-height: 96px;
        transition: transform .5s; transform-style: preserve-3d;
      }
      .ll-flip.flipped .ll-flip-inner { transform: rotateY(180deg); }
      .ll-flip-front, .ll-flip-back {
        position: absolute; inset: 0; backface-visibility: hidden;
        border-radius: 12px; padding: 14px 16px; font-size: 13.5px; line-height: 1.5;
        display: flex; align-items: center; box-shadow: 0 2px 10px rgba(30,27,75,.08);
      }
      .ll-flip-front { background: #fff; border: 1.5px solid #e0e7ff; color: #1e1b4b; }
      .ll-flip-back {
        background: linear-gradient(135deg,#4f46e5,#0d9488); color: #fff; transform: rotateY(180deg);
      }
      .ll-q, .ll-a {
        position: absolute; top: 8px; left: 12px; font-size: 10px; font-weight: 800;
        letter-spacing: .5px; opacity: .7;
      }
      .ll-flip-front .ll-q, .ll-flip-back .ll-a { padding-right: 6px; }
      .ll-flip-front, .ll-flip-back { padding-top: 26px; }

      /* Locked / upgrade states */
      .ll-lock { text-align: center; padding: 24px 16px; }
      .ll-lock-icon { font-size: 36px; }
      .ll-lock h3 { margin: 10px 0 6px; font-size: 16px; color: #312e81; }
      .ll-prolist { text-align: left; list-style: none; padding: 0; margin: 14px 0; }
      .ll-prolist li { font-size: 13px; color: #4338ca; padding: 3px 0; }
      .ll-prolist li::before { content: "✓ "; font-weight: 800; }

      .ll-btn {
        margin-top: 12px; background: linear-gradient(135deg,#4f46e5,#0d9488); color: #fff;
        border: none; border-radius: 10px; padding: 10px 22px; font-size: 13px;
        font-weight: 600; cursor: pointer; width: 100%;
      }
      .ll-btn:hover { opacity: .93; }
      .ll-key {
        width: 100%; margin-top: 14px; padding: 9px 12px; border: 1.5px solid #c7d2fe;
        border-radius: 9px; font-size: 13px; text-align: center; letter-spacing: 1px; font-family: inherit;
      }
      .ll-key:focus { outline: none; border-color: #4f46e5; }
      .ll-act-result { font-size: 12.5px; margin-top: 8px; }
      .ll-act-result.ok { color: #047857; }
      .ll-act-result.err { color: #dc2626; }

      /* Loading */
      .ll-loading { text-align: center; padding: 50px 20px; color: #64748b; }
      .ll-spinner {
        width: 34px; height: 34px; margin: 0 auto 14px; border-radius: 50%;
        border: 3.5px solid #e0e7ff; border-top-color: #4f46e5; animation: ll-spin .8s linear infinite;
      }
      @keyframes ll-spin { to { transform: rotate(360deg); } }

      /* Footer */
      .ll-foot { background: #fff; border-top: 1px solid #eef2f7; padding: 10px 16px; }
      .ll-export { display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 8px; }
      .ll-export:empty { display: none; }
      .ll-btn-ghost {
        border: 1.5px solid #c7d2fe; color: #4338ca; background: #fff; border-radius: 8px;
        padding: 5px 10px; font-size: 11.5px; font-weight: 600; cursor: pointer;
      }
      .ll-btn-ghost:hover { background: #4f46e5; color: #fff; border-color: #4f46e5; }
      .ll-foot-row { margin: 3px 0; }
      .ll-privacy { font-size: 11px; color: #0d9488; font-weight: 600; }
      .ll-usage { font-size: 12px; color: #64748b; }
      .ll-upgrade:empty { display: none; }
      .ll-banner {
        width: 100%; margin-top: 8px; background: linear-gradient(135deg,#eef2ff,#ccfbf1);
        border: 1.5px solid #c7d2fe; color: #4338ca; border-radius: 10px; padding: 9px;
        font-size: 12px; font-weight: 600; cursor: pointer;
      }
      .ll-card { background: #fff; border: 1px solid #eef2f7; border-radius: 12px; padding: 16px; }
      .ll-card a { color: #4f46e5; }
    `;
  }
})();

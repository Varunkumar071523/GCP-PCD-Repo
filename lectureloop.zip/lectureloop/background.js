// ============================================================
//  background.js — Service Worker (the "brain")
//  Lives outside the page, so it can:
//   1. Call the Claude API (YouTube's origin would be CORS-blocked)
//   2. Enforce the free/Pro limits in ONE trusted place
//   3. Validate license keys
//   4. Turn Claude's JSON into the 4 study sections
//  The on-page panel (content.js) talks to this via messages.
// ============================================================

// --- Constants -------------------------------------------------
const MODEL          = "claude-sonnet-4-20250514";
const FREE_LIMIT     = 3;                     // lectures per day (free)
const VALID_KEY      = "LECTURELOOP-PRO-2024"; // test Pro key
const MAX_TRANSCRIPT = 16000;                 // chars sent to Claude (safety cap)

// Languages each tier may use
const FREE_LANGUAGES = ["English", "Hindi"];
const ALL_LANGUAGES  = [
  "English", "Hindi", "Hinglish", "Tamil",
  "Telugu", "Bengali", "Marathi", "Kannada"
];

// ------------------------------------------------------------
//  Message router
// ------------------------------------------------------------
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "GET_STATUS") {
    getStatus().then(sendResponse);
    return true; // async response
  }
  if (msg.type === "GENERATE") {
    handleGenerate(msg).then(sendResponse);
    return true;
  }
  if (msg.type === "ACTIVATE_PRO") {
    activatePro(msg.key).then(sendResponse);
    return true;
  }
});

// ============================================================
//  Status: read storage, reset the daily counter if the day
//  changed, and report what the UI needs to render.
// ============================================================
async function getStatus() {
  const data = await chrome.storage.local.get({
    usageCount: 0,
    lastResetDate: "",
    isPro: false,
    apiKey: "",
    language: "English"
  });

  // Reset the daily counter at the start of a new day
  const today = todayString();
  if (data.lastResetDate !== today) {
    data.usageCount = 0;
    await chrome.storage.local.set({ usageCount: 0, lastResetDate: today });
  }

  return {
    isPro: data.isPro,
    usageCount: data.usageCount,
    limit: FREE_LIMIT,
    remaining: data.isPro ? Infinity : Math.max(0, FREE_LIMIT - data.usageCount),
    hasKey: !!data.apiKey,
    language: data.language,
    languages: data.isPro ? ALL_LANGUAGES : FREE_LANGUAGES,
    // Feature gates the UI uses to lock/unlock sections
    features: {
      flashcards: data.isPro,
      allLanguages: data.isPro,
      export: data.isPro
    }
  };
}

// ============================================================
//  Generate study material from a transcript.
// ============================================================
async function handleGenerate({ transcript, title, language }) {
  const status = await getStatus();

  // 1) Must have an API key
  if (!status.hasKey) {
    return { ok: false, reason: "no_key",
             message: "Add your Claude API key in the LectureLoop popup first." };
  }

  // 2) No transcript → graceful stop
  if (!transcript || transcript.trim().length < 30) {
    return { ok: false, reason: "no_transcript",
             message: "No transcript available — try a lecture with captions." };
  }

  // 3) Daily limit for free users
  if (!status.isPro && status.remaining <= 0) {
    return { ok: false, reason: "limit",
             message: "You've used all " + FREE_LIMIT +
                      " free lectures today. Upgrade to Pro for unlimited study sessions." };
  }

  // 4) Clamp the language to what this tier allows
  let lang = language || status.language || "English";
  if (!status.isPro && !FREE_LANGUAGES.includes(lang)) lang = "English";

  // 5) Truncate very long transcripts so we don't blow up the request
  let text = transcript.trim();
  let truncated = false;
  if (text.length > MAX_TRANSCRIPT) {
    text = text.slice(0, MAX_TRANSCRIPT);
    truncated = true;
  }

  // 6) Read the user's own key and call Claude
  const { apiKey } = await chrome.storage.local.get({ apiKey: "" });
  try {
    const study = await callClaude(apiKey, text, title || "Untitled lecture", lang);

    // 7) Count this lecture for free users
    let newCount = status.usageCount;
    if (!status.isPro) {
      newCount = status.usageCount + 1;
      await chrome.storage.local.set({
        usageCount: newCount,
        lastResetDate: todayString()
      });
    }

    return {
      ok: true,
      study,                 // { notes, concepts, keyPoints, flashcards }
      isPro: status.isPro,
      usageCount: newCount,
      limit: FREE_LIMIT,
      remaining: status.isPro ? Infinity : Math.max(0, FREE_LIMIT - newCount),
      features: status.features,
      language: lang,
      truncated
    };
  } catch (err) {
    return { ok: false, reason: "api", message: err.message };
  }
}

// ============================================================
//  The Claude API call — asks for structured JSON study material.
// ============================================================
async function callClaude(apiKey, transcript, title, language) {
  const prompt =
    "You are a study assistant for a student. From this YouTube lecture " +
    "transcript, produce study material in " + language + ". Return as JSON with " +
    "keys: notes (array of bullet strings), concepts (array of " +
    "{term, definition}), keyPoints (array), flashcards (array of " +
    "{question, answer}). Be concise and exam-focused. " +
    "Lecture title: " + title + ". Transcript: " + transcript;

  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": apiKey,
      "anthropic-version": "2023-06-01",
      "anthropic-dangerous-direct-browser-access": "true"
    },
    body: JSON.stringify({
      model: MODEL,
      max_tokens: 2048,
      messages: [{ role: "user", content: prompt }]
    })
  });

  if (!res.ok) {
    const e = await res.json().catch(() => ({}));
    throw new Error(e?.error?.message || ("API error (" + res.status + ")"));
  }

  const data = await res.json();
  const raw = data.content[0].text;
  return parseStudyJSON(raw);
}

// ============================================================
//  Parse Claude's reply into clean study data.
//  Claude sometimes wraps JSON in ```json fences — strip those,
//  then grab the outermost { ... } and parse it.
// ============================================================
function parseStudyJSON(raw) {
  let s = raw.trim();

  // Remove markdown code fences if present
  s = s.replace(/^```(?:json)?\s*/i, "").replace(/```\s*$/i, "");

  // Fall back to slicing from first { to last }
  const start = s.indexOf("{");
  const end = s.lastIndexOf("}");
  if (start !== -1 && end !== -1) s = s.slice(start, end + 1);

  let obj;
  try {
    obj = JSON.parse(s);
  } catch (e) {
    throw new Error("Could not read the AI response. Please try again.");
  }

  // Normalise so the UI never crashes on missing keys
  return {
    notes:      Array.isArray(obj.notes) ? obj.notes : [],
    concepts:   Array.isArray(obj.concepts) ? obj.concepts : [],
    keyPoints:  Array.isArray(obj.keyPoints) ? obj.keyPoints : [],
    flashcards: Array.isArray(obj.flashcards) ? obj.flashcards : []
  };
}

// ============================================================
//  License key validation → flip account to Pro.
// ============================================================
async function activatePro(key) {
  const clean = (key || "").trim().toUpperCase();
  if (!clean) return { ok: false, message: "Please enter a license key." };
  if (clean === VALID_KEY) {
    await chrome.storage.local.set({ isPro: true });
    return { ok: true, message: "Pro activated! Enjoy unlimited study sessions." };
  }
  return { ok: false, message: "Invalid license key. Please try again." };
}

// Helper: today's date as "YYYY-MM-DD"
function todayString() {
  return new Date().toISOString().split("T")[0];
}

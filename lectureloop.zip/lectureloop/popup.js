// ============================================================
//  popup.js — Settings & Pro activation
//  Talks to background.js for status + license validation,
//  and writes the API key / language straight to chrome.storage.
// ============================================================

const ALL_LANGUAGES = ["English","Hindi","Hinglish","Tamil","Telugu","Bengali","Marathi","Kannada"];

// --- DOM refs ---
const apiKeyInput   = document.getElementById("api-key");
const toggleKeyBtn  = document.getElementById("toggle-key");
const saveKeyBtn    = document.getElementById("save-key");
const keyMsg        = document.getElementById("key-msg");
const langSelect    = document.getElementById("language");
const langHint      = document.getElementById("lang-hint");
const usageText     = document.getElementById("usage-text");
const usageBar      = document.getElementById("usage-bar");
const proBadge      = document.getElementById("pro-badge");
const upgradeBanner = document.getElementById("upgrade-banner");
const btnUpgrade    = document.getElementById("btn-upgrade");
const proScreen     = document.getElementById("pro-screen");
const btnActivate   = document.getElementById("btn-activate");
const btnCancel     = document.getElementById("btn-cancel");
const licenseInput  = document.getElementById("license-key");
const actResult     = document.getElementById("activation-result");

// ============================================================
//  Load everything on open
// ============================================================
document.addEventListener("DOMContentLoaded", async () => {
  const stored = await chrome.storage.local.get({ apiKey: "", language: "English" });
  if (stored.apiKey) apiKeyInput.value = stored.apiKey;

  const status = await sendMessage({ type: "GET_STATUS" });
  applyStatus(status, stored.language);
});

// ============================================================
//  Render UI from status (Pro?, languages, usage)
// ============================================================
function applyStatus(status, savedLang) {
  if (!status) return;

  // Pro badge + upgrade banner
  proBadge.classList.toggle("visible", !!status.isPro);
  upgradeBanner.style.display = status.isPro ? "none" : "";

  // Language dropdown — lock the ones this tier can't use
  langSelect.innerHTML = "";
  ALL_LANGUAGES.forEach(l => {
    const allowed = status.languages.includes(l);
    const o = document.createElement("option");
    o.value = l;
    o.textContent = allowed ? l : (l + " 🔒");
    o.disabled = !allowed;
    langSelect.appendChild(o);
  });
  const lang = status.languages.includes(savedLang) ? savedLang : "English";
  langSelect.value = lang;
  langHint.textContent = status.isPro
    ? "All 8 languages unlocked."
    : "Free plan: English & Hindi. Upgrade for 6 more.";

  // Usage
  if (status.isPro) {
    usageText.textContent = "⭐ Pro — unlimited lectures";
    usageBar.style.width = "100%";
  } else {
    usageText.textContent = status.usageCount + " / " + status.limit + " lectures used today";
    usageBar.style.width = (status.usageCount / status.limit * 100) + "%";
  }
}

// ============================================================
//  API key: show/hide, save
// ============================================================
toggleKeyBtn.addEventListener("click", () => {
  const showing = apiKeyInput.type === "text";
  apiKeyInput.type = showing ? "password" : "text";
  toggleKeyBtn.textContent = showing ? "Show" : "Hide";
});

saveKeyBtn.addEventListener("click", async () => {
  const key = apiKeyInput.value.trim();
  if (!key) { showKeyMsg("error", "Please paste your API key first."); return; }
  if (!key.startsWith("sk-ant-")) {
    showKeyMsg("error", "That doesn't look like a Claude key (should start with sk-ant-).");
    return;
  }
  await chrome.storage.local.set({ apiKey: key });
  showKeyMsg("ok", "✓ Key saved locally on this device.");
});

function showKeyMsg(type, msg) {
  keyMsg.className = "inline-msg " + type;
  keyMsg.textContent = msg;
}

// ============================================================
//  Language default
// ============================================================
langSelect.addEventListener("change", () => {
  chrome.storage.local.set({ language: langSelect.value });
});

// ============================================================
//  Pro activation flow
// ============================================================
btnUpgrade.addEventListener("click", () => {
  actResult.className = "activation-result";
  actResult.textContent = "";
  licenseInput.value = "";
  proScreen.classList.add("visible");
});
btnCancel.addEventListener("click", () => proScreen.classList.remove("visible"));

btnActivate.addEventListener("click", activate);
licenseInput.addEventListener("keydown", (e) => { if (e.key === "Enter") activate(); });

async function activate() {
  const result = await sendMessage({ type: "ACTIVATE_PRO", key: licenseInput.value });
  if (result.ok) {
    actResult.className = "activation-result success";
    actResult.textContent = "🎉 Pro Activated ✓ " + result.message;
    setTimeout(async () => {
      proScreen.classList.remove("visible");
      const status = await sendMessage({ type: "GET_STATUS" });
      const stored = await chrome.storage.local.get({ language: "English" });
      applyStatus(status, stored.language);
    }, 1600);
  } else {
    actResult.className = "activation-result error";
    actResult.textContent = result.message;
  }
}

// ============================================================
//  Messaging helper
// ============================================================
function sendMessage(msg) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(msg, (resp) => {
      if (chrome.runtime.lastError) resolve(null);
      else resolve(resp);
    });
  });
}

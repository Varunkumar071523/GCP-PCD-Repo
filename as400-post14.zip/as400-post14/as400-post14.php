<?php
/**
 * Plugin Name: AS400 Decoded - Post 14 IBM i and the Cloud
 * Description: Publishes Post 14 with SEO metadata, tags, custom slug, no Gutenberg
 * Version: 1.0
 */

if (!defined('ABSPATH')) exit;

add_action('init', 'as400_ensure_post14_exists');
function as400_ensure_post14_exists() {

    // Check already published
    $existing = get_posts(array(
        'post_type'      => 'post',
        'post_status'    => array('publish', 'draft', 'pending'),
        'posts_per_page' => 1,
        'meta_key'       => '_as400_post14',
        'meta_value'     => '1',
    ));
    if (!empty($existing)) return;

    $by_slug = get_page_by_path('ibm-i-cloud-modernisation-hybrid-architecture-2026', OBJECT, 'post');
    if ($by_slug) {
        add_post_meta($by_slug->ID, '_as400_post14', '1', true);
        return;
    }

    // ── Category ──────────────────────────────────
    $cat = get_category_by_slug('modern-integrations');
    if (!$cat) $cat = get_category_by_slug('operations-admin');
    $cat_id = $cat ? $cat->term_id : 1;

    // ── Tags ──────────────────────────────────────
    $tag_names = array(
        'IBM i',
        'AS400',
        'iSeries',
        'cloud',
        'IBM Cloud',
        'modernisation',
        'hybrid architecture',
        'PowerVS',
        'REST API',
        'data replication',
        'Change Data Capture',
        'CDC',
        'MuleSoft',
        'Snowflake',
        'RPG modernisation',
        'cloud migration',
        'digital transformation',
        'PASE',
        'Node.js IBM i',
        'IBM i 2026'
    );
    $tag_ids = array();
    foreach ($tag_names as $tag) {
        $term = term_exists($tag, 'post_tag');
        if (!$term) {
            $term = wp_insert_term($tag, 'post_tag');
        }
        if (!is_wp_error($term)) {
            $tag_ids[] = is_array($term) ? (int) $term['term_id'] : (int) $term;
        }
    }

    // ── Content ───────────────────────────────────
    $content = file_get_contents(dirname(__FILE__) . '/post14-content.html');

    // ── Insert post ───────────────────────────────
    $post_id = wp_insert_post(array(
        'post_title'   => 'IBM i and the cloud: modernisation strategies, hybrid architectures, and what staying on IBM i actually means in 2026',
        'post_name'    => 'ibm-i-cloud-modernisation-hybrid-architecture-2026',
        'post_content' => $content,
        'post_excerpt' => 'The "should we leave IBM i?" conversation has been happening for twenty years. The shops that handled it well are running modern hybrid architectures in 2026 — IBM i at the transactional core, cloud services handling front ends, analytics, and integration. Here is what that actually looks like.',
        'post_status'  => 'publish',
        'post_type'    => 'post',
        'post_category'=> array($cat_id),
        'tags_input'   => $tag_ids,
        'post_author'  => 1,
        'post_date'    => current_time('mysql'),
        'meta_input'   => array(

            // ── Internal marker ───────────────────
            '_as400_post14' => '1',

            // ── Yoast SEO ─────────────────────────
            '_yoast_wpseo_title'         => 'IBM i and the Cloud: Modernisation Strategies and Hybrid Architecture in 2026',
            '_yoast_wpseo_metadesc'      => 'What does staying on IBM i actually mean in 2026? This post covers hybrid architectures, cloud hosting on IBM Cloud PowerVS, data replication to analytics platforms, and how to have the right modernisation conversation.',
            '_yoast_wpseo_focuskw'       => 'IBM i cloud modernisation 2026',
            '_yoast_wpseo_canonical'     => 'https://as400decoded.com/ibm-i-cloud-modernisation-hybrid-architecture-2026/',
            '_yoast_wpseo_opengraph-title'       => 'IBM i and the Cloud: Modernisation Strategies in 2026',
            '_yoast_wpseo_opengraph-description' => 'Hybrid architecture, IBM Cloud PowerVS, REST APIs, CDC replication, and what a modern IBM i shop actually looks like today.',
            '_yoast_wpseo_twitter-title'         => 'IBM i and the Cloud — what modernisation actually looks like in 2026',
            '_yoast_wpseo_twitter-description'   => 'Not a debate about leaving the platform. A practical guide to hybrid IBM i architecture, cloud hosting, and modern tooling in 2026.',

            // ── All in One SEO ────────────────────
            '_aioseo_title'              => 'IBM i and the Cloud: Modernisation Strategies and Hybrid Architecture in 2026',
            '_aioseo_description'        => 'What does staying on IBM i mean in 2026? Covers hybrid architectures, IBM Cloud PowerVS hosting, CDC data replication, REST APIs, and the modernisation conversation worth having.',
            '_aioseo_keywords'           => 'IBM i cloud,IBM i modernisation 2026,hybrid IBM i architecture,IBM Cloud PowerVS,AS400 cloud migration,RPG modernisation,IBM i REST API',
            '_aioseo_og_title'           => 'IBM i and the Cloud: Modernisation Strategies in 2026',
            '_aioseo_og_description'     => 'Hybrid architecture, IBM Cloud PowerVS, REST APIs, CDC replication, and what a modern IBM i shop actually looks like today.',
            '_aioseo_twitter_title'      => 'IBM i and the Cloud — what modernisation actually looks like in 2026',
            '_aioseo_twitter_description'=> 'Not a debate about leaving the platform. A practical guide to hybrid IBM i architecture in 2026.',

            // ── Rank Math ─────────────────────────
            'rank_math_focus_keyword'    => 'IBM i cloud modernisation 2026',
            'rank_math_description'      => 'What does staying on IBM i mean in 2026? Covers hybrid architectures, IBM Cloud PowerVS hosting, CDC data replication, REST APIs, and the modernisation conversation worth having.',
            'rank_math_title'            => 'IBM i and the Cloud: Modernisation Strategies and Hybrid Architecture in 2026',

            // ── Disable Gutenberg ─────────────────
            '_classic_editor_enabled'    => 'classic',
        ),
    ));

    // ── Attach tags ───────────────────────────────
    if ($post_id && !is_wp_error($post_id) && !empty($tag_ids)) {
        wp_set_post_tags($post_id, $tag_ids, false);
    }
}

/* ─────────────────────────────────────────────────
   Force classic editor for this post
   ───────────────────────────────────────────────── */
add_filter('use_block_editor_for_post', 'as400_post14_use_classic', 10, 2);
function as400_post14_use_classic($use_block_editor, $post) {
    if (!$post) return $use_block_editor;
    $marker = get_post_meta($post->ID, '_as400_post14', true);
    if ($marker === '1') {
        return false;
    }
    return $use_block_editor;
}

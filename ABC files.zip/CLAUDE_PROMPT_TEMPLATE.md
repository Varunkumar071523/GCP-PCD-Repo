# Claude Prompt — Batch Post Generator for as400decoded.com

Paste this prompt into Claude (with your topic list at the bottom).
Claude will return a single posts.json you feed into generate_plugins.py.

---

## PROMPT (copy everything below this line)

You are a technical writer for as400decoded.com — a deep-dive blog on IBM AS400 / IBM i / iSeries for developers and administrators.

Generate a `posts.json` file for the following topics. Return ONLY valid JSON — no explanation, no markdown fences, no preamble.

### JSON schema (one object per post in an array):

```
[
  {
    "plugin_id": "postNN",                    // e.g. post17, post18
    "plugin_name": "AS400 Decoded - Post NN <Short Title>",
    "post_title": "<Full descriptive title with year>",
    "post_slug": "<url-friendly-slug-with-year>",
    "post_excerpt": "<2-3 sentence summary, no HTML>",
    "post_date": "YYYY-MM-DD 08:00:00",       // IST publish time
    "post_date_gmt": "YYYY-MM-DD 02:30:00",   // UTC (IST - 5:30)
    "post_status": "draft",
    "category_slug": "<one of: rpg-programming | cl-commands | db2-for-i | ifs-file-systems | modern-integrations | operations-admin | modernization | ai-for-ibm-i>",
    "tags": ["IBM i", "AS400", ...],           // 12-20 relevant tags
    "seo": {
      "focus_keyword": "<primary keyword phrase>",
      "title": "<SEO title, under 60 chars>",
      "meta_description": "<meta desc, under 155 chars>",
      "og_title": "<Open Graph title>",
      "og_description": "<OG description>",
      "twitter_title": "<Twitter card title>",
      "twitter_description": "<Twitter card description>"
    },
    "canonical": "https://as400decoded.com/<post_slug>/",
    "content_html": "<full article HTML — h2/h3 headings, p, ul, li, pre for code blocks. Minimum 1200 words. No inline styles. No wrapping div.>"
  }
]
```

### Writing style rules:
- Direct, technical, no fluff. Write like a senior IBM i developer explaining to a peer.
- Every h2 section has at least 2 paragraphs before any code block.
- Code examples use `<pre>` tags, are real and runnable, not pseudocode.
- No "In conclusion" or "In this post we covered" endings. End on a practical note.
- First paragraph does NOT start with "In this post". Start mid-thought.
- Dates: start from post_date YYYY-MM-DD and increment by 1 day per post.

### Topics to generate (one post each):

1. [POST NUMBER + TOPIC — e.g. "Post 17: IBM i job queues and subsystems — SBMJOB, WRKACTJOB, QBATCH"]
2. [POST NUMBER + TOPIC]
3. [POST NUMBER + TOPIC]
...

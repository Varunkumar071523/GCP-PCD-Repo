import os
import json

# ==========================================
# CONFIGURATION
# ==========================================

# Path to your posts.json file (Claude's output)
POSTS_JSON = r"C:\Anant study\AS400 Blogs Test\posts.json"

# Output folder — same SOURCE_DIR that Zip.py reads from
OUTPUT_DIR = r"C:\Anant study\AS400 Blogs Test\GCP-PCD-Repo"

# Your WordPress site URL
SITE_URL = "https://as400decoded.com"

# WordPress author ID (1 = admin)
AUTHOR_ID = 1

# ==========================================
# LOAD POSTS JSON
# ==========================================

with open(POSTS_JSON, "r", encoding="utf-8") as f:
    posts = json.load(f)

print(f"Found {len(posts)} posts to generate.\n")

# ==========================================
# GENERATE PLUGIN FOR EACH POST
# ==========================================

for post in posts:

    pid        = post["plugin_id"]           # e.g. post17
    slug       = post["post_slug"]
    title      = post["post_title"]
    excerpt    = post["post_excerpt"]
    pub_date   = post["post_date"]           # local time  e.g. 2026-05-27 08:00:00
    pub_gmt    = post["post_date_gmt"]       # UTC         e.g. 2026-05-27 02:30:00
    status     = post.get("post_status", "draft")
    cat_slug   = post["category_slug"]
    tags       = post["tags"]
    seo        = post["seo"]
    canonical  = post["canonical"]
    content    = post["content_html"]
    plugin_name = post["plugin_name"]

    # ── Folder & file names ──────────────────────
    folder_name = f"as400-{pid}"
    plugin_file = f"as400-{pid}.php"
    content_file = f"{pid}-content.html"
    meta_key     = f"_as400_{pid}"

    folder_path = os.path.join(OUTPUT_DIR, folder_name)
    os.makedirs(folder_path, exist_ok=True)

    # ── Write HTML content file ──────────────────
    html_path = os.path.join(folder_path, content_file)
    with open(html_path, "w", encoding="utf-8") as f:
        f.write(content)

    # ── Build tag array for PHP ──────────────────
    tag_lines = "\n".join([f"        '{t}'," for t in tags])

    # ── Write PHP plugin file ────────────────────
    php = f"""<?php
/**
 * Plugin Name: {plugin_name}
 * Description: Publishes {pid} with SEO metadata, tags, custom slug
 * Version: 1.0
 */

if (!defined('ABSPATH')) exit;

add_action('init', 'as400_ensure_{pid}_exists');
function as400_ensure_{pid}_exists() {{

    // Already published — skip
    $existing = get_posts(array(
        'post_type'      => 'post',
        'post_status'    => array('publish', 'future', 'draft', 'pending'),
        'posts_per_page' => 1,
        'meta_key'       => '{meta_key}',
        'meta_value'     => '1',
    ));
    if (!empty($existing)) return;

    $by_slug = get_page_by_path('{slug}', OBJECT, 'post');
    if ($by_slug) {{
        add_post_meta($by_slug->ID, '{meta_key}', '1', true);
        return;
    }}

    // ── Category ──────────────────────────────────
    $cat = get_category_by_slug('{cat_slug}');
    if (!$cat) $cat = get_category_by_slug('operations-admin');
    $cat_id = $cat ? $cat->term_id : 1;

    // ── Tags ──────────────────────────────────────
    $tag_names = array(
{tag_lines}
    );
    $tag_ids = array();
    foreach ($tag_names as $tag) {{
        $term = term_exists($tag, 'post_tag');
        if (!$term) $term = wp_insert_term($tag, 'post_tag');
        if (!is_wp_error($term)) {{
            $tag_ids[] = is_array($term) ? (int)$term['term_id'] : (int)$term;
        }}
    }}

    // ── Content ───────────────────────────────────
    $content = file_get_contents(dirname(__FILE__) . '/{content_file}');

    // ── Insert post ───────────────────────────────
    $post_id = wp_insert_post(array(
        'post_title'    => '{title}',
        'post_name'     => '{slug}',
        'post_content'  => $content,
        'post_excerpt'  => '{excerpt}',
        'post_status'   => '{status}',
        'post_type'     => 'post',
        'post_category' => array($cat_id),
        'tags_input'    => $tag_ids,
        'post_author'   => {AUTHOR_ID},
        'post_date'     => '{pub_date}',
        'post_date_gmt' => '{pub_gmt}',
        'meta_input'    => array(

            '_as400_{pid}' => '1',

            // ── Yoast SEO ─────────────────────────
            '_yoast_wpseo_title'               => '{seo["title"]}',
            '_yoast_wpseo_metadesc'            => '{seo["meta_description"]}',
            '_yoast_wpseo_focuskw'             => '{seo["focus_keyword"]}',
            '_yoast_wpseo_canonical'           => '{canonical}',
            '_yoast_wpseo_opengraph-title'     => '{seo["og_title"]}',
            '_yoast_wpseo_opengraph-description' => '{seo["og_description"]}',
            '_yoast_wpseo_twitter-title'       => '{seo["twitter_title"]}',
            '_yoast_wpseo_twitter-description' => '{seo["twitter_description"]}',

            // ── Rank Math ─────────────────────────
            'rank_math_focus_keyword'  => '{seo["focus_keyword"]}',
            'rank_math_description'    => '{seo["meta_description"]}',
            'rank_math_title'          => '{seo["title"]}',

            // ── Classic editor ────────────────────
            '_classic_editor_enabled'  => 'classic',
        ),
    ));

    if ($post_id && !is_wp_error($post_id) && !empty($tag_ids)) {{
        wp_set_post_tags($post_id, $tag_ids, false);
    }}
}}

// Force classic editor for this post
add_filter('use_block_editor_for_post', 'as400_{pid}_use_classic', 10, 2);
function as400_{pid}_use_classic($use_block_editor, $post) {{
    if (!$post) return $use_block_editor;
    if (get_post_meta($post->ID, '{meta_key}', true) === '1') return false;
    return $use_block_editor;
}}
"""

    php_path = os.path.join(folder_path, plugin_file)
    with open(php_path, "w", encoding="utf-8") as f:
        f.write(php)

    print(f"Generated: {folder_name}/  ({plugin_file} + {content_file})")

print(f"\nAll {len(posts)} plugin folders created in: {OUTPUT_DIR}")
print("Run Zip.py next to package them, then upload_and_activate.py to deploy.")

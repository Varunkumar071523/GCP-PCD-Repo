'use strict';

// ============================================================
// LOCKIN LITE — background.js
// Zero AI. Blocking is a pure domain lookup against the user's
// blocklist. Instant, offline, private.
// ============================================================

const FREE_SESSION_LIMIT_MIN = 30;
const FREE_SESSIONS_PER_DAY  = 2;  // free: limited session count
const VALID_PRO_KEYS = ['LOCKIN-LITE-PRO-2024'];

// ── Built-in category presets ────────────────────────────────
// Keys match the category IDs stored in chrome.storage
const PRESET_DOMAINS = {
  social: [
    'facebook.com','twitter.com','x.com','instagram.com','tiktok.com',
    'snapchat.com','reddit.com','pinterest.com','tumblr.com','threads.net',
    'mastodon.social','bluesky.app','bereal.com'
  ],
  entertainment: [
    'youtube.com','netflix.com','hulu.com','twitch.tv','disneyplus.com',
    'primevideo.com','hbomax.com','max.com','peacocktv.com','crunchyroll.com',
    'funimation.com','vimeo.com','dailymotion.com','rumble.com'
  ],
  music: [
    'spotify.com','soundcloud.com','music.apple.com','tidal.com',
    'deezer.com','pandora.com','last.fm','bandcamp.com'
  ],
  news: [
    'cnn.com','foxnews.com','bbc.com','bbc.co.uk','nytimes.com',
    'theguardian.com','huffpost.com','buzzfeed.com','msn.com',
    'news.google.com','flipboard.com','apple.news','wsj.com',
    'washingtonpost.com','nbcnews.com','cbsnews.com','abcnews.go.com'
  ],
  shopping: [
    'amazon.com','ebay.com','etsy.com','aliexpress.com','wish.com',
    'walmart.com','target.com','bestbuy.com','wayfair.com','zappos.com',
    'asos.com','shein.com','zara.com','h&m.com','hm.com'
  ],
  gaming: [
    'store.steampowered.com','roblox.com','minecraft.net','epicgames.com',
    'ea.com','ubisoft.com','itch.io','gog.com','ign.com','gamespot.com',
    'kotaku.com','polygon.com'
  ],
  messaging: [
    'web.whatsapp.com','telegram.org','discord.com','slack.com',
    'messenger.com','signal.org','line.me','kik.com','viber.com'
  ],
};

// ── In-memory cache (rebuilt from storage on wake-up) ────────
// Unlike the AI version, there's nothing expensive to cache —
// lookups are instant. We just hold the active blocklist in memory
// to avoid a storage read on every navigation.
let activeBlocklist  = new Set(); // populated when session starts
let tempPasses       = {};        // { 'domain': expiryTimestamp }

// ============================================================
// INIT
// ============================================================
async function init() {
  try {
    const data = await chrome.storage.local.get(['activeSession', 'tempPasses']);
    if (data.activeSession) {
      tempPasses = data.tempPasses || {};
      activeBlocklist = await buildBlocklist();
    }
  } catch (e) {
    console.error('[Lockin Lite] init error:', e);
  }
}
init();

// ============================================================
// Build the active blocklist from enabled categories + custom domains
// ============================================================
async function buildBlocklist() {
  const data = await chrome.storage.local.get(['enabledCategories', 'customDomains']);
  const enabled  = data.enabledCategories || {};
  const custom   = data.customDomains     || [];
  const domains  = new Set();

  // Add preset category domains for every enabled category
  for (const [cat, isOn] of Object.entries(enabled)) {
    if (isOn && PRESET_DOMAINS[cat]) {
      PRESET_DOMAINS[cat].forEach(d => domains.add(d));
    }
  }

  // Add user's custom domains
  custom.forEach(d => domains.add(normalizeDomain(d)));

  return domains;
}

// ============================================================
// NAVIGATION INTERCEPTOR
// ============================================================
chrome.webNavigation.onBeforeNavigate.addListener(async (details) => {
  if (details.frameId !== 0) return;
  if (!details.url.startsWith('http://') && !details.url.startsWith('https://')) return;
  if (details.url.includes(chrome.runtime.id)) return;

  const storage = await chrome.storage.local.get(['activeSession', 'task', 'startTime', 'isPro']);
  if (!storage.activeSession) return;

  // Free tier: auto-end at 30 minutes
  if (!storage.isPro) {
    const elapsed = Date.now() - (storage.startTime || Date.now());
    if (elapsed >= FREE_SESSION_LIMIT_MIN * 60 * 1000) {
      await endSession(true);
      return;
    }
  }

  let domain;
  try {
    domain = normalizeDomain(new URL(details.url).hostname);
  } catch {
    return;
  }

  // Check temp pass
  if (tempPasses[domain] && tempPasses[domain] > Date.now()) return;
  if (tempPasses[domain] && tempPasses[domain] <= Date.now()) {
    delete tempPasses[domain]; // expired
  }

  // Check blocklist — O(1) lookup
  if (isBlocked(domain)) {
    await incrementStat('blocked');
    redirectToBlocked(details.tabId, details.url, domain, storage.task);
  } else {
    await incrementStat('allowed');
  }
});

// ── Check if a domain (or its parent) is on the blocklist ───
function isBlocked(domain) {
  if (activeBlocklist.has(domain)) return true;
  // Also match subdomains: music.youtube.com → youtube.com
  const parts = domain.split('.');
  for (let i = 1; i < parts.length - 1; i++) {
    const parent = parts.slice(i).join('.');
    if (activeBlocklist.has(parent)) return true;
  }
  return false;
}

function normalizeDomain(d) {
  return (d || '').toLowerCase().replace(/^www\./, '').trim();
}

// ============================================================
// REDIRECT TO BLOCKED PAGE
// ============================================================
function redirectToBlocked(tabId, originalUrl, domain, task) {
  const blockedUrl =
    chrome.runtime.getURL('blocked.html') +
    '?url='    + encodeURIComponent(originalUrl) +
    '&domain=' + encodeURIComponent(domain) +
    '&task='   + encodeURIComponent(task || '');

  chrome.tabs.update(tabId, { url: blockedUrl }).catch(err =>
    console.error('[Lockin Lite] Redirect failed:', err)
  );
}

// ============================================================
// MESSAGE HANDLER
// ============================================================
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  const handle = async () => {
    switch (message.type) {
      case 'START_SESSION':      return startSession(message.task);
      case 'END_SESSION':        return endSession(false);
      case 'REQUEST_TEMP_PASS':  return grantTempPass(message.domain, message.reason);
      case 'REMOVE_FROM_BLOCKLIST': return removeFromBlocklist(message.domain);
      case 'GET_STATS':          return getStats();
      case 'ACTIVATE_PRO':       return activatePro(message.licenseKey);
      case 'CLEAR_SUMMARY':
        await chrome.storage.local.set({ lastSessionSummary: null });
        return { ok: true };
      case 'SAVE_BLOCKLIST':
        await chrome.storage.local.set({
          enabledCategories: message.enabledCategories,
          customDomains:     message.customDomains,
        });
        // Rebuild in-memory blocklist immediately
        activeBlocklist = await buildBlocklist();
        return { ok: true };
      default:
        return { ok: false, error: 'unknown_message' };
    }
  };

  handle().then(sendResponse).catch(err => {
    console.error('[Lockin Lite] Handler error:', err);
    sendResponse({ ok: false, error: err.message });
  });
  return true;
});

// ============================================================
// SESSION: START
// ============================================================
async function startSession(task) {
  const storage = await chrome.storage.local.get([
    'isPro', 'sessionsToday', 'lastResetDate', 'enabledCategories', 'customDomains'
  ]);

  const today = todayString();
  let sessionsToday = storage.sessionsToday || 0;
  if (storage.lastResetDate !== today) sessionsToday = 0;

  // Free: 2 sessions/day
  if (!storage.isPro && sessionsToday >= FREE_SESSIONS_PER_DAY) {
    return { ok: false, error: 'daily_limit' };
  }

  // Must have at least one domain to block
  activeBlocklist = await buildBlocklist();
  if (activeBlocklist.size === 0) {
    return { ok: false, error: 'empty_blocklist' };
  }

  tempPasses = {};
  const startTime = Date.now();

  await chrome.storage.local.set({
    activeSession:      true,
    task:               (task || '').trim(),
    startTime,
    tempPasses:         {},
    sessionStats:       { allowed: 0, blocked: 0, breakRequests: 0 },
    sessionsToday:      sessionsToday + 1,
    lastResetDate:      today,
    lastSessionSummary: null,
  });

  if (!storage.isPro) {
    chrome.alarms.create('sessionTimeLimit', { delayInMinutes: FREE_SESSION_LIMIT_MIN });
  }

  return { ok: true, startTime, blocklistSize: activeBlocklist.size };
}

// ============================================================
// SESSION: END
// ============================================================
async function endSession(autoEnded = false) {
  const storage = await chrome.storage.local.get(['sessionStats', 'startTime', 'task']);
  const now     = Date.now();
  const stats   = storage.sessionStats || { allowed: 0, blocked: 0, breakRequests: 0 };

  const summary = {
    task:          storage.task || '',
    durationMin:   Math.max(0, Math.round((now - (storage.startTime || now)) / 60000)),
    allowed:       stats.allowed       || 0,
    blocked:       stats.blocked       || 0,
    breakRequests: stats.breakRequests || 0,
    endTime:       now,
    autoEnded,
  };

  activeBlocklist = new Set();
  tempPasses      = {};

  await chrome.storage.local.set({
    activeSession:      false,
    task:               '',
    startTime:          null,
    tempPasses:         {},
    lastSessionSummary: summary,
  });

  chrome.alarms.clear('sessionTimeLimit');
  return { ok: true, summary };
}

// ============================================================
// TEMP PASS (5 minutes)
// ============================================================
async function grantTempPass(domain, reason) {
  tempPasses[domain] = Date.now() + 5 * 60 * 1000;
  await chrome.storage.local.set({ tempPasses });

  const { sessionStats } = await chrome.storage.local.get('sessionStats');
  const stats = sessionStats || { allowed: 0, blocked: 0, breakRequests: 0 };
  stats.breakRequests = (stats.breakRequests || 0) + 1;
  await chrome.storage.local.set({ sessionStats: stats });

  return { ok: true, expiresAt: tempPasses[domain] };
}

// ============================================================
// REMOVE A DOMAIN FROM BLOCKLIST (from blocked.html)
// ============================================================
async function removeFromBlocklist(domain) {
  const data = await chrome.storage.local.get(['customDomains', 'enabledCategories']);
  const custom = (data.customDomains || []).filter(d => d !== domain);
  await chrome.storage.local.set({ customDomains: custom });

  // Also remove from in-memory set so current session respects the change
  activeBlocklist.delete(domain);

  return { ok: true };
}

// ============================================================
// STATS
// ============================================================
async function getStats() {
  const data = await chrome.storage.local.get([
    'activeSession', 'task', 'startTime', 'sessionStats',
    'isPro', 'lastSessionSummary', 'sessionsToday', 'lastResetDate',
    'enabledCategories', 'customDomains'
  ]);
  return { ok: true, ...data, blocklistSize: activeBlocklist.size };
}

async function incrementStat(field) {
  const { sessionStats } = await chrome.storage.local.get('sessionStats');
  const stats = sessionStats || { allowed: 0, blocked: 0, breakRequests: 0 };
  stats[field] = (stats[field] || 0) + 1;
  await chrome.storage.local.set({ sessionStats: stats });
}

// ============================================================
// PRO ACTIVATION
// ============================================================
async function activatePro(licenseKey) {
  if (VALID_PRO_KEYS.includes((licenseKey || '').trim().toUpperCase())) {
    await chrome.storage.local.set({ isPro: true });
    return { ok: true };
  }
  return { ok: false, error: 'invalid_key' };
}

// ============================================================
// HELPERS
// ============================================================
function todayString() {
  return new Date().toISOString().split('T')[0];
}

// ── Alarm: auto-end free session at 30 min ───────────────────
chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name !== 'sessionTimeLimit') return;
  await endSession(true);
  try {
    chrome.notifications.create('sessionEnded', {
      type:    'basic',
      iconUrl: chrome.runtime.getURL('icons/icon48.png'),
      title:   'Lockin Lite — Session Complete!',
      message: `Your ${FREE_SESSION_LIMIT_MIN}-min focus session ended. Check your stats!`
    });
  } catch (e) { /* ignore */ }
});

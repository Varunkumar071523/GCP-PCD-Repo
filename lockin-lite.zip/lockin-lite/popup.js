'use strict';

// ============================================================
// POPUP.JS — Lockin Lite (no AI)
// ============================================================

const FREE_SESSION_LIMIT_MIN = 30;

// Category metadata for the blocklist manager UI
const CATEGORIES = [
  { id: 'social',        emoji: '📱', name: 'Social Media',  count: 13 },
  { id: 'entertainment', emoji: '🎬', name: 'Entertainment', count: 14 },
  { id: 'music',         emoji: '🎵', name: 'Music & Audio', count:  8 },
  { id: 'news',          emoji: '📰', name: 'News & Media',  count: 17 },
  { id: 'shopping',      emoji: '🛍️', name: 'Shopping',      count: 15 },
  { id: 'gaming',        emoji: '🎮', name: 'Gaming',        count: 12 },
  { id: 'messaging',     emoji: '💬', name: 'Messaging',     count:  9 },
];

// ── DOM refs ─────────────────────────────────────────────────
const screens = {
  idle:      document.getElementById('screen-idle'),
  active:    document.getElementById('screen-active'),
  summary:   document.getElementById('screen-summary'),
  blocklist: document.getElementById('screen-blocklist'),
  settings:  document.getElementById('screen-settings'),
};

// Idle
const taskInput          = document.getElementById('task-input');
const charCount          = document.getElementById('char-count');
const startBtn           = document.getElementById('start-btn');
const idleTierBadge      = document.getElementById('idle-tier-badge');
const idleSettingsBtn    = document.getElementById('idle-settings-btn');
const idleManageBtn      = document.getElementById('idle-manage-btn');
const blTotalCount       = document.getElementById('bl-total-count');
const blCatsLabel        = document.getElementById('bl-cats-label');
const sessionsRemaining  = document.getElementById('sessions-remaining-label');
const idleFeedback       = document.getElementById('idle-feedback');
const idleLastSummary    = document.getElementById('idle-last-summary');
const idleLastText       = document.getElementById('idle-last-text');

// Active
const timerDisplay   = document.getElementById('timer-display');
const activeTaskText = document.getElementById('active-task-text');
const statAllowed    = document.getElementById('stat-allowed');
const statBlocked    = document.getElementById('stat-blocked');
const statBreaks     = document.getElementById('stat-breaks');
const endBtn         = document.getElementById('end-btn');
const freeBarWrap    = document.getElementById('free-bar-wrap');
const freeBar        = document.getElementById('free-bar');
const freeBarLabel   = document.getElementById('free-bar-label');

// Summary
const summaryDuration = document.getElementById('summary-duration');
const summaryAllowed  = document.getElementById('summary-allowed');
const summaryBlocked  = document.getElementById('summary-blocked');
const summaryMsg      = document.getElementById('summary-msg');
const summaryTaskChip = document.getElementById('summary-task-chip');
const newSessionBtn   = document.getElementById('new-session-btn');

// Blocklist manager
const blBackBtn          = document.getElementById('bl-back-btn');
const catGrid            = document.getElementById('cat-grid');
const customDomainInput  = document.getElementById('custom-domain-input');
const addDomainBtn       = document.getElementById('add-domain-btn');
const domainTagsEl       = document.getElementById('domain-tags');
const noCustomMsg        = document.getElementById('no-custom-msg');
const saveBlocklistBtn   = document.getElementById('save-blocklist-btn');
const blHeaderCount      = document.getElementById('bl-header-count');
const blFeedback         = document.getElementById('bl-feedback');

// Settings
const settingsBackBtn   = document.getElementById('settings-back-btn');
const settingsTierBadge = document.getElementById('settings-tier-badge');
const proStatusBadge    = document.getElementById('pro-status-badge');
const proUnlockSection  = document.getElementById('pro-unlock-section');
const proActiveSection  = document.getElementById('pro-active-section');
const licenseInput      = document.getElementById('license-input');
const activateBtn       = document.getElementById('activate-btn');
const usageCount        = document.getElementById('usage-count');
const settingsFeedback  = document.getElementById('settings-feedback');

// ── Local state for the blocklist editor ─────────────────────
let draftCategories  = {};  // { social: true, entertainment: false, … }
let draftCustom      = [];  // ['reddit.com', 'chess.com']
let previousScreen   = 'idle';

// ── Timers ───────────────────────────────────────────────────
let timerInterval = null;
let statsInterval = null;

// ============================================================
// INIT
// ============================================================
async function init() {
  const data = await chrome.storage.local.get([
    'activeSession', 'task', 'startTime', 'isPro',
    'lastSessionSummary', 'sessionsToday', 'lastResetDate',
    'enabledCategories', 'customDomains',
  ]);

  // Reset daily counter on new day
  const today = todayString();
  if (data.lastResetDate !== today) {
    await chrome.storage.local.set({ sessionsToday: 0, lastResetDate: today });
    data.sessionsToday = 0;
  }

  if (data.activeSession) {
    showScreen('active');
    populateActiveScreen(data);
    return;
  }

  if (data.lastSessionSummary && isRecent(data.lastSessionSummary.endTime)) {
    showScreen('summary');
    populateSummaryScreen(data.lastSessionSummary);
    return;
  }

  showScreen('idle');
  populateIdleScreen(data);
}

// ============================================================
// SCREEN SWITCHING
// ============================================================
function showScreen(name) {
  Object.values(screens).forEach(s => s.classList.add('hidden'));
  screens[name].classList.remove('hidden');
}

// ============================================================
// SCREEN: IDLE
// ============================================================
function populateIdleScreen(data) {
  // Tier badge
  if (data.isPro) {
    idleTierBadge.textContent = '⭐ PRO';
    idleTierBadge.className   = 'badge badge-pro';
  }

  // Sessions remaining
  if (!data.isPro) {
    const used = data.sessionsToday || 0;
    const left = Math.max(0, 2 - used);
    sessionsRemaining.innerHTML =
      `<span>${left}</span> free session${left !== 1 ? 's' : ''} remaining today`;
    sessionsRemaining.style.color = left === 0 ? 'var(--danger)' : '';
  } else {
    sessionsRemaining.textContent = 'Unlimited sessions — Pro';
    sessionsRemaining.style.color = 'var(--accent)';
  }

  // Blocklist summary card
  refreshBlocklistSummary(data.enabledCategories || {}, data.customDomains || []);

  // Last session snippet
  if (data.lastSessionSummary) {
    const s = data.lastSessionSummary;
    idleLastText.textContent =
      `Last: ${s.durationMin}min · blocked ${s.blocked} site${s.blocked !== 1 ? 's' : ''}`;
    idleLastSummary.classList.remove('hidden');
  }
}

// Updates the "X sites blocked" summary on the idle screen
function refreshBlocklistSummary(enabledCats, customDomains) {
  // Count total domains across enabled categories
  let total = 0;
  const enabledNames = [];
  for (const cat of CATEGORIES) {
    if (enabledCats[cat.id]) {
      total += cat.count;
      enabledNames.push(cat.name);
    }
  }
  total += customDomains.length;

  blTotalCount.textContent = total;

  if (enabledNames.length === 0 && customDomains.length === 0) {
    blCatsLabel.textContent  = 'No categories selected';
    blTotalCount.style.color = 'var(--danger)';
  } else {
    const catPart    = enabledNames.length > 0
      ? enabledNames.slice(0, 2).join(', ') + (enabledNames.length > 2 ? ` +${enabledNames.length-2}` : '')
      : '';
    const customPart = customDomains.length > 0 ? `${customDomains.length} custom` : '';
    blCatsLabel.textContent  = [catPart, customPart].filter(Boolean).join(' · ');
    blTotalCount.style.color = 'var(--accent)';
  }
}

taskInput.addEventListener('input', () => {
  const len = taskInput.value.length;
  charCount.textContent = `${len} / 80`;
});

idleManageBtn.addEventListener('click', () => {
  previousScreen = 'idle';
  openBlocklistManager();
});

idleSettingsBtn.addEventListener('click', () => {
  previousScreen = 'idle';
  openSettings();
});

startBtn.addEventListener('click', async () => {
  startBtn.disabled    = true;
  startBtn.textContent = 'Starting…';

  const result = await chrome.runtime.sendMessage({
    type: 'START_SESSION',
    task: taskInput.value.trim(),
  });

  if (!result.ok) {
    startBtn.disabled    = false;
    startBtn.textContent = '🚀 Start Focus Session';
    const msgs = {
      daily_limit:     'You\'ve used your 2 free sessions today. Upgrade to Pro for unlimited sessions.',
      empty_blocklist: 'Your blocklist is empty — add some categories or custom domains first.',
    };
    showFeedback(idleFeedback, msgs[result.error] || result.error, 'error');
    if (result.error === 'empty_blocklist') {
      openBlocklistManager();
    }
    return;
  }

  const data = await chrome.storage.local.get(['task', 'startTime', 'sessionStats', 'isPro']);
  showScreen('active');
  populateActiveScreen({ ...data, activeSession: true });
});

// ============================================================
// SCREEN: ACTIVE SESSION
// ============================================================
function populateActiveScreen(data) {
  clearTimers();

  activeTaskText.textContent = data.task || 'Focus session active';

  if (!data.isPro) freeBarWrap.classList.remove('hidden');

  timerInterval = setInterval(() => updateTimer(data.startTime, data.isPro), 1000);
  updateTimer(data.startTime, data.isPro);

  statsInterval = setInterval(refreshStats, 2000);
  refreshStats();
}

function updateTimer(startTime, isPro) {
  const ms  = Date.now() - (startTime || Date.now());
  const s   = Math.floor(ms / 1000);
  timerDisplay.textContent =
    `${String(Math.floor(s/60)).padStart(2,'0')}:${String(s%60).padStart(2,'0')}`;

  if (!isPro) {
    const pct   = Math.min(100, (ms / (FREE_SESSION_LIMIT_MIN * 60000)) * 100);
    freeBar.style.width        = pct + '%';
    freeBar.style.background   = pct >= 83 ? 'var(--danger)' : 'var(--accent)';
    freeBarLabel.textContent   = `${Math.floor(s/60)} / ${FREE_SESSION_LIMIT_MIN} min`;
  }
}

async function refreshStats() {
  const data = await chrome.storage.local.get(['sessionStats', 'activeSession']);

  if (!data.activeSession) {
    clearTimers();
    const { lastSessionSummary } = await chrome.storage.local.get('lastSessionSummary');
    if (lastSessionSummary) {
      showScreen('summary');
      populateSummaryScreen(lastSessionSummary);
    }
    return;
  }

  const s = data.sessionStats || {};
  statAllowed.textContent = s.allowed       || 0;
  statBlocked.textContent = s.blocked       || 0;
  statBreaks.textContent  = s.breakRequests || 0;
}

endBtn.addEventListener('click', async () => {
  endBtn.disabled    = true;
  endBtn.textContent = 'Ending…';
  const result = await chrome.runtime.sendMessage({ type: 'END_SESSION' });
  clearTimers();
  if (result.ok) {
    showScreen('summary');
    populateSummaryScreen(result.summary);
  }
});

// ============================================================
// SCREEN: SUMMARY
// ============================================================
function populateSummaryScreen(s) {
  summaryDuration.textContent = s.durationMin || 0;
  summaryAllowed.textContent  = s.allowed     || 0;
  summaryBlocked.textContent  = s.blocked     || 0;
  summaryTaskChip.textContent = s.task ? `🎯 ${s.task}` : 'Session complete';

  const mins = s.durationMin || 0;
  const blk  = s.blocked     || 0;
  let msg = `You focused for ${mins} minute${mins !== 1 ? 's' : ''}`;
  if (blk > 0) msg += ` and blocked ${blk} distraction${blk !== 1 ? 's' : ''}`;
  msg += '. ' + motivationLine(blk, mins);
  summaryMsg.textContent = msg;
}

function motivationLine(blocked, minutes) {
  if (minutes >= 25) return 'Outstanding deep work session! 🔥';
  if (blocked >= 5)  return 'You resisted every urge. That\'s real discipline. 💪';
  if (blocked >= 2)  return 'Every blocked site is a win. Keep building the habit! ✨';
  if (minutes >= 10) return 'Solid session — consistency beats perfection. 🌱';
  return 'Every minute of focus counts. Great start! 🚀';
}

newSessionBtn.addEventListener('click', async () => {
  await chrome.runtime.sendMessage({ type: 'CLEAR_SUMMARY' });
  const data = await chrome.storage.local.get([
    'sessionsToday', 'lastResetDate', 'isPro',
    'enabledCategories', 'customDomains', 'lastSessionSummary',
  ]);
  showScreen('idle');
  populateIdleScreen(data);
  taskInput.focus();
});

// ============================================================
// SCREEN: BLOCKLIST MANAGER
// ============================================================
async function openBlocklistManager() {
  const data = await chrome.storage.local.get(['enabledCategories', 'customDomains']);
  draftCategories = { ...(data.enabledCategories || {}) };
  draftCustom     = [...(data.customDomains     || [])];

  renderCategoryGrid();
  renderDomainTags();
  updateHeaderCount();
  clearFeedback(blFeedback);
  showScreen('blocklist');
}

function renderCategoryGrid() {
  catGrid.innerHTML = '';
  for (const cat of CATEGORIES) {
    const isOn = !!draftCategories[cat.id];
    const card = document.createElement('div');
    card.className = `cat-card${isOn ? ' active' : ''}`;
    card.innerHTML = `
      <div class="cat-left">
        <span class="cat-emoji">${cat.emoji}</span>
        <div>
          <div class="cat-name">${cat.name}</div>
          <div class="cat-count">${cat.count} sites</div>
        </div>
      </div>
      <label class="toggle">
        <input type="checkbox" ${isOn ? 'checked' : ''} data-cat="${cat.id}">
        <span class="toggle-slider"></span>
      </label>`;

    // Toggle on click anywhere on the card
    card.addEventListener('click', (e) => {
      // Let the checkbox handle its own click natively; we sync state after
      const chk = card.querySelector('input[type=checkbox]');
      if (e.target !== chk) chk.checked = !chk.checked;
      draftCategories[cat.id] = chk.checked;
      card.classList.toggle('active', chk.checked);
      updateHeaderCount();
    });

    catGrid.appendChild(card);
  }
}

function renderDomainTags() {
  domainTagsEl.innerHTML = '';
  if (draftCustom.length === 0) {
    noCustomMsg.classList.remove('hidden');
    return;
  }
  noCustomMsg.classList.add('hidden');
  for (const domain of draftCustom) {
    const tag = document.createElement('span');
    tag.className = 'domain-tag';
    tag.innerHTML = `${domain}<span class="remove-tag" data-domain="${domain}">×</span>`;
    tag.querySelector('.remove-tag').addEventListener('click', () => {
      draftCustom = draftCustom.filter(d => d !== domain);
      renderDomainTags();
      updateHeaderCount();
    });
    domainTagsEl.appendChild(tag);
  }
}

function updateHeaderCount() {
  let total = 0;
  for (const cat of CATEGORIES) {
    if (draftCategories[cat.id]) total += cat.count;
  }
  total += draftCustom.length;
  blHeaderCount.textContent = total;
}

addDomainBtn.addEventListener('click', addCustomDomain);
customDomainInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') addCustomDomain();
});

function addCustomDomain() {
  let raw = customDomainInput.value.trim().toLowerCase();
  if (!raw) return;

  // Strip protocol/path, keep just the domain
  raw = raw.replace(/^https?:\/\//i, '').replace(/^www\./i, '').split('/')[0];

  if (!raw.includes('.')) {
    showFeedback(blFeedback, 'Enter a valid domain (e.g. chess.com)', 'error');
    return;
  }
  if (draftCustom.includes(raw)) {
    showFeedback(blFeedback, `${raw} is already in your list.`, 'error');
    return;
  }

  draftCustom.push(raw);
  customDomainInput.value = '';
  renderDomainTags();
  updateHeaderCount();
  clearFeedback(blFeedback);
}

saveBlocklistBtn.addEventListener('click', async () => {
  saveBlocklistBtn.disabled    = true;
  saveBlocklistBtn.textContent = 'Saving…';

  await chrome.runtime.sendMessage({
    type:              'SAVE_BLOCKLIST',
    enabledCategories: draftCategories,
    customDomains:     draftCustom,
  });

  saveBlocklistBtn.disabled    = false;
  saveBlocklistBtn.textContent = 'Save Blocklist';
  showFeedback(blFeedback, '✓ Blocklist saved!', 'ok');

  // Refresh the idle screen's summary after a moment
  setTimeout(async () => {
    const data = await chrome.storage.local.get(['enabledCategories', 'customDomains']);
    refreshBlocklistSummary(data.enabledCategories || {}, data.customDomains || []);
  }, 400);
});

blBackBtn.addEventListener('click', () => showScreen(previousScreen));

// ============================================================
// SCREEN: SETTINGS
// ============================================================
async function openSettings() {
  const data = await chrome.storage.local.get(['isPro', 'sessionsToday', 'lastResetDate']);

  const today   = todayString();
  const used    = (data.lastResetDate === today ? data.sessionsToday : 0) || 0;

  if (data.isPro) {
    settingsTierBadge.textContent = '⭐ PRO';
    settingsTierBadge.className   = 'badge badge-pro';
    proStatusBadge.textContent    = '⭐ PRO';
    proStatusBadge.className      = 'badge badge-pro';
    proUnlockSection.classList.add('hidden');
    proActiveSection.classList.remove('hidden');
    usageCount.textContent = '∞';
  } else {
    usageCount.textContent = `${used} / 2`;
  }

  clearFeedback(settingsFeedback);
  showScreen('settings');
}

settingsBackBtn.addEventListener('click', () => showScreen(previousScreen));

activateBtn.addEventListener('click', async () => {
  const key = licenseInput.value.trim();
  if (!key) { showFeedback(settingsFeedback, 'Enter your license key.', 'error'); return; }

  activateBtn.disabled    = true;
  activateBtn.textContent = '…';

  const result = await chrome.runtime.sendMessage({ type: 'ACTIVATE_PRO', licenseKey: key });

  activateBtn.disabled    = false;
  activateBtn.textContent = 'Activate';

  if (result.ok) {
    settingsTierBadge.textContent = '⭐ PRO';
    settingsTierBadge.className   = 'badge badge-pro';
    proStatusBadge.textContent    = '⭐ PRO';
    proStatusBadge.className      = 'badge badge-pro';
    proUnlockSection.classList.add('hidden');
    proActiveSection.classList.remove('hidden');
    usageCount.textContent = '∞';
    showFeedback(settingsFeedback, '⭐ Pro activated! All limits removed.', 'ok');
  } else {
    showFeedback(settingsFeedback, '✗ Invalid key. Try: LOCKIN-LITE-PRO-2024', 'error');
  }
});

// ============================================================
// HELPERS
// ============================================================
function showFeedback(el, msg, type) {
  el.textContent = msg;
  el.className   = `feedback feedback-${type === 'ok' ? 'ok' : 'error'}`;
  el.classList.remove('hidden');
  if (type === 'ok') setTimeout(() => clearFeedback(el), 3000);
}

function clearFeedback(el) {
  el.textContent = '';
  el.classList.add('hidden');
}

function clearTimers() {
  clearInterval(timerInterval);
  clearInterval(statsInterval);
  timerInterval = statsInterval = null;
}

function todayString() { return new Date().toISOString().split('T')[0]; }
function isRecent(ts)  { return ts && (Date.now() - ts < 5 * 60 * 1000); }

// ============================================================
// START
// ============================================================
init();

'use strict';

// Minimal content script — same as the AI version.
// Listens for optional SHOW_CHECKING / HIDE_CHECKING messages
// from background.js (not used in current flow but wired up for future use).

let overlay = null;

chrome.runtime.onMessage.addListener((message) => {
  if (message.type === 'SHOW_CHECKING') showOverlay();
  if (message.type === 'HIDE_CHECKING') removeOverlay();
});

function showOverlay() {
  if (overlay) return;
  overlay = document.createElement('div');
  overlay.style.cssText = `
    position:fixed;inset:0;background:rgba(13,17,23,.85);
    backdrop-filter:blur(4px);z-index:2147483647;
    display:flex;align-items:center;justify-content:center;
    font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',system-ui,sans-serif;
    color:#e6edf3;font-size:15px;font-weight:600;gap:12px;
  `;
  overlay.innerHTML = `
    <div style="width:20px;height:20px;border:2px solid #30363d;border-top-color:#f59e0b;
         border-radius:50%;animation:ls 0.7s linear infinite;"></div>
    <style>@keyframes ls{to{transform:rotate(360deg)}}</style>
    Checking blocklist…
  `;
  document.documentElement.appendChild(overlay);
}

function removeOverlay() {
  if (overlay) { overlay.remove(); overlay = null; }
}

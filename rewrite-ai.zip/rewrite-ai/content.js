// ============================================================
//  content.js — The IN-LINE OVERLAY (runs on every webpage)
//  This is the whole product surface now. When you select text:
//    1. A small floating "Rephrase" pill appears next to it.
//    2. Clicking it opens a card anchored to the selection.
//    3. The card asks background.js to call Claude, shows the
//       result, and lets you Copy or Replace the text in place.
//  Everything lives inside a Shadow DOM so the host page's CSS
//  can never break our widget (and ours can't leak onto theirs).
// ============================================================

(function () {
  // Guard against double-injection (e.g. extension reloaded)
  if (window.__rewriteAIInjected) return;
  window.__rewriteAIInjected = true;

  // --- State we capture at selection time -------------------
  let selectedText = "";        // the text the user highlighted
  let editableTarget = null;    // the <input>/<textarea> if selection was inside one
  let editableRange = null;     // a Range for contenteditable replacement
  let selectionStart = 0;       // caret start (for input/textarea)
  let selectionEnd = 0;         // caret end   (for input/textarea)
  let lastStatus = null;        // cached {isPro, tones, ...}

  // ============================================================
  //  Build the Shadow DOM host (once)
  // ============================================================
  const host = document.createElement("div");
  host.id = "rewrite-ai-host";
  host.style.all = "initial";              // isolate from page
  host.style.position = "absolute";
  host.style.zIndex = "2147483647";        // sit above everything
  host.style.top = "0";
  host.style.left = "0";
  document.documentElement.appendChild(host);

  const shadow = host.attachShadow({ mode: "open" });
  shadow.innerHTML = `
    <style>${OVERLAY_CSS()}</style>

    <!-- The little floating button shown right after a selection -->
    <button class="ra-pill" id="ra-pill" type="button">
      <span class="ra-pill-icon">✍️</span> Rephrase
    </button>

    <!-- The expanded rewrite card -->
    <div class="ra-card" id="ra-card">
      <div class="ra-card-head">
        <div class="ra-logo"><span>✍️</span> ReWrite <b>AI</b></div>
        <span class="ra-pro-badge" id="ra-pro-badge">PRO</span>
        <button class="ra-close" id="ra-close" type="button">×</button>
      </div>

      <div class="ra-row">
        <select class="ra-tone" id="ra-tone"></select>
        <button class="ra-go" id="ra-go" type="button">Rephrase</button>
      </div>

      <div class="ra-output" id="ra-output"></div>

      <div class="ra-msg" id="ra-msg"></div>

      <div class="ra-actions" id="ra-actions">
        <button class="ra-btn-ghost" id="ra-copy" type="button">Copy</button>
        <button class="ra-btn-ghost" id="ra-replace" type="button">Replace</button>
        <span class="ra-usage" id="ra-usage"></span>
      </div>
    </div>
  `;

  // --- Grab shadow elements ---
  const pill      = shadow.getElementById("ra-pill");
  const card      = shadow.getElementById("ra-card");
  const toneSel   = shadow.getElementById("ra-tone");
  const goBtn     = shadow.getElementById("ra-go");
  const outputEl  = shadow.getElementById("ra-output");
  const msgEl     = shadow.getElementById("ra-msg");
  const actionsEl = shadow.getElementById("ra-actions");
  const copyBtn   = shadow.getElementById("ra-copy");
  const replaceBtn= shadow.getElementById("ra-replace");
  const usageEl   = shadow.getElementById("ra-usage");
  const closeBtn  = shadow.getElementById("ra-close");
  const proBadge  = shadow.getElementById("ra-pro-badge");

  // ============================================================
  //  Detect selection → show the pill
  // ============================================================
  document.addEventListener("mouseup", (e) => {
    // Ignore clicks inside our own UI
    if (e.target === host) return;

    // Let the browser finalise the selection first
    setTimeout(() => {
      const sel = window.getSelection();
      const text = sel ? sel.toString().trim() : "";

      if (!text) {
        hidePill();
        return;
      }

      captureSelection(sel);
      const rect = getSelectionRect(sel);
      if (rect) showPill(rect);
    }, 0);
  });

  // Hide everything when clicking elsewhere or pressing Escape.
  // Clicks inside our widget are retargeted to `host`, so we only
  // close when the click is genuinely outside it.
  document.addEventListener("mousedown", (e) => {
    if (e.target !== host) {
      hidePill();
      hideCard();
    }
  });
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") { hidePill(); hideCard(); }
  });

  // ============================================================
  //  Capture WHAT and WHERE the user selected.
  //  We store this now because clicking our UI can clear the
  //  page's live selection.
  // ============================================================
  function captureSelection(sel) {
    selectedText = sel.toString().trim();
    editableTarget = null;
    editableRange = null;

    const active = document.activeElement;
    const tag = active && active.tagName ? active.tagName.toLowerCase() : "";

    // Case 1: selection inside an <input> or <textarea>
    if ((tag === "input" || tag === "textarea") &&
        typeof active.selectionStart === "number") {
      editableTarget = active;
      selectionStart = active.selectionStart;
      selectionEnd = active.selectionEnd;
      return;
    }

    // Case 2: selection inside a contenteditable region
    if (sel.rangeCount > 0) {
      const range = sel.getRangeAt(0);
      let node = range.commonAncestorContainer;
      if (node.nodeType === Node.TEXT_NODE) node = node.parentElement;
      if (node && node.closest && node.closest('[contenteditable=""], [contenteditable="true"]')) {
        editableTarget = "contenteditable";
        editableRange = range.cloneRange();
      }
    }
  }

  // The bounding box of the selection, in page coordinates
  function getSelectionRect(sel) {
    if (!sel.rangeCount) return null;
    const r = sel.getRangeAt(0).getBoundingClientRect();
    if (r.width === 0 && r.height === 0) return null;
    return {
      top: r.top + window.scrollY,
      bottom: r.bottom + window.scrollY,
      left: r.left + window.scrollX,
      width: r.width
    };
  }

  // ============================================================
  //  Pill show/hide & positioning
  // ============================================================
  function showPill(rect) {
    pill.dataset.top = rect.bottom + 6;            // below the selection
    pill.dataset.left = rect.left + rect.width / 2; // centred
    pill.style.top = (rect.bottom + 6) + "px";
    pill.style.left = (rect.left + rect.width / 2) + "px";
    pill.classList.add("visible");
    card.classList.remove("open");
  }
  function hidePill() { pill.classList.remove("visible"); }

  // Prevent the pill click from clearing the selection / focus
  pill.addEventListener("mousedown", (e) => e.preventDefault());
  pill.addEventListener("click", () => openCard());

  // ============================================================
  //  Card: open / close
  // ============================================================
  async function openCard(prefillText) {
    if (prefillText) selectedText = prefillText;
    if (!selectedText) return;

    hidePill();

    // Position the card where the pill was
    const top = parseFloat(pill.dataset.top || "80");
    const left = parseFloat(pill.dataset.left || "80");
    placeCard(top, left);

    // Reset card UI
    outputEl.textContent = "";
    outputEl.classList.remove("filled");
    msgEl.className = "ra-msg";
    msgEl.textContent = "";
    actionsEl.style.display = "none";
    card.classList.add("open");

    // Load status (Pro?, tones, usage) from background
    lastStatus = await sendMessage({ type: "GET_STATUS" });
    renderStatus(lastStatus);
  }

  function placeCard(top, left) {
    const CARD_W = 320;
    // Keep the card inside the viewport horizontally
    let x = left - CARD_W / 2;
    const maxX = window.scrollX + document.documentElement.clientWidth - CARD_W - 12;
    const minX = window.scrollX + 12;
    x = Math.max(minX, Math.min(x, maxX));
    card.style.top = top + "px";
    card.style.left = x + "px";
  }

  function hideCard() { card.classList.remove("open"); }
  closeBtn.addEventListener("click", hideCard);

  // Don't let interactions inside the card clear the page selection
  card.addEventListener("mousedown", (e) => {
    // allow text fields / selects to work, but stop selection loss elsewhere
    const t = e.target;
    if (t === toneSel || t.tagName === "OPTION") return;
    if (t === outputEl) return;
    e.preventDefault();
  });

  // ============================================================
  //  Render Pro/Free status into the card
  // ============================================================
  function renderStatus(status) {
    if (!status) return;

    // Tone dropdown — only the tones this tier is allowed
    toneSel.innerHTML = "";
    const allTones = ["Standard", "Formal", "Casual", "Persuasive", "Creative"];
    allTones.forEach((tone) => {
      const allowed = status.tones.includes(tone);
      const opt = document.createElement("option");
      opt.value = tone;
      opt.textContent = allowed ? tone : (tone + " 🔒");
      opt.disabled = !allowed;
      toneSel.appendChild(opt);
    });
    toneSel.value = "Standard";

    // Pro badge
    proBadge.classList.toggle("visible", !!status.isPro);

    // Usage line
    if (status.isPro) {
      usageEl.textContent = "Unlimited ⭐";
    } else {
      usageEl.textContent = status.usageCount + " / " + status.limit + " used today";
    }

    // Replace button only makes sense if the selection was editable
    replaceBtn.style.display = editableTarget ? "" : "none";
  }

  // ============================================================
  //  Rephrase button → ask background to call Claude
  // ============================================================
  goBtn.addEventListener("click", async () => {
    if (!selectedText) return;

    setLoading(true);
    msgEl.className = "ra-msg";
    msgEl.textContent = "";
    actionsEl.style.display = "none";
    outputEl.textContent = "";
    outputEl.classList.remove("filled");

    const result = await sendMessage({
      type: "REPHRASE",
      text: selectedText,
      tone: toneSel.value
    });

    setLoading(false);

    if (result.ok) {
      outputEl.textContent = result.text;
      outputEl.classList.add("filled");
      actionsEl.style.display = "flex";
      usageEl.textContent = result.isPro
        ? "Unlimited ⭐"
        : result.usageCount + " / " + result.limit + " used today";
    } else if (result.reason === "limit") {
      showUpgrade(result.message);
    } else {
      msgEl.className = "ra-msg error";
      msgEl.textContent = result.message || "Something went wrong.";
    }
  });

  // ============================================================
  //  Copy & Replace actions
  // ============================================================
  copyBtn.addEventListener("click", () => {
    const text = outputEl.textContent;
    if (!text) return;
    navigator.clipboard.writeText(text).then(() => {
      copyBtn.textContent = "Copied ✓";
      setTimeout(() => (copyBtn.textContent = "Copy"), 1500);
    });
  });

  replaceBtn.addEventListener("click", () => {
    const newText = outputEl.textContent;
    if (!newText) return;

    // Replace inside <input>/<textarea>
    if (editableTarget && editableTarget !== "contenteditable") {
      const el = editableTarget;
      const v = el.value;
      el.value = v.slice(0, selectionStart) + newText + v.slice(selectionEnd);
      // Move caret to end of inserted text and notify frameworks (React etc.)
      const caret = selectionStart + newText.length;
      el.setSelectionRange(caret, caret);
      el.dispatchEvent(new Event("input", { bubbles: true }));
      el.focus();
    }
    // Replace inside contenteditable
    else if (editableTarget === "contenteditable" && editableRange) {
      editableRange.deleteContents();
      editableRange.insertNode(document.createTextNode(newText));
    }

    replaceBtn.textContent = "Replaced ✓";
    setTimeout(() => { replaceBtn.textContent = "Replace"; hideCard(); }, 800);
  });

  // ============================================================
  //  Upgrade prompt (free user hit the daily limit)
  //  Shows an "Upgrade to Pro" button that expands, in place,
  //  into a license-key form — no popup, no toolbar trip.
  // ============================================================
  function showUpgrade(message) {
    actionsEl.style.display = "none";
    msgEl.className = "ra-msg upgrade";
    msgEl.innerHTML =
      '<div class="ra-upgrade-text">' + (message || "Daily limit reached.") + "</div>" +
      '<button class="ra-upgrade-btn" id="ra-upgrade">Upgrade to Pro</button>' +
      '<div class="ra-activate" id="ra-activate">' +
        '<input class="ra-key" id="ra-key" type="text" placeholder="REWRITE-PRO-XXXX" autocomplete="off" spellcheck="false" />' +
        '<button class="ra-activate-btn" id="ra-activate-btn">Activate</button>' +
        '<div class="ra-activate-result" id="ra-activate-result"></div>' +
      "</div>";

    const upBtn      = shadow.getElementById("ra-upgrade");
    const activate   = shadow.getElementById("ra-activate");
    const keyInput   = shadow.getElementById("ra-key");
    const actBtn     = shadow.getElementById("ra-activate-btn");
    const actResult  = shadow.getElementById("ra-activate-result");

    // "Upgrade to Pro" reveals the key field
    upBtn.addEventListener("click", () => {
      upBtn.style.display = "none";
      activate.classList.add("open");
      keyInput.focus();
    });

    // Let users type/select inside the key field without losing focus
    keyInput.addEventListener("mousedown", (e) => e.stopPropagation());

    // Submit the key to the background worker for validation
    const submit = async () => {
      const result = await sendMessage({ type: "ACTIVATE_PRO", key: keyInput.value });
      if (result.ok) {
        actResult.className = "ra-activate-result success";
        actResult.textContent = "🎉 " + result.message;
        // Refresh status so tones unlock and the Pro badge shows
        lastStatus = await sendMessage({ type: "GET_STATUS" });
        renderStatus(lastStatus);
        // Clear the upgrade message after a moment
        setTimeout(() => { msgEl.className = "ra-msg"; msgEl.textContent = ""; }, 1800);
      } else {
        actResult.className = "ra-activate-result error";
        actResult.textContent = result.message;
      }
    };

    actBtn.addEventListener("click", submit);
    keyInput.addEventListener("keydown", (e) => {
      if (e.key === "Enter") submit();
    });
  }

  // ============================================================
  //  Loading state on the Rephrase button
  // ============================================================
  function setLoading(on) {
    goBtn.classList.toggle("loading", on);
    goBtn.disabled = on;
    goBtn.textContent = on ? "" : "Rephrase";
  }

  // ============================================================
  //  Messaging helper (promise-wrapped sendMessage)
  // ============================================================
  function sendMessage(msg) {
    return new Promise((resolve) => {
      // If the extension was reloaded, this script is "orphaned" and
      // chrome.runtime is gone. Bail gracefully instead of throwing
      // "Extension context invalidated".
      if (!chrome.runtime?.id) {
        resolve({ ok: false, reason: "context", message: "Please reload this page (extension was updated)." });
        return;
      }
      try {
        chrome.runtime.sendMessage(msg, (resp) => {
          if (chrome.runtime.lastError) {
            resolve({ ok: false, reason: "api", message: chrome.runtime.lastError.message });
          } else {
            resolve(resp);
          }
        });
      } catch (e) {
        resolve({ ok: false, reason: "context", message: "Please reload this page (extension was updated)." });
      }
    });
  }

  // ============================================================
  //  Open the card from the right-click context menu
  // ============================================================
  chrome.runtime.onMessage.addListener((message) => {
    if (message.type === "SHOW_INLINE") {
      // Use the live selection if present, else the text from the menu
      const sel = window.getSelection();
      if (sel && sel.toString().trim()) {
        captureSelection(sel);
        const rect = getSelectionRect(sel);
        if (rect) { pill.dataset.top = rect.bottom + 6; pill.dataset.left = rect.left + rect.width / 2; }
      } else {
        selectedText = message.text || "";
        editableTarget = null;
        // Default position near top of viewport
        pill.dataset.top = window.scrollY + 80;
        pill.dataset.left = window.scrollX + 200;
      }
      openCard(selectedText || message.text);
    }
  });

  // ============================================================
  //  The Shadow DOM stylesheet (kept here so it's self-contained)
  // ============================================================
  function OVERLAY_CSS() {
    return `
      :host, * { box-sizing: border-box; }
      .ra-pill, .ra-card {
        position: absolute;
        font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
      }

      /* --- Pill --- */
      .ra-pill {
        display: none;
        transform: translateX(-50%);
        align-items: center;
        gap: 5px;
        background: linear-gradient(135deg, #6c3ce1, #9b5de5);
        color: #fff;
        border: none;
        border-radius: 20px;
        padding: 7px 13px;
        font-size: 13px;
        font-weight: 600;
        cursor: pointer;
        box-shadow: 0 4px 14px rgba(108,60,225,.4);
        white-space: nowrap;
      }
      .ra-pill.visible { display: inline-flex; }
      .ra-pill:hover { opacity: .93; }
      .ra-pill-icon { font-size: 14px; }

      /* --- Card --- */
      .ra-card {
        display: none;
        width: 320px;
        background: #fff;
        border-radius: 14px;
        box-shadow: 0 12px 40px rgba(40,20,80,.28);
        border: 1px solid #ede8ff;
        overflow: hidden;
      }
      .ra-card.open { display: block; }

      .ra-card-head {
        display: flex;
        align-items: center;
        gap: 8px;
        padding: 10px 12px;
        background: linear-gradient(135deg, #6c3ce1, #9b5de5);
        color: #fff;
      }
      .ra-logo { font-size: 14px; font-weight: 700; }
      .ra-logo span { font-size: 15px; }
      .ra-logo b { color: #f0d9ff; font-weight: 800; }
      .ra-pro-badge {
        display: none;
        background: linear-gradient(135deg,#ffd700,#ffb300);
        color:#3a2a00; font-size:10px; font-weight:800;
        padding:2px 7px; border-radius:10px; letter-spacing:.5px;
      }
      .ra-pro-badge.visible { display: inline-block; }
      .ra-close {
        margin-left: auto; background: none; border: none; color: #fff;
        font-size: 20px; line-height: 1; cursor: pointer; opacity: .85;
      }
      .ra-close:hover { opacity: 1; }

      .ra-row { display: flex; gap: 8px; padding: 12px 12px 0; }
      .ra-tone {
        flex: 1; padding: 8px 10px; border: 1.5px solid #e0d7ff;
        border-radius: 9px; font-size: 13px; color: #1a1a2e; background: #fff;
        font-family: inherit; cursor: pointer;
      }
      .ra-tone:focus { outline: none; border-color: #6c3ce1; }
      .ra-go {
        padding: 8px 16px; background: linear-gradient(135deg,#6c3ce1,#9b5de5);
        color: #fff; border: none; border-radius: 9px; font-size: 13px;
        font-weight: 600; cursor: pointer; min-width: 92px; position: relative;
      }
      .ra-go:hover:not(:disabled) { opacity: .93; }
      .ra-go:disabled { opacity: .8; cursor: default; }
      .ra-go.loading::after {
        content: ""; position: absolute; width: 15px; height: 15px;
        top: 50%; left: 50%; margin: -7.5px 0 0 -7.5px;
        border: 2.5px solid rgba(255,255,255,.4); border-top-color: #fff;
        border-radius: 50%; animation: ra-spin .7s linear infinite;
      }
      @keyframes ra-spin { to { transform: rotate(360deg); } }

      .ra-output {
        margin: 12px; padding: 10px 12px; min-height: 64px;
        background: #faf9ff; border: 1px solid #ede8ff; border-radius: 10px;
        font-size: 13px; line-height: 1.5; color: #2a2440; white-space: pre-wrap;
      }
      .ra-output.filled { background: #fff; }

      .ra-msg { margin: 0 12px; font-size: 12.5px; }
      .ra-msg.error {
        color: #c62828; background: #fff0f0; border: 1px solid #ffcdd2;
        border-radius: 8px; padding: 8px 10px;
      }
      .ra-msg.upgrade {
        color: #5b21b6; background: linear-gradient(135deg,#fff0fa,#ede8ff);
        border: 1px solid #d8b4fe; border-radius: 10px; padding: 10px 12px;
        text-align: center;
      }
      .ra-upgrade-btn {
        margin-top: 8px; background: linear-gradient(135deg,#6c3ce1,#9b5de5);
        color: #fff; border: none; border-radius: 8px; padding: 7px 16px;
        font-size: 12px; font-weight: 600; cursor: pointer;
      }
      .ra-upgrade-btn:hover { opacity: .92; }

      /* --- Inline license-key activation (hidden until clicked) --- */
      .ra-activate { display: none; margin-top: 10px; }
      .ra-activate.open { display: block; }
      .ra-key {
        width: 100%; padding: 8px 10px; border: 1.5px solid #d8b4fe;
        border-radius: 8px; font-size: 13px; letter-spacing: 1px;
        font-family: inherit; text-align: center; margin-bottom: 7px;
      }
      .ra-key:focus { outline: none; border-color: #6c3ce1; }
      .ra-activate-btn {
        width: 100%; background: linear-gradient(135deg,#6c3ce1,#9b5de5);
        color: #fff; border: none; border-radius: 8px; padding: 8px;
        font-size: 13px; font-weight: 600; cursor: pointer;
      }
      .ra-activate-btn:hover { opacity: .92; }
      .ra-activate-result { font-size: 12px; margin-top: 7px; }
      .ra-activate-result.success { color: #2e7d32; }
      .ra-activate-result.error { color: #c62828; }

      .ra-actions {
        display: none; align-items: center; gap: 8px;
        padding: 0 12px 12px;
      }
      .ra-btn-ghost {
        border: 1.5px solid #6c3ce1; color: #6c3ce1; background: none;
        border-radius: 7px; padding: 5px 12px; font-size: 12px;
        font-weight: 600; cursor: pointer;
      }
      .ra-btn-ghost:hover { background: #6c3ce1; color: #fff; }
      .ra-usage { margin-left: auto; font-size: 11.5px; color: #8a7cb0; }
    `;
  }
})();

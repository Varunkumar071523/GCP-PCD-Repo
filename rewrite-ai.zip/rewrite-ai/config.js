// ============================================================
//  config.js — API Configuration
//  IMPORTANT: Replace the placeholder below with your real
//  Anthropic API key from https://console.anthropic.com
// ============================================================

const CONFIG = {
  // Your Anthropic API key — keep this secret!
  ANTHROPIC_API_KEY: "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",

  // The Claude model to use for rephrasing
  MODEL: "claude-sonnet-4-20250514",

  // The valid Pro license key (hardcoded for testing)
  VALID_LICENSE_KEY: "REWRITE-PRO-2024",

  // Max free rephrases per day
  FREE_DAILY_LIMIT: 5
};

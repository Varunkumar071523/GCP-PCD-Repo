// ============================================================
//  popup.js — Main popup logic
//  Handles: freemium checks, Claude API calls, usage tracking,
//           Pro activation, copy button, tone locking
// ============================================================

// --- Grab all DOM elements we need ---
const inputText        = document.getElementById("input-text");
const outputText       = document.getElementById("output-text");
const toneSelect       = document.getElementById("tone-select");
const toneHint         = document.getElementById("tone-hint");
const btnRephrase      = document.getElementById("btn-rephrase");
const btnCopy          = document.getElementById("btn-copy");
const btnUpgrade       = document.getElementById("btn-upgrade");
const btnActivate      = document.getElementById("btn-activate");
const btnCancel        = document.getElementById("btn-cancel");
const proScreen        = document.getElementById("pro-screen");
const proBadge         = document.getElementById("pro-badge");
const usageCounter     = document.getElementById("usage-counter");
const usageText        = document.getElementById("usage-text");
const usageBar         = document.getElementById("usage-bar");
const upgradeBanner    = document.getElementById("upgrade-banner");
const errorMessage     = document.getElementById("error-message");
const licenseKeyInput  = document.getElementById("license-key-input");
const activationResult = document.getElementById("activation-result");

// ============================================================
//  STEP 1: Load state from chrome.storage and initialise UI
// ============================================================
document.addEventListener("DOMContentLoaded", async () => {
  // Load persisted data (usage count, date, pro status)
  const data = await getStorageData();

  // Check if the date has changed — if so, reset the counter
  const today = getTodayDateString();
  if (data.lastResetDate !== today) {
    await chrome.storage.local.set({ usageCount: 0, lastResetDate: today });
    data.usageCount = 0;
  }

  // Apply UI based on Pro status
  applyProUI(data.isPro, data.usageCount);

  // Auto-fill input if there is pending text (from context menu or content.js)
  const pending = await chrome.storage.local.get("pendingText");
  if (pending.pendingText) {
    inputText.value = pending.pendingText;
    // Clear it so it doesn't persist on next open
    chrome.storage.local.remove("pendingText");
  } else {
    // Try to get currently selected text from the active tab
    tryGetSelectedText();
  }
});

// ============================================================
//  STEP 2: Apply UI state depending on Free vs Pro
// ============================================================
function applyProUI(isPro, usageCount) {
  if (isPro) {
    // --- PRO USER ---
    proBadge.classList.add("visible");
    toneSelect.disabled = false;              // Unlock all tones
    toneHint.style.display = "none";          // Hide lock hint
    usageCounter.style.display = "none";      // Hide usage bar
    upgradeBanner.style.display = "none";     // Hide upgrade banner

    // Remove lock icons from tone options
    for (const opt of toneSelect.options) {
      opt.text = opt.text.replace(" 🔒", "");
    }

    // Make sure rephrase button is enabled
    btnRephrase.disabled = false;

  } else {
    // --- FREE USER ---
    const limit = CONFIG.FREE_DAILY_LIMIT;
    const remaining = limit - usageCount;

    // Update usage counter display
    usageText.textContent = `${usageCount} / ${limit} rephrases used today`;
    usageBar.style.width = `${(usageCount / limit) * 100}%`;

    // Disable button if limit reached
    if (usageCount >= limit) {
      btnRephrase.disabled = true;
      btnRephrase.textContent = "Daily limit reached";
      showError("You've used all 5 free rephrases today. Upgrade to Pro for unlimited access!");
    } else {
      btnRephrase.disabled = false;
      btnRephrase.textContent = "✨ Rephrase Now";
    }
  }
}

// ============================================================
//  STEP 3: Rephrase button — call Claude API
// ============================================================
btnRephrase.addEventListener("click", async () => {
  const text = inputText.value.trim();
  if (!text) {
    showError("Please enter or select some text to rephrase.");
    return;
  }

  // Load latest state
  const data = await getStorageData();
  const today = getTodayDateString();

  // Safety check: re-verify limit (in case storage changed)
  if (!data.isPro && data.usageCount >= CONFIG.FREE_DAILY_LIMIT) {
    showError("Daily limit reached. Upgrade to Pro for unlimited rephrases!");
    return;
  }

  // Get selected tone
  const tone = toneSelect.value;

  // Show loading state
  setLoading(true);
  hideError();
  outputText.value = "";

  try {
    // Call the Claude API
    const rephrased = await callClaudeAPI(text, tone);

    // Display the result
    outputText.value = rephrased;

    // Increment usage count for free users
    if (!data.isPro) {
      const newCount = (data.usageCount || 0) + 1;
      await chrome.storage.local.set({
        usageCount: newCount,
        lastResetDate: today
      });
      // Refresh usage UI
      applyProUI(false, newCount);
    }

  } catch (err) {
    showError("Error: " + err.message);
  } finally {
    setLoading(false);
  }
});

// ============================================================
//  STEP 4: Call the Anthropic Claude API
// ============================================================
async function callClaudeAPI(userText, tone) {
  const prompt = `Rephrase the following text in a ${tone} tone. Return only the rephrased text, nothing else: ${userText}`;

  const response = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": CONFIG.ANTHROPIC_API_KEY,
      "anthropic-version": "2023-06-01",
      // Required for browser-side requests
      "anthropic-dangerous-direct-browser-access": "true"
    },
    body: JSON.stringify({
      model: CONFIG.MODEL,
      max_tokens: 1024,
      messages: [
        {
          role: "user",
          content: prompt
        }
      ]
    })
  });

  if (!response.ok) {
    const errData = await response.json().catch(() => ({}));
    const msg = errData?.error?.message || `API error (${response.status})`;
    throw new Error(msg);
  }

  const result = await response.json();
  // Extract the text from the response
  return result.content[0].text.trim();
}

// ============================================================
//  STEP 5: Copy button
// ============================================================
btnCopy.addEventListener("click", () => {
  const text = outputText.value;
  if (!text) return;

  navigator.clipboard.writeText(text).then(() => {
    btnCopy.textContent = "Copied ✓";
    btnCopy.classList.add("copied");
    setTimeout(() => {
      btnCopy.textContent = "Copy";
      btnCopy.classList.remove("copied");
    }, 2000);
  });
});

// ============================================================
//  STEP 6: Upgrade button — show Pro activation screen
// ============================================================
btnUpgrade.addEventListener("click", () => {
  activationResult.className = "activation-result"; // reset
  activationResult.textContent = "";
  licenseKeyInput.value = "";
  proScreen.classList.add("visible");
});

// --- Cancel button — close Pro screen ---
btnCancel.addEventListener("click", () => {
  proScreen.classList.remove("visible");
});

// --- Activate button — validate license key ---
btnActivate.addEventListener("click", async () => {
  const key = licenseKeyInput.value.trim().toUpperCase();

  if (!key) {
    showActivationResult("error", "Please enter a license key.");
    return;
  }

  if (key === CONFIG.VALID_LICENSE_KEY) {
    // Valid key — save Pro status
    await chrome.storage.local.set({ isPro: true });
    showActivationResult("success", "🎉 Pro Activated! Enjoy unlimited rephrases.");

    // After a short delay, close the screen and update UI
    setTimeout(async () => {
      proScreen.classList.remove("visible");
      const data = await getStorageData();
      applyProUI(true, data.usageCount);
    }, 2000);

  } else {
    showActivationResult("error", "Invalid license key. Please check and try again.");
  }
});

// ============================================================
//  HELPER FUNCTIONS
// ============================================================

// Read all stored data, with safe defaults
function getStorageData() {
  return new Promise((resolve) => {
    chrome.storage.local.get(
      { usageCount: 0, lastResetDate: "", isPro: false },
      (result) => resolve(result)
    );
  });
}

// Get today's date as "YYYY-MM-DD"
function getTodayDateString() {
  return new Date().toISOString().split("T")[0];
}

// Try to pull selected text from the active tab via content.js
function tryGetSelectedText() {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (!tabs[0]) return;
    chrome.tabs.sendMessage(
      tabs[0].id,
      { type: "GET_SELECTED_TEXT" },
      (response) => {
        if (chrome.runtime.lastError) return; // tab might not have content script
        if (response && response.text && !inputText.value) {
          inputText.value = response.text;
        }
      }
    );
  });
}

// Show/hide the loading state on the rephrase button
function setLoading(isLoading) {
  if (isLoading) {
    btnRephrase.classList.add("loading");
    btnRephrase.disabled = true;
  } else {
    btnRephrase.classList.remove("loading");
    btnRephrase.disabled = false;
  }
}

// Show an error message below the button
function showError(msg) {
  errorMessage.textContent = msg;
  errorMessage.classList.add("visible");
}

function hideError() {
  errorMessage.classList.remove("visible");
}

// Show result inside the Pro activation card
function showActivationResult(type, msg) {
  activationResult.className = `activation-result ${type}`;
  activationResult.textContent = msg;
}

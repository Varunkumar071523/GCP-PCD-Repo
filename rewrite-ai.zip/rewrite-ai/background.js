// ============================================================
//  background.js — Service Worker (the "brain")
//  Central place for everything that must NOT live on the page:
//   1. The Claude API call (page origin would be blocked by CORS)
//   2. Usage tracking / daily-limit logic (single source of truth)
//   3. The right-click context menu
//  The on-page overlay (content.js) talks to this file via messages.
// ============================================================

// Pull in CONFIG (API key, model, limit, license key).
// importScripts works in MV3 service workers and runs config.js
// in this worker's scope, so CONFIG becomes available below.
importScripts("config.js");

// ------------------------------------------------------------
//  Context menu: "Rephrase with ReWrite AI"
// ------------------------------------------------------------
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "rewrite-ai-rephrase",
    title: "Rephrase with ReWrite AI",
    contexts: ["selection"]
  });
});

// When the menu item is clicked, tell the page's overlay to open
// with the selected text already loaded.
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "rewrite-ai-rephrase" && tab?.id) {
    chrome.tabs.sendMessage(tab.id, {
      type: "SHOW_INLINE",
      text: info.selectionText || ""
    });
  }
});

// ------------------------------------------------------------
//  Message router — handles requests from content.js & popup.js
// ------------------------------------------------------------
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  // --- Overlay/popup asks for current status (Pro? usage? tones?) ---
  if (message.type === "GET_STATUS") {
    getStatus().then(sendResponse);
    return true; // keep the message channel open for the async reply
  }

  // --- Overlay/popup requests a rephrase ---
  if (message.type === "REPHRASE") {
    handleRephrase(message.text, message.tone).then(sendResponse);
    return true;
  }

  // --- Overlay/popup submits a license key to unlock Pro ---
  if (message.type === "ACTIVATE_PRO") {
    activatePro(message.key).then(sendResponse);
    return true;
  }
});

// ============================================================
//  Validate a license key and flip the account to Pro.
// ============================================================
async function activatePro(key) {
  const clean = (key || "").trim().toUpperCase();
  if (!clean) {
    return { ok: false, message: "Please enter a license key." };
  }
  if (clean === CONFIG.VALID_LICENSE_KEY) {
    await chrome.storage.local.set({ isPro: true });
    return { ok: true, message: "Pro activated! Enjoy unlimited rewrites." };
  }
  return { ok: false, message: "Invalid license key. Please try again." };
}

// ============================================================
//  Status: read storage, reset the daily counter if the day
//  changed, and report back what the UI needs to render.
// ============================================================
async function getStatus() {
  const data = await chrome.storage.local.get({
    usageCount: 0,
    lastResetDate: "",
    isPro: false
  });

  // Reset the counter when a new day begins
  const today = todayString();
  if (data.lastResetDate !== today) {
    data.usageCount = 0;
    data.lastResetDate = today;
    await chrome.storage.local.set({ usageCount: 0, lastResetDate: today });
  }

  const limit = CONFIG.FREE_DAILY_LIMIT;
  return {
    isPro: data.isPro,
    usageCount: data.usageCount,
    limit,
    remaining: data.isPro ? Infinity : Math.max(0, limit - data.usageCount),
    // Free users only get "Standard"; Pro users get all five.
    tones: data.isPro
      ? ["Standard", "Formal", "Casual", "Persuasive", "Creative"]
      : ["Standard"]
  };
}

// ============================================================
//  Rephrase: enforce the limit, call Claude, bump the counter.
//  Returns a small result object the UI can act on.
// ============================================================
async function handleRephrase(text, tone) {
  if (!text || !text.trim()) {
    return { ok: false, reason: "empty", message: "No text to rephrase." };
  }

  const status = await getStatus();

  // Free users who've hit the limit get a clear "upgrade" signal.
  if (!status.isPro && status.remaining <= 0) {
    return {
      ok: false,
      reason: "limit",
      message: "You've used all " + status.limit +
               " free rephrases today. Upgrade to Pro for unlimited rewrites."
    };
  }

  // Free users are locked to the Standard tone, no matter what was sent.
  const safeTone = status.isPro ? tone : "Standard";

  try {
    const rephrased = await callClaudeAPI(text, safeTone);

    // Count this rephrase for free users.
    let newCount = status.usageCount;
    if (!status.isPro) {
      newCount = status.usageCount + 1;
      await chrome.storage.local.set({
        usageCount: newCount,
        lastResetDate: todayString()
      });
    }

    return {
      ok: true,
      text: rephrased,
      isPro: status.isPro,
      usageCount: newCount,
      limit: status.limit,
      remaining: status.isPro ? Infinity : Math.max(0, status.limit - newCount)
    };
  } catch (err) {
    return { ok: false, reason: "api", message: err.message };
  }
}

// ============================================================
//  The actual Anthropic Claude API call.
//  Runs in the service worker, so the request isn't tied to the
//  website's origin — host_permissions in manifest grants access.
// ============================================================
async function callClaudeAPI(userText, tone) {
  if (!CONFIG.ANTHROPIC_API_KEY || CONFIG.ANTHROPIC_API_KEY.includes("YOUR-API-KEY")) {
    throw new Error("No API key set. Add your key in config.js.");
  }

  const prompt =
    "Rephrase the following text in a " + tone +
    " tone. Return only the rephrased text, nothing else: " + userText;

  const response = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": CONFIG.ANTHROPIC_API_KEY,
      "anthropic-version": "2023-06-01",
      "anthropic-dangerous-direct-browser-access": "true"
    },
    body: JSON.stringify({
      model: CONFIG.MODEL,
      max_tokens: 1024,
      messages: [{ role: "user", content: prompt }]
    })
  });

  if (!response.ok) {
    const errData = await response.json().catch(() => ({}));
    throw new Error(errData?.error?.message || ("API error (" + response.status + ")"));
  }

  const result = await response.json();
  return result.content[0].text.trim();
}

// Helper: today's date as "YYYY-MM-DD"
function todayString() {
  return new Date().toISOString().split("T")[0];
}

<?php
/**
 * Plugin Name: AS400 Decoded - Post 15 Building REST APIs on IBM i
 * Description: Publishes Post 15 with SEO metadata, tags, custom slug, no Gutenberg
 * Version: 1.0
 */

if (!defined('ABSPATH')) exit;

add_action('init', 'as400_ensure_post15_exists');
function as400_ensure_post15_exists() {

    // Check already published
    $existing = get_posts(array(
        'post_type'      => 'post',
        'post_status'    => array('publish', 'draft', 'pending'),
        'posts_per_page' => 1,
        'meta_key'       => '_as400_post15',
        'meta_value'     => '1',
    ));
    if (!empty($existing)) return;

    $by_slug = get_page_by_path('ibm-i-rest-api-node-js-pase-modern-front-end', OBJECT, 'post');
    if ($by_slug) {
        add_post_meta($by_slug->ID, '_as400_post15', '1', true);
        return;
    }

    // ── Category ──────────────────────────────────
    $cat = get_category_by_slug('modern-integrations');
    if (!$cat) $cat = get_category_by_slug('operations-admin');
    $cat_id = $cat ? $cat->term_id : 1;

    // ── Tags ──────────────────────────────────────
    $tag_names = array(
        'IBM i',
        'AS400',
        'iSeries',
        'REST API',
        'Node.js IBM i',
        'PASE',
        'Express',
        'idb-connector',
        'IBM i web services',
        'RPG CGI',
        'ILE Web',
        'API Gateway',
        'MuleSoft',
        'JWT authentication',
        'IBM i modernisation',
        'hybrid architecture',
        'DB2 for i',
        'IAS REST',
        'PHP IBM i',
        'IBM i 2026'
    );
    $tag_ids = array();
    foreach ($tag_names as $tag) {
        $term = term_exists($tag, 'post_tag');
        if (!$term) {
            $term = wp_insert_term($tag, 'post_tag');
        }
        if (!is_wp_error($term)) {
            $tag_ids[] = is_array($term) ? (int) $term['term_id'] : (int) $term;
        }
    }

    // ── Content ───────────────────────────────────
    $content = file_get_contents(dirname(__FILE__) . '/post15-content.html');

    // ── Insert post ───────────────────────────────
    $post_id = wp_insert_post(array(
        'post_title'   => 'Building REST APIs on IBM i: Node.js in PASE, IAS REST, and connecting modern front ends to your RPG business logic',
        'post_name'    => 'ibm-i-rest-api-node-js-pase-modern-front-end',
        'post_content' => $content,
        'post_excerpt' => 'REST APIs are the bridge between IBM i and modern front ends. This post covers every practical option — IAS REST, Node.js in PASE, PHP, RPG CGI, and API gateways — with enough detail to choose the right approach for your environment.',
        'post_status'  => 'publish',
        'post_type'    => 'post',
        'post_category'=> array($cat_id),
        'tags_input'   => $tag_ids,
        'post_author'  => 1,
        'post_date'    => current_time('mysql'),
        'meta_input'   => array(

            // ── Internal marker ───────────────────
            '_as400_post15' => '1',

            // ── Yoast SEO ─────────────────────────
            '_yoast_wpseo_title'         => 'Building REST APIs on IBM i: Node.js in PASE and Modern Front-End Integration',
            '_yoast_wpseo_metadesc'      => 'How to expose IBM i data and RPG business logic as REST APIs. Covers IAS REST, Node.js in PASE with Express, PHP, RPG CGI, API gateways, and authentication patterns.',
            '_yoast_wpseo_focuskw'       => 'IBM i REST API Node.js PASE',
            '_yoast_wpseo_canonical'     => 'https://as400decoded.com/ibm-i-rest-api-node-js-pase-modern-front-end/',
            '_yoast_wpseo_opengraph-title'       => 'Building REST APIs on IBM i: Connecting Modern Front Ends to RPG',
            '_yoast_wpseo_opengraph-description' => 'IAS REST, Node.js in PASE, PHP, RPG CGI, and API gateways — a practical guide to every option for exposing IBM i as REST APIs.',
            '_yoast_wpseo_twitter-title'         => 'Building REST APIs on IBM i — every option explained',
            '_yoast_wpseo_twitter-description'   => 'IAS REST vs Node.js in PASE vs RPG CGI vs API Gateway. Which approach is right for your IBM i environment?',

            // ── All in One SEO ────────────────────
            '_aioseo_title'              => 'Building REST APIs on IBM i: Node.js in PASE and Modern Front-End Integration',
            '_aioseo_description'        => 'How to expose IBM i data and RPG business logic as REST APIs. Covers IAS REST, Node.js in PASE with Express, PHP, RPG CGI, API gateways, and authentication patterns.',
            '_aioseo_keywords'           => 'IBM i REST API,Node.js PASE IBM i,IBM i web services,RPG REST API,IAS REST IBM i,idb-connector,IBM i modern front end',
            '_aioseo_og_title'           => 'Building REST APIs on IBM i: Connecting Modern Front Ends to RPG',
            '_aioseo_og_description'     => 'IAS REST, Node.js in PASE, PHP, RPG CGI, and API gateways — a practical guide to every option for exposing IBM i as REST APIs.',
            '_aioseo_twitter_title'      => 'Building REST APIs on IBM i — every option explained',
            '_aioseo_twitter_description'=> 'IAS REST vs Node.js in PASE vs RPG CGI vs API Gateway. Which approach is right for your IBM i environment?',

            // ── Rank Math ─────────────────────────
            'rank_math_focus_keyword'    => 'IBM i REST API Node.js PASE',
            'rank_math_description'      => 'How to expose IBM i data and RPG business logic as REST APIs. Covers IAS REST, Node.js in PASE with Express, PHP, RPG CGI, API gateways, and authentication patterns.',
            'rank_math_title'            => 'Building REST APIs on IBM i: Node.js in PASE and Modern Front-End Integration',

            // ── Disable Gutenberg ─────────────────
            '_classic_editor_enabled'    => 'classic',
        ),
    ));

    // ── Attach tags ───────────────────────────────
    if ($post_id && !is_wp_error($post_id) && !empty($tag_ids)) {
        wp_set_post_tags($post_id, $tag_ids, false);
    }
}

/* ─────────────────────────────────────────────────
   Force classic editor for this post
   ───────────────────────────────────────────────── */
add_filter('use_block_editor_for_post', 'as400_post15_use_classic', 10, 2);
function as400_post15_use_classic($use_block_editor, $post) {
    if (!$post) return $use_block_editor;
    $marker = get_post_meta($post->ID, '_as400_post15', true);
    if ($marker === '1') {
        return false;
    }
    return $use_block_editor;
}
